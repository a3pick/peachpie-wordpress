/**
 * فرم‌های Webisoft — موتور مشترک مودال/مراحل/ارسال AJAX.
 * هر ویجت (رزومه/همکاری، عضویت آکادمی، مشاوره) فقط با همین چند data-attribute کار می‌کند،
 * بدون نیاز به جاوااسکریپت اختصاصی. هر نمونه از ویجت (حتی چند بار در یک صفحه)
 * با شناسه‌ی یکتای خودش کار می‌کند، نه با getElementById سراسری.
 */
( function () {
	'use strict';

	function openModal( modal ) {
		modal.classList.add( 'wsf-active' );
		modal.setAttribute( 'aria-hidden', 'false' );
		document.body.style.overflow = 'hidden';
	}

	function closeModal( modal ) {
		modal.classList.remove( 'wsf-active' );
		modal.setAttribute( 'aria-hidden', 'true' );
		document.body.style.overflow = '';
	}

	function goToStep( container, index ) {
		container.querySelectorAll( '.wsf-step' ).forEach( function ( step ) {
			step.classList.toggle( 'wsf-step-active', String( step.dataset.step ) === String( index ) );
		} );
	}

	function initModal( widget ) {
		var modal = widget.querySelector( '.wsf-modal' );
		if ( ! modal ) {
			return;
		}

		widget.querySelectorAll( '[data-wsf-open]' ).forEach( function ( trigger ) {
			trigger.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				openModal( modal );
			} );
		} );

		var closeBtn = modal.querySelector( '.wsf-close' );
		var overlay = modal.querySelector( '.wsf-overlay' );
		if ( closeBtn ) { closeBtn.addEventListener( 'click', function () { closeModal( modal ); } ); }
		if ( overlay ) { overlay.addEventListener( 'click', function () { closeModal( modal ); } ); }

		document.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Escape' && modal.classList.contains( 'wsf-active' ) ) {
				closeModal( modal );
			}
		} );

		return modal;
	}

	function initSteps( widget ) {
		widget.querySelectorAll( '[data-wsf-next]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var step = btn.closest( '.wsf-step' );
				if ( step && step.dataset.wsfRequireSelection === '1' ) {
					var checked = step.querySelector( 'input:checked' );
					if ( ! checked ) {
						alert( widget.dataset.wsfSelectAlert || 'لطفاً یک گزینه را انتخاب کنید.' );
						return;
					}
				}
				// دکمه‌هایی مثل «انتخاب طرح» مقدار فیلدهای فرم را از data-wsf-fill (JSON) پر می‌کنند.
				if ( btn.dataset.wsfFill ) {
					var form = widget.querySelector( 'form.wsf-form' );
					var values = {};
					try { values = JSON.parse( btn.dataset.wsfFill ); } catch ( err ) { values = {}; }
					Object.keys( values ).forEach( function ( name ) {
						var field = form && form.querySelector( '[name="' + name + '"]' );
						if ( field ) { field.value = values[ name ]; }
						widget.querySelectorAll( '[data-wsf-chosen="' + name + '"]' ).forEach( function ( el ) { el.textContent = values[ name ]; } );
					} );
				}
				goToStep( widget, btn.dataset.wsfNext );
			} );
		} );

		widget.querySelectorAll( '[data-wsf-prev]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				goToStep( widget, btn.dataset.wsfPrev );
			} );
		} );

		// اتوادونس: با انتخاب یک رادیو در گروهی که data-wsf-autonext دارد، خودکار برو به مرحله بعد.
		widget.querySelectorAll( '.wsf-radio-group[data-wsf-autonext]' ).forEach( function ( group ) {
			group.querySelectorAll( 'input' ).forEach( function ( input ) {
				input.addEventListener( 'change', function () {
					setTimeout( function () {
						goToStep( widget, group.dataset.wsfAutonext );
					}, 220 );
				} );
			} );
		} );

		// نمایش توضیح متنیِ متصل به گزینه‌ی انتخاب‌شده (مثلاً توضیح طرح مشاوره).
		widget.querySelectorAll( '.wsf-radio-group[data-wsf-reveal]' ).forEach( function ( group ) {
			var target = widget.querySelector( group.dataset.wsfReveal );
			if ( ! target ) { return; }
			var textBox = target.querySelector( '.wsf-reveal-text' );
			group.querySelectorAll( 'input[data-wsf-desc]' ).forEach( function ( input ) {
				input.addEventListener( 'change', function () {
					if ( textBox ) { textBox.innerHTML = ( input.dataset.wsfDesc || '' ).replace( /\n/g, '<br>' ); }
					target.hidden = false;
				} );
			} );
		} );
	}

	function initAjaxSubmit( widget ) {
		var form = widget.querySelector( 'form.wsf-form' );
		if ( ! form ) { return; }

		var message = form.querySelector( '.wsf-message' );
		var submitBtn = form.querySelector( 'button[type="submit"]' );

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			if ( message ) { message.className = 'wsf-message'; message.innerHTML = ''; }
			if ( submitBtn ) { submitBtn.classList.add( 'wsf-loading' ); }

			var formData = new FormData( form );
			formData.append( 'action', form.dataset.wsfAction );

			fetch( window.wsfVars ? wsfVars.ajaxUrl : '/wp-admin/admin-ajax.php', {
				method: 'POST',
				body: formData,
				credentials: 'same-origin',
			} )
				.then( function ( r ) { return r.json(); } )
				.then( function ( data ) {
					if ( submitBtn ) { submitBtn.classList.remove( 'wsf-loading' ); }
					if ( ! message ) { return; }

					if ( data.success ) {
						message.classList.add( 'wsf-success' );
						message.innerHTML = data.data.message;
						form.reset();
						widget.querySelectorAll( '.wsf-reveal-box' ).forEach( function ( b ) { b.hidden = true; } );

						setTimeout( function () {
							goToStep( widget, 0 );
							message.classList.remove( 'wsf-success' );
							message.innerHTML = '';
							if ( form.dataset.wsfCloseOnSuccess ) {
								var modal = widget.querySelector( '.wsf-modal' );
								if ( modal ) { closeModal( modal ); }
							}
						}, 3200 );
					} else {
						message.classList.add( 'wsf-error' );
						message.innerHTML = ( data.data && data.data.message ) || 'خطایی رخ داد.';
					}
				} )
				.catch( function () {
					if ( submitBtn ) { submitBtn.classList.remove( 'wsf-loading' ); }
					if ( message ) {
						message.classList.add( 'wsf-error' );
						message.innerHTML = 'ارتباط با سرور برقرار نشد.';
					}
				} );
		} );
	}

	// هایلایت ستون جدول مقایسه‌ی طرح‌ها با هاور (هر سلول data-col دارد).
	function initPlanTable( widget ) {
		var table = widget.querySelector( '.wsf-plan-table' );
		if ( ! table ) { return; }
		function setCol( col, on ) {
			table.querySelectorAll( '[data-col="' + col + '"]' ).forEach( function ( c ) { c.classList.toggle( 'wsf-col-hover', on ); } );
		}
		table.addEventListener( 'mouseover', function ( e ) {
			var cell = e.target.closest( '[data-col]' );
			if ( cell ) { setCol( cell.dataset.col, true ); }
		} );
		table.addEventListener( 'mouseout', function ( e ) {
			var cell = e.target.closest( '[data-col]' );
			if ( cell ) { setCol( cell.dataset.col, false ); }
		} );
	}

	// کارت‌های موبایل: دکمه‌ی «مشاهده‌ی بیشتر» ویژگی‌های مخفی را باز/بسته می‌کند.
	function initMoreButtons( widget ) {
		widget.querySelectorAll( '[data-wsf-more]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var card = btn.closest( '.wsf-plan-card' );
				var open = card.classList.toggle( 'wsf-expanded' );
				btn.querySelector( '.wsf-more-label' ).textContent = open ? btn.dataset.less : btn.dataset.more;
			} );
		} );
	}

	function autoInit( widget ) {
		if ( widget.dataset.wsfInited ) { return; }
		widget.dataset.wsfInited = '1';
		initModal( widget );
		initSteps( widget );
		initAjaxSubmit( widget );
		initPlanTable( widget );
		initMoreButtons( widget );
	}

	/**
	 * باز کردن مودال با شناسه‌ی پاپ‌آپ: لینک‌هایی مثل href="#resume-popup" (مثلاً آیتم منو).
	 */
	function findPopupModal( id ) {
		if ( ! id ) { return null; }
		var widgets = document.querySelectorAll( '.wsf-widget[data-wsf-popup-id]' );
		for ( var i = 0; i < widgets.length; i++ ) {
			if ( widgets[ i ].getAttribute( 'data-wsf-popup-id' ) === id ) {
				autoInit( widgets[ i ] );
				return widgets[ i ].querySelector( '.wsf-modal' );
			}
		}
		return null;
	}

	function hashToId( href ) {
		var idx = href ? href.indexOf( '#' ) : -1;
		if ( idx === -1 ) { return ''; }
		try { return decodeURIComponent( href.slice( idx + 1 ) ); } catch ( err ) { return ''; }
	}

	// فاز capture: حتی اگر اسکریپت منو/اسموت‌اسکرول رویداد را متوقف کند، باز هم کار می‌کند.
	document.addEventListener( 'click', function ( e ) {
		var link = e.target.closest ? e.target.closest( 'a[href*="#"]' ) : null;
		if ( ! link || ! link.hash || link.hash.length < 2 ) { return; }
		var norm = function ( p ) { return ( p || '/' ).replace( /\/+$/, '' ) || '/'; };
		var sameHost = link.hostname.replace( /^www\./, '' ) === window.location.hostname.replace( /^www\./, '' );
		if ( ! sameHost || norm( link.pathname ) !== norm( window.location.pathname ) ) { return; }
		var modal = findPopupModal( hashToId( link.hash ) );
		if ( modal ) {
			e.preventDefault();
			e.stopPropagation();
			openModal( modal );
		}
	}, true );

	// جایگزین: کلاس CSS روی آیتم منو، مثلاً wsf-open-consulting-popup (فیلد «CSS Classes» آیتم منو)
	document.addEventListener( 'click', function ( e ) {
		var el = e.target.closest ? e.target.closest( '[class*="wsf-open-"]' ) : null;
		if ( ! el ) { return; }
		var m = ( el.className + '' ).match( /(?:^|\s)wsf-open-([\w-]+)/ );
		var modal = m ? findPopupModal( m[ 1 ] ) : null;
		if ( modal ) {
			e.preventDefault();
			e.stopPropagation();
			openModal( modal );
		}
	}, true );

	window.addEventListener( 'hashchange', function () {
		var modal = findPopupModal( hashToId( window.location.hash ) );
		if ( modal ) { openModal( modal ); }
	} );

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '.wsf-widget' ).forEach( autoInit );
		var modal = findPopupModal( hashToId( window.location.hash ) );
		if ( modal ) { openModal( modal ); }
	} );

	window.WSF = { openModal: openModal, closeModal: closeModal, goToStep: goToStep, autoInit: autoInit };
} )();
