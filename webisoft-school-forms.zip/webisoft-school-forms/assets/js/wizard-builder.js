/**
 * رابط ادمین «سازنده ویزارد هوشمند»: افزودن/حذف/ویرایش مراحل، هرکدام یا
 * متصل به یک فیلتر JetSmartFilters (داینامیک) یا یک لیست دستی از گزینه‌ها.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var hiddenInput = document.getElementById( 'wsf-wizard-builder-data' );
		var container = document.getElementById( 'wsf-wizard-builder-container' );
		var addBtn = document.getElementById( 'wsf-wizard-add-step' );
		if ( ! hiddenInput || ! container || ! addBtn ) { return; }

		var filters = window.wsfWizardFilters || [];
		var data = [];
		try {
			data = JSON.parse( hiddenInput.value || '[]' );
		} catch ( e ) {
			data = [];
		}

		function save() {
			hiddenInput.value = JSON.stringify( data );
		}

		function render() {
			container.innerHTML = '';

			data.forEach( function ( step, index ) {
				var box = document.createElement( 'div' );
				box.className = 'wsf-a-card';
				box.style.cssText = 'border-inline-start:4px solid var(--wsf-a-primary,#2271b1); margin-bottom:14px;';

				var filterOptionsHtml = '<option value="">-- انتخاب فیلتر (در صورت داینامیک بودن) --</option>';
				filters.forEach( function ( f ) {
					filterOptionsHtml += '<option value="' + f.id + '"' + ( String( step.filter_id ) === String( f.id ) ? ' selected' : '' ) + '>' + f.title + '</option>';
				} );

				box.innerHTML =
					'<div class="wsf-a-card-head"><h3>مرحله ' + ( index + 1 ) + '</h3><button type="button" class="wsf-a-btn wsf-a-btn-danger wsf-a-btn-sm wsf-remove-step" data-step="' + index + '">حذف مرحله</button></div>' +
					'<div class="wsf-a-form-group"><label>متن سوال به کاربر</label>' +
					'<input type="text" class="wsf-a-form-control wsf-step-qtitle" data-step="' + index + '" value="' + ( step.q_title || '' ).replace( /"/g, '&quot;' ) + '" placeholder="مثال: چه درسی می‌خواهی؟"></div>' +
					'<div class="wsf-a-form-group"><label>نوع پاسخ‌ها</label>' +
					'<select class="wsf-a-form-control wsf-step-type" data-step="' + index + '">' +
					'<option value="filter"' + ( step.type === 'filter' ? ' selected' : '' ) + '>داینامیک (متصل به فیلترهای جت)</option>' +
					'<option value="manual"' + ( step.type === 'manual' ? ' selected' : '' ) + '>دستی (تایپ گزینه‌ها)</option>' +
					'</select></div>' +
					'<div class="wsf-filter-wrap wsf-a-form-group" style="display:' + ( step.type === 'filter' ? 'block' : 'none' ) + ';">' +
					'<label>پاسخ‌ها به طور خودکار از فیلتر زیر استخراج می‌شوند</label>' +
					'<select class="wsf-a-form-control wsf-q-filter" data-step="' + index + '">' + filterOptionsHtml + '</select></div>' +
					'<div class="wsf-manual-wrap wsf-a-form-group" style="display:' + ( step.type === 'manual' ? 'block' : 'none' ) + ';">' +
					'<label>گزینه‌ها را با کاما جدا کنید</label>' +
					'<input type="text" class="wsf-a-form-control wsf-step-manual" data-step="' + index + '" value="' + ( step.manual_options || '' ).replace( /"/g, '&quot;' ) + '" placeholder="بله,خیر"></div>' +
					'<label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:#334155;"><input type="checkbox" class="wsf-step-multi" data-step="' + index + '"' + ( step.is_multi ? ' checked' : '' ) + '> کاربر بتواند چند گزینه را همزمان انتخاب کند (Multi-Select)</label>';

				container.appendChild( box );
			} );

			save();
		}

		addBtn.addEventListener( 'click', function () {
			data.push( { q_title: '', type: 'filter', filter_id: '', manual_options: '', is_multi: false } );
			render();
		} );

		container.addEventListener( 'click', function ( e ) {
			if ( e.target.classList.contains( 'wsf-remove-step' ) ) {
				data.splice( parseInt( e.target.dataset.step, 10 ), 1 );
				render();
			}
		} );

		container.addEventListener( 'change', function ( e ) {
			var idx = parseInt( e.target.dataset.step, 10 );
			if ( isNaN( idx ) ) { return; }

			if ( e.target.classList.contains( 'wsf-step-type' ) ) {
				data[ idx ].type = e.target.value;
				render();
			} else if ( e.target.classList.contains( 'wsf-q-filter' ) ) {
				data[ idx ].filter_id = e.target.value;
				save();
			} else if ( e.target.classList.contains( 'wsf-step-multi' ) ) {
				data[ idx ].is_multi = e.target.checked;
				save();
			}
		} );

		container.addEventListener( 'input', function ( e ) {
			var idx = parseInt( e.target.dataset.step, 10 );
			if ( isNaN( idx ) ) { return; }

			if ( e.target.classList.contains( 'wsf-step-qtitle' ) ) {
				data[ idx ].q_title = e.target.value;
				save();
			} else if ( e.target.classList.contains( 'wsf-step-manual' ) ) {
				data[ idx ].manual_options = e.target.value;
				save();
			}
		} );

		render();
	} );
} )();
