/**
 * تقویم شمسی سبک برای صفحات ادمین این پلاگین — همان الگو/همان الگوریتم
 * pilates-booking-core (jalali-datepicker.js): فیلد نمایشی همیشه شمسی است،
 * مقدار واقعی ارسالی به سرور همیشه میلادیِ YYYY-MM-DD است.
 */
( function ( $ ) {
	'use strict';

	var PERSIAN_MONTHS = [ 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' ];
	var DOW_LABELS = [ 'ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج' ];

	function toPersianDigits( str ) {
		var en = [ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ];
		var fa = [ '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' ];
		str = String( str );
		for ( var i = 0; i < 10; i++ ) {
			str = str.split( en[ i ] ).join( fa[ i ] );
		}
		return str;
	}

	function pad( n ) { return ( n < 10 ? '0' : '' ) + n; }

	function gregorianToJalali( gy, gm, gd ) {
		var g_d_m = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
		var j_d_m = [ 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29 ];

		var gy2 = gy - 1600;
		var gm2 = gm - 1;
		var gd2 = gd - 1;

		var g_day_no = 365 * gy2 + Math.floor( ( gy2 + 3 ) / 4 ) - Math.floor( ( gy2 + 99 ) / 100 ) + Math.floor( ( gy2 + 399 ) / 400 );
		for ( var i = 0; i < gm2; i++ ) {
			g_day_no += g_d_m[ i ];
		}
		if ( gm2 > 1 && ( ( gy2 % 4 === 0 && gy2 % 100 !== 0 ) || gy2 % 400 === 0 ) ) {
			g_day_no++;
		}
		g_day_no += gd2;

		var j_day_no = g_day_no - 79;
		var j_np = Math.floor( j_day_no / 12053 );
		j_day_no %= 12053;

		var jy = 979 + 33 * j_np + 4 * Math.floor( j_day_no / 1461 );
		j_day_no %= 1461;

		if ( j_day_no >= 366 ) {
			jy += Math.floor( ( j_day_no - 1 ) / 365 );
			j_day_no = ( j_day_no - 1 ) % 365;
		}

		var jm;
		for ( jm = 0; jm < 11 && j_day_no >= j_d_m[ jm ]; jm++ ) {
			j_day_no -= j_d_m[ jm ];
		}
		return [ jy, jm + 1, j_day_no + 1 ];
	}

	function jalaliToGregorian( jy, jm, jd ) {
		var g_d_m = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
		var j_d_m = [ 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29 ];

		var jy2 = jy - 979;
		var jm2 = jm - 1;
		var jd2 = jd - 1;

		var j_day_no = 365 * jy2 + Math.floor( jy2 / 33 ) * 8 + Math.floor( ( ( jy2 % 33 ) + 3 ) / 4 );
		for ( var i = 0; i < jm2; i++ ) {
			j_day_no += j_d_m[ i ];
		}
		j_day_no += jd2;

		var g_day_no = j_day_no + 79;

		var gy = 1600 + 400 * Math.floor( g_day_no / 146097 );
		g_day_no %= 146097;

		var leap = true;
		if ( g_day_no >= 36525 ) {
			g_day_no--;
			gy += 100 * Math.floor( g_day_no / 36524 );
			g_day_no %= 36524;
			if ( g_day_no >= 365 ) {
				g_day_no++;
			} else {
				leap = false;
			}
		}

		gy += 4 * Math.floor( g_day_no / 1461 );
		g_day_no %= 1461;

		if ( g_day_no >= 366 ) {
			leap = false;
			g_day_no--;
			gy += Math.floor( g_day_no / 365 );
			g_day_no %= 365;
		}

		var gm;
		for ( gm = 0; gm < 12; gm++ ) {
			var threshold = g_d_m[ gm ] + ( ( gm === 1 && leap ) ? 1 : 0 );
			if ( g_day_no < threshold ) {
				break;
			}
			g_day_no -= threshold;
		}
		return [ gy, gm + 1, g_day_no + 1 ];
	}

	function jalaliDaysInMonth( jy, jm ) {
		var g1 = jalaliToGregorian( jy, jm, 1 );
		var nextJm = jm === 12 ? 1 : jm + 1;
		var nextJy = jm === 12 ? jy + 1 : jy;
		var g2 = jalaliToGregorian( nextJy, nextJm, 1 );
		var d1 = Date.UTC( g1[ 0 ], g1[ 1 ] - 1, g1[ 2 ] );
		var d2 = Date.UTC( g2[ 0 ], g2[ 1 ] - 1, g2[ 2 ] );
		return Math.round( ( d2 - d1 ) / 86400000 );
	}

	function jalaliStartColumn( jy, jm ) {
		var g = jalaliToGregorian( jy, jm, 1 );
		var dow = new Date( Date.UTC( g[ 0 ], g[ 1 ] - 1, g[ 2 ] ) ).getUTCDay();
		return ( dow + 1 ) % 7;
	}

	function Datepicker( field ) {
		this.$field = $( field );
		this.$display = this.$field.find( '.wsf-jalali-display' );
		this.$hidden = this.$field.find( '.wsf-jalali-value' );
		this.$popup = null;
		this.viewJy = null;
		this.viewJm = null;

		this.syncDisplay( this.selectedJalali() );

		var self = this;
		this.$display.on( 'click', function ( e ) {
			e.stopPropagation();
			self.open();
		} );
	}

	Datepicker.prototype.selectedJalali = function () {
		var val = this.$hidden.val();
		if ( val ) {
			var parts = val.split( '-' ).map( Number );
			if ( parts.length === 3 && parts[ 0 ] ) {
				return gregorianToJalali( parts[ 0 ], parts[ 1 ], parts[ 2 ] );
			}
		}
		return null;
	};

	Datepicker.prototype.syncDisplay = function ( jalali ) {
		if ( jalali ) {
			this.$display.val( toPersianDigits( jalali[ 0 ] ) + '/' + toPersianDigits( pad( jalali[ 1 ] ) ) + '/' + toPersianDigits( pad( jalali[ 2 ] ) ) );
		}
	};

	Datepicker.prototype.open = function () {
		$( '.wsf-jalali-popup.wsf-jd-open' ).removeClass( 'wsf-jd-open' );
		if ( ! this.$popup ) {
			this.$popup = $( '<div class="wsf-jalali-popup"></div>' ).appendTo( this.$field );
			this.$popup.on( 'click', function ( e ) { e.stopPropagation(); } );
		}
		var today = new Date();
		var sel = this.selectedJalali() || gregorianToJalali( today.getFullYear(), today.getMonth() + 1, today.getDate() );
		this.viewJy = sel[ 0 ];
		this.viewJm = sel[ 1 ];
		this.render();
		this.$popup.addClass( 'wsf-jd-open' );
	};

	Datepicker.prototype.close = function () {
		if ( this.$popup ) {
			this.$popup.removeClass( 'wsf-jd-open' );
		}
	};

	Datepicker.prototype.render = function () {
		var self = this;
		var sel = this.selectedJalali();
		var today = new Date();
		var todayJalali = gregorianToJalali( today.getFullYear(), today.getMonth() + 1, today.getDate() );

		var daysInMonth = jalaliDaysInMonth( this.viewJy, this.viewJm );
		var startCol = jalaliStartColumn( this.viewJy, this.viewJm );

		var html = '<div class="wsf-jalali-popup-header">' +
			'<button type="button" class="wsf-jd-prev">قبل</button>' +
			'<span class="wsf-jalali-popup-title">' + PERSIAN_MONTHS[ this.viewJm - 1 ] + ' ' + toPersianDigits( this.viewJy ) + '</span>' +
			'<button type="button" class="wsf-jd-next">بعد</button>' +
			'</div><div class="wsf-jalali-grid">';

		DOW_LABELS.forEach( function ( d ) { html += '<span class="wsf-jd-dow">' + d + '</span>'; } );
		for ( var i = 0; i < startCol; i++ ) {
			html += '<span></span>';
		}
		for ( var day = 1; day <= daysInMonth; day++ ) {
			var isToday = ( this.viewJy === todayJalali[ 0 ] && this.viewJm === todayJalali[ 1 ] && day === todayJalali[ 2 ] );
			var isSelected = sel && ( this.viewJy === sel[ 0 ] && this.viewJm === sel[ 1 ] && day === sel[ 2 ] );
			var cls = 'wsf-jd-day' + ( isToday ? ' wsf-jd-today' : '' ) + ( isSelected ? ' wsf-jd-selected' : '' );
			html += '<button type="button" class="' + cls + '" data-day="' + day + '">' + toPersianDigits( day ) + '</button>';
		}
		html += '</div><div class="wsf-jalali-popup-footer">' +
			'<button type="button" class="wsf-jd-today-btn">امروز</button>' +
			( this.$field.data( 'optional' ) ? '<button type="button" class="wsf-jd-clear-btn">پاک کردن</button>' : '<span></span>' ) +
			'</div>';

		this.$popup.html( html );

		this.$popup.find( '.wsf-jd-next' ).on( 'click', function () { self.changeMonth( 1 ); } );
		this.$popup.find( '.wsf-jd-prev' ).on( 'click', function () { self.changeMonth( -1 ); } );
		this.$popup.find( '.wsf-jd-day' ).on( 'click', function () {
			self.selectDay( parseInt( $( this ).data( 'day' ), 10 ) );
		} );
		this.$popup.find( '.wsf-jd-today-btn' ).on( 'click', function () {
			var g = new Date();
			self.setGregorian( g.getFullYear(), g.getMonth() + 1, g.getDate() );
		} );
		this.$popup.find( '.wsf-jd-clear-btn' ).on( 'click', function () {
			self.$hidden.val( '' ).trigger( 'change' );
			self.$display.val( '' );
			self.close();
		} );
	};

	Datepicker.prototype.changeMonth = function ( delta ) {
		this.viewJm += delta;
		if ( this.viewJm > 12 ) { this.viewJm = 1; this.viewJy++; }
		if ( this.viewJm < 1 ) { this.viewJm = 12; this.viewJy--; }
		this.render();
	};

	Datepicker.prototype.selectDay = function ( day ) {
		var g = jalaliToGregorian( this.viewJy, this.viewJm, day );
		this.setGregorian( g[ 0 ], g[ 1 ], g[ 2 ] );
	};

	Datepicker.prototype.setGregorian = function ( gy, gm, gd ) {
		var iso = gy + '-' + pad( gm ) + '-' + pad( gd );
		this.$hidden.val( iso ).trigger( 'change' );
		this.syncDisplay( gregorianToJalali( gy, gm, gd ) );
		this.close();
	};

	$( document ).on( 'click', function () {
		$( '.wsf-jalali-popup.wsf-jd-open' ).removeClass( 'wsf-jd-open' );
	} );

	$( function () {
		$( '.wsf-jalali-field' ).each( function () {
			$( this ).data( 'wsfDatepicker', new Datepicker( this ) );
		} );
	} );
} )( jQuery );
