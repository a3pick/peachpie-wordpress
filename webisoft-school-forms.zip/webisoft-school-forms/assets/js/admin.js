jQuery( function ( $ ) {
	$( '.wsf-color-picker' ).wpColorPicker();
} );

// تب‌های صفحات ادمین: همه فیلدها همیشه داخل یک فرم هستند، فقط نمایش/عدم‌نمایش
// پنل تغییر می‌کند تا ذخیره‌ی همه‌ی تب‌ها با یک دکمه و یک ارسال فرم انجام شود.
document.addEventListener( 'DOMContentLoaded', function () {
	var tabs = document.querySelectorAll( '.wsf-a-tab' );
	if ( ! tabs.length ) {
		return;
	}

	tabs.forEach( function ( tab ) {
		tab.addEventListener( 'click', function () {
			var target = tab.getAttribute( 'data-tab' );

			document.querySelectorAll( '.wsf-a-tab' ).forEach( function ( t ) { t.classList.remove( 'active' ); } );
			document.querySelectorAll( '.wsf-a-panel' ).forEach( function ( p ) { p.hidden = true; } );

			tab.classList.add( 'active' );
			var panel = document.querySelector( '.wsf-a-panel[data-panel="' + target + '"]' );
			if ( panel ) {
				panel.hidden = false;
			}

			var url = new URL( window.location.href );
			url.searchParams.set( 'tab', target );
			window.history.replaceState( {}, '', url );
		} );
	} );

	var params = new URLSearchParams( window.location.search );
	var wantedTab = params.get( 'tab' );
	if ( wantedTab ) {
		var wantedBtn = document.querySelector( '.wsf-a-tab[data-tab="' + wantedTab + '"]' );
		if ( wantedBtn ) {
			wantedBtn.click();
		}
	}
} );
