/**
 * منطق اختصاصی ویجت «ویزارد هوشمند اساتید»: بارگذاری پویای گزینه‌های هر
 * مرحله از طریق AJAX (وابسته به مراحل قبلی)، ثبت لاگ، و در نهایت هدایت
 * کاربر به صفحه‌ی آرشیو با کوئری‌استرینگ تکسونومی. هر نمونه از ویجت
 * (چند بار در یک صفحه) با state مستقل خودش کار می‌کند.
 */
( function () {
	'use strict';

	function buildOptionCard( inputType, name, value, label, extraData ) {
		var wrap = document.createElement( 'label' );
		wrap.className = 'wsf-option-card';

		var input = document.createElement( 'input' );
		input.type = inputType;
		input.name = name;
		input.value = value;
		if ( extraData ) {
			Object.keys( extraData ).forEach( function ( k ) { input.dataset[ k ] = extraData[ k ]; } );
		}

		var check = document.createElement( 'span' );
		check.className = 'wsf-option-check' + ( inputType === 'radio' ? ' wsf-check-round' : '' );

		var labelSpan = document.createElement( 'span' );
		labelSpan.className = 'wsf-option-label';
		labelSpan.textContent = label;

		wrap.appendChild( input );
		wrap.appendChild( check );
		wrap.appendChild( labelSpan );
		return wrap;
	}

	function initWizard( widget ) {
		var root = widget.querySelector( '[data-wsf-wizard]' );
		if ( ! root ) { return; }

		var ajaxUrl = window.wsfVars ? wsfVars.ajaxUrl : '/wp-admin/admin-ajax.php';
		var nonceInput = root.querySelector( 'input[name="wsf_nonce"]' );
		var nonce = nonceInput ? nonceInput.value : '';
		var archiveUrl = root.dataset.archiveUrl || '/';
		var wizardId = root.dataset.wizardId || '';
		var wizardState = [];
		var logData = {};

		function stepEl( index ) {
			return root.querySelector( '.wsf-step[data-step="' + index + '"]' );
		}

		function loadDynamicStep( index ) {
			var step = stepEl( index );
			if ( ! step || step.dataset.type !== 'filter' ) { return; }

			var optionsBox = step.querySelector( '.wsf-wizard-options' );
			var loading = step.querySelector( '.wsf-wizard-loading' );
			optionsBox.innerHTML = '';
			loading.hidden = false;

			var formData = new FormData();
			formData.append( 'action', 'wsf_wizard_get_terms' );
			formData.append( 'wsf_nonce', nonce );
			formData.append( 'wizard_id', wizardId );
			formData.append( 'filter_id', step.dataset.filter );
			wizardState.forEach( function ( item, i ) {
				formData.append( 'deps[' + i + '][filter_id]', item.filter_id );
				( item.value || [] ).forEach( function ( v ) {
					formData.append( 'deps[' + i + '][value][]', v );
				} );
			} );

			fetch( ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( res ) {
					loading.hidden = true;
					if ( ! res.success ) { return; }
					step.dataset.tax = res.data.taxonomy;

					if ( ! res.data.terms.length ) {
						optionsBox.innerHTML = '<p style="color:#d63638;">متأسفانه گزینه‌ای یافت نشد.</p>';
						return;
					}

					var isMulti = step.dataset.multi === '1';
					res.data.terms.forEach( function ( term ) {
						optionsBox.appendChild(
							buildOptionCard( isMulti ? 'checkbox' : 'radio', 'step_' + index + '[]', term.id, term.name, { label: term.name } )
						);
					} );
				} );
		}

		function collectSelections( step ) {
			var values = [];
			var labels = [];
			step.querySelectorAll( 'input:checked' ).forEach( function ( input ) {
				values.push( input.value );
				labels.push( input.dataset.label || input.value );
			} );
			return { values: values, labels: labels };
		}

		root.querySelectorAll( '[data-wsf-wizard-next]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var current = btn.closest( '.wsf-step' );
				var targetIndex = btn.dataset.wsfWizardNext;
				var picked = collectSelections( current );

				if ( ! picked.values.length ) {
					alert( 'لطفاً حداقل یک گزینه را انتخاب کنید.' );
					return;
				}

				if ( current.dataset.type === 'filter' ) {
					wizardState = wizardState.filter( function ( i ) { return i.filter_id !== current.dataset.filter; } );
					wizardState.push( { filter_id: current.dataset.filter, tax: current.dataset.tax, value: picked.values } );
				}
				logData[ current.dataset.qtitle ] = picked.labels;

				WSF.goToStep( widget, targetIndex );
				loadDynamicStep( targetIndex );
			} );
		} );

		root.querySelectorAll( '[data-wsf-wizard-prev]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				WSF.goToStep( widget, btn.dataset.wsfWizardPrev );
			} );
		} );

		root.querySelectorAll( '.wsf-wizard-submit' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var current = btn.closest( '.wsf-step' );
				var picked = collectSelections( current );

				if ( picked.values.length ) {
					if ( current.dataset.type === 'filter' ) {
						wizardState.push( { filter_id: current.dataset.filter, tax: current.dataset.tax, value: picked.values } );
					}
					logData[ current.dataset.qtitle ] = picked.labels;
				}

				btn.textContent = 'در حال انتقال...';
				btn.disabled = true;

				var formData = new FormData();
				formData.append( 'action', 'wsf_wizard_save_log' );
				formData.append( 'wsf_nonce', nonce );
				formData.append( 'wizard_id', wizardId );
				formData.append( 'log_data', JSON.stringify( logData ) );

				fetch( ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' } ).finally( function () {
					var taxQueries = [];
					wizardState.forEach( function ( item ) {
						if ( item.tax ) { taxQueries.push( item.tax + ':' + item.value.join( ',' ) ); }
					} );

					var finalUrl = archiveUrl;
					if ( taxQueries.length ) {
						var sep = finalUrl.indexOf( '?' ) !== -1 ? '&' : '?';
						finalUrl += sep + 'jsf=jet-engine&tax=' + encodeURIComponent( taxQueries.join( ';' ) );
					}
					window.location.href = finalUrl;
				} );
			} );
		} );

		loadDynamicStep( 0 );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '.wsf-widget[data-wsf-module="teacher_wizard"]' ).forEach( initWizard );
	} );
} )();
