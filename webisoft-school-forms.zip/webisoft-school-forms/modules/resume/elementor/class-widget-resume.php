<?php
defined( 'ABSPATH' ) || exit;

class WSF_Widget_Resume extends \Elementor\Widget_Base {

	use WSF_Elementor_Widget_Trait;

	public function get_name() { return 'wsf-resume'; }
	public function get_title() { return __( 'Webisoft: فرم همکاری (رزومه)', 'webisoft-school-forms' ); }
	public function get_icon() { return 'eicon-form-horizontal'; }

	public function get_style_depends() { return array( 'wsf-frontend' ); }
	public function get_script_depends() { return array( 'wsf-frontend' ); }

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array( 'label' => __( 'محتوا', 'webisoft-school-forms' ) ) );

		$this->add_control(
			'button_text',
			array(
				'label'       => __( 'متن دکمه', 'webisoft-school-forms' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => get_option( 'wsf_resume_button_text', 'آیا میخواید همکارمون بشید؟' ),
				'description' => __( 'خالی بگذارید تا متن تنظیم‌شده در «تنظیمات فرم‌ها» استفاده شود.', 'webisoft-school-forms' ),
			)
		);

		$this->add_wsf_popup_id_control();

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', array( 'label' => __( 'ظاهر', 'webisoft-school-forms' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_wsf_css_var_color_control( 'accent_color', 'wsf-accent', __( 'رنگ برند (این نمونه)', 'webisoft-school-forms' ) );
		$this->add_wsf_typography_control( 'button_typography', '{{WRAPPER}} .wsf-trigger-btn', __( 'تایپوگرافی دکمه', 'webisoft-school-forms' ) );
		$this->add_wsf_corner_radius_control( 'trigger_radius', 'wsf-trigger-radius', __( 'گردی گوشه‌های دکمه‌ی اصلی', 'webisoft-school-forms' ) );
		$this->add_wsf_radius_control( 'modal_radius', 'wsf-radius', __( 'گردی گوشه‌های مودال', 'webisoft-school-forms' ), 14 );
		$this->end_controls_section();
	}

	protected function render() {
		$settings   = $this->get_settings_for_display();
		$uid        = 'wsf-resume-' . $this->get_id();
		$button_txt = $settings['button_text'] ?: get_option( 'wsf_resume_button_text', 'آیا میخواید همکارمون بشید؟' );

		$resume_module   = wsf()->resume;
		$max_size        = $resume_module->get_max_size_mb();
		$allowed_types   = array_keys( $resume_module->get_allowed_types() );
		$education_opts  = $resume_module->get_education_options();
		$accept_attr     = implode( ',', array_map( function ( $ext ) { return '.' . $ext; }, $allowed_types ) );
		?>
		<div class="wsf-widget"<?php echo $this->get_wsf_popup_id_attr( $settings ); // phpcs:ignore -- escaped in helper ?> data-wsf-module="resume" id="<?php echo esc_attr( $uid ); ?>">
			<button type="button" class="wsf-trigger-btn" data-wsf-open><?php echo esc_html( $button_txt ); ?></button>

			<div class="wsf-modal" id="<?php echo esc_attr( $uid ); ?>-modal" aria-hidden="true">
				<div class="wsf-overlay"></div>
				<div class="wsf-modal-content">
					<button type="button" class="wsf-close" aria-label="<?php esc_attr_e( 'بستن', 'webisoft-school-forms' ); ?>">×</button>

					<form class="wsf-form" data-wsf-action="wsf_submit_resume" enctype="multipart/form-data">
						<?php wp_nonce_field( 'wsf_submit_resume', 'wsf_nonce' ); ?>

						<div class="wsf-step wsf-step-active" data-step="0">
							<h2 class="wsf-form-title"><?php esc_html_e( 'ارسال رزومه', 'webisoft-school-forms' ); ?></h2>
							<p class="wsf-form-desc"><?php esc_html_e( 'لطفاً اطلاعات خود را وارد کنید.', 'webisoft-school-forms' ); ?></p>

							<div class="wsf-field">
								<label><?php esc_html_e( 'نام', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
								<input type="text" name="first_name" required autocomplete="given-name">
							</div>
							<div class="wsf-field">
								<label><?php esc_html_e( 'نام خانوادگی', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
								<input type="text" name="last_name" required autocomplete="family-name">
							</div>
							<div class="wsf-field">
								<label><?php esc_html_e( 'شماره تماس', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
								<input type="tel" name="phone" required placeholder="09123456789" autocomplete="tel">
							</div>
							<div class="wsf-field">
								<label><?php esc_html_e( 'میزان تحصیلات', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
								<select name="education" required>
									<option value=""><?php esc_html_e( 'انتخاب کنید', 'webisoft-school-forms' ); ?></option>
									<?php foreach ( $education_opts as $opt ) : ?>
										<option value="<?php echo esc_attr( $opt ); ?>"><?php echo esc_html( $opt ); ?></option>
									<?php endforeach; ?>
								</select>
							</div>
							<div class="wsf-field">
								<label><?php esc_html_e( 'رزومه / فایل', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
								<input type="file" name="resume_file" required accept="<?php echo esc_attr( $accept_attr ); ?>">
								<small>
									<?php
									printf(
										/* translators: 1: لیست فرمت‌های مجاز, 2: حداکثر حجم به مگابایت */
										esc_html__( 'فرمت‌های مجاز: %1$s — حداکثر %2$d مگابایت', 'webisoft-school-forms' ),
										esc_html( strtoupper( implode( ', ', $allowed_types ) ) ),
										(int) $max_size
									);
									?>
								</small>
							</div>

							<div class="wsf-message"></div>

							<button type="submit" class="wsf-btn">
								<span class="wsf-submit-text"><?php esc_html_e( 'ارسال رزومه', 'webisoft-school-forms' ); ?></span>
								<span class="wsf-loading-text"><?php esc_html_e( 'در حال ارسال...', 'webisoft-school-forms' ); ?></span>
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php
	}
}
