<?php
defined( 'ABSPATH' ) || exit;

/**
 * ماژول «فرم همکاری» (درخواست استخدام/همکاری همراه با آپلود رزومه) — فرم
 * تک‌مرحله‌ای با آپلود فایل. (نام داخلی کد resume مانده تا نیازی به تغییر
 * گسترده‌ی اسلاگ/جدول دیتابیس نباشد؛ فقط برچسب‌های قابل‌مشاهده عوض شده‌اند.)
 */
class WSF_Resume_Module {

	const ID = 'resume';

	private $allowed_types = array(
		'pdf'  => 'application/pdf',
		'doc'  => 'application/msword',
		'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
	);

	public function register() {
		add_action( 'wp_ajax_wsf_submit_resume', array( $this, 'handle_submit' ) );
		add_action( 'wp_ajax_nopriv_wsf_submit_resume', array( $this, 'handle_submit' ) );
	}

	public function register_elementor_widget( $widgets_manager ) {
		require_once __DIR__ . '/elementor/class-widget-resume.php';
		$widgets_manager->register( new WSF_Widget_Resume() );
	}

	public function register_settings() {
		register_setting( 'wsf_settings_group', 'wsf_resume_button_text' );
		register_setting( 'wsf_settings_group', 'wsf_resume_font' );
		register_setting( 'wsf_settings_group', 'wsf_resume_accent_color' );
		register_setting( 'wsf_settings_group', 'wsf_resume_max_size_mb' );
		register_setting( 'wsf_settings_group', 'wsf_resume_allowed_types', array( 'type' => 'array' ) );
		register_setting( 'wsf_settings_group', 'wsf_resume_education_options' );
	}

	public function get_max_size_mb() {
		$mb = (int) get_option( 'wsf_resume_max_size_mb', 5 );
		return $mb > 0 ? $mb : 5;
	}

	public function get_allowed_types() {
		$saved = get_option( 'wsf_resume_allowed_types', array( 'pdf', 'doc', 'docx' ) );
		$saved = array_intersect( (array) $saved, array_keys( $this->allowed_types ) );
		if ( empty( $saved ) ) {
			$saved = array( 'pdf' );
		}
		return array_intersect_key( $this->allowed_types, array_flip( $saved ) );
	}

	public function get_education_options() {
		$raw = get_option( 'wsf_resume_education_options', 'دیپلم,کاردانی,کارشناسی,کارشناسی ارشد,دکتری,سایر' );
		return array_filter( array_map( 'trim', explode( ',', $raw ) ) );
	}

	/* ---------------------------------------------------------------
	 * تنظیمات
	 * --------------------------------------------------------------- */
	public function render_settings_fields() {
		$button_text = get_option( 'wsf_resume_button_text', 'آیا میخواید همکارمون بشید؟' );
		$font        = get_option( 'wsf_resume_font', '' );
		$accent      = get_option( 'wsf_resume_accent_color', '' );
		$max_size    = get_option( 'wsf_resume_max_size_mb', 5 );
		$allowed     = (array) get_option( 'wsf_resume_allowed_types', array( 'pdf', 'doc', 'docx' ) );
		$education   = get_option( 'wsf_resume_education_options', 'دیپلم,کاردانی,کارشناسی,کارشناسی ارشد,دکتری,سایر' );
		$fonts       = wsf_get_elementor_fonts();
		?>
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'متن دکمه', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="regular-text" name="wsf_resume_button_text" value="<?php echo esc_attr( $button_text ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'حداکثر حجم فایل (مگابایت)', 'webisoft-school-forms' ); ?></th>
				<td><input type="number" min="1" max="50" name="wsf_resume_max_size_mb" value="<?php echo esc_attr( $max_size ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'فرمت‌های مجاز', 'webisoft-school-forms' ); ?></th>
				<td>
					<?php foreach ( $this->allowed_types as $ext => $mime ) : ?>
						<label style="margin-inline-end:15px;"><input type="checkbox" name="wsf_resume_allowed_types[]" value="<?php echo esc_attr( $ext ); ?>" <?php checked( in_array( $ext, $allowed, true ) ); ?>> .<?php echo esc_html( $ext ); ?></label>
					<?php endforeach; ?>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'گزینه‌های میزان تحصیلات', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="text" class="large-text" name="wsf_resume_education_options" value="<?php echo esc_attr( $education ); ?>" dir="rtl">
					<p class="description"><?php esc_html_e( 'با ویرگول (,) از هم جدا کنید.', 'webisoft-school-forms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'رنگ برند اختصاصی این فرم', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="text" class="wsf-color-picker" name="wsf_resume_accent_color" value="<?php echo esc_attr( $accent ); ?>" dir="ltr">
					<p class="description"><?php esc_html_e( 'خالی بگذارید تا رنگ برند عمومی استفاده شود.', 'webisoft-school-forms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'فونت اختصاصی این فرم', 'webisoft-school-forms' ); ?></th>
				<td>
					<select name="wsf_resume_font" style="min-width:25em;">
						<option value=""><?php esc_html_e( '— پیش‌فرض عمومی —', 'webisoft-school-forms' ); ?></option>
						<option value="Tahoma, sans-serif" <?php selected( $font, 'Tahoma, sans-serif' ); ?>>Tahoma</option>
						<?php foreach ( $fonts as $f ) : ?>
							<option value="<?php echo esc_attr( $f ); ?>" <?php selected( $font, $f ); ?>><?php echo esc_html( $f ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</table>
		<?php
	}

	/* ---------------------------------------------------------------
	 * لیست ثبت‌نام‌ها
	 * --------------------------------------------------------------- */
	public function render_submissions_page() {
		$education_options = $this->get_education_options();
		$list = new WSF_Submissions_List(
			array(
				'table'               => wsf_table( 'resume' ),
				'page_slug'           => 'wsf-resume',
				'title'               => __( 'مدیریت ثبت‌نام‌های همکاری', 'webisoft-school-forms' ),
				'icon'                => '🤝',
				'columns'             => array(
					'first_name' => __( 'نام', 'webisoft-school-forms' ),
					'last_name'  => __( 'نام خانوادگی', 'webisoft-school-forms' ),
					'phone'      => __( 'شماره تماس', 'webisoft-school-forms' ),
					'education'  => __( 'تحصیلات', 'webisoft-school-forms' ),
					'file_id'    => __( 'فایل رزومه', 'webisoft-school-forms' ),
				),
				'filters'             => array(
					'first_name' => array( 'label' => __( 'نام', 'webisoft-school-forms' ), 'type' => 'text' ),
					'last_name'  => array( 'label' => __( 'نام خانوادگی', 'webisoft-school-forms' ), 'type' => 'text' ),
					'phone'      => array( 'label' => __( 'شماره تماس', 'webisoft-school-forms' ), 'type' => 'text' ),
					'education'  => array( 'label' => __( 'تحصیلات', 'webisoft-school-forms' ), 'type' => 'select', 'options' => $education_options ),
				),
				'csv_columns'         => array(
					'first_name' => __( 'نام', 'webisoft-school-forms' ),
					'last_name'  => __( 'نام خانوادگی', 'webisoft-school-forms' ),
					'phone'      => __( 'شماره تماس', 'webisoft-school-forms' ),
					'education'  => __( 'تحصیلات', 'webisoft-school-forms' ),
					'file_name'  => __( 'نام فایل', 'webisoft-school-forms' ),
					'file_url'   => __( 'لینک فایل', 'webisoft-school-forms' ),
				),
				'csv_action'          => 'wsf_export_resume_csv',
				'csv_filename_prefix' => 'resume-submissions',
				'nonce_prefix'        => 'wsf_resume',
				'row_cell'            => function ( $row, $key ) {
					if ( 'file_id' === $key ) {
						if ( empty( $row->file_id ) ) {
							return esc_html__( 'بدون فایل', 'webisoft-school-forms' );
						}
						return '<a href="' . esc_url( wp_get_attachment_url( intval( $row->file_id ) ) ) . '" target="_blank" class="button button-small">⬇ ' . esc_html__( 'دانلود', 'webisoft-school-forms' ) . '</a>';
					}
					return null;
				},
				'before_delete'       => function ( $row ) {
					if ( ! empty( $row->file_id ) ) {
						wp_delete_attachment( intval( $row->file_id ), true );
					}
				},
				'before_clear'        => function () {
					global $wpdb;
					$rows = $wpdb->get_results( 'SELECT file_id FROM ' . wsf_table( 'resume' ) . ' WHERE file_id > 0' );
					foreach ( (array) $rows as $row ) {
						wp_delete_attachment( intval( $row->file_id ), true );
					}
				},
			)
		);
		$list->render();
	}

	/* ---------------------------------------------------------------
	 * AJAX
	 * --------------------------------------------------------------- */
	public function handle_submit() {
		check_ajax_referer( 'wsf_submit_resume', 'wsf_nonce' );

		$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
		$last_name  = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
		$phone      = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$education  = isset( $_POST['education'] ) ? sanitize_text_field( wp_unslash( $_POST['education'] ) ) : '';

		if ( ! $first_name || ! $last_name || ! $phone || ! $education ) {
			wsf_ajax_error( __( 'لطفاً تمام فیلدهای الزامی را تکمیل کنید.', 'webisoft-school-forms' ) );
		}

		$phone_clean = wsf_clean_phone( $phone );
		if ( strlen( $phone_clean ) < 8 ) {
			wsf_ajax_error( __( 'شماره تماس وارد شده معتبر نیست.', 'webisoft-school-forms' ) );
		}

		if ( empty( $_FILES['resume_file']['name'] ) ) {
			wsf_ajax_error( __( 'لطفاً فایل رزومه خود را انتخاب کنید.', 'webisoft-school-forms' ) );
		}

		$file = $_FILES['resume_file'];
		if ( UPLOAD_ERR_OK !== $file['error'] ) {
			wsf_ajax_error( __( 'در هنگام آپلود فایل خطایی رخ داد.', 'webisoft-school-forms' ) );
		}

		$max_bytes = $this->get_max_size_mb() * 1024 * 1024;
		if ( $file['size'] > $max_bytes ) {
			/* translators: %d: حداکثر حجم مجاز بر حسب مگابایت */
			wsf_ajax_error( sprintf( __( 'حجم فایل نباید بیشتر از %d مگابایت باشد.', 'webisoft-school-forms' ), $this->get_max_size_mb() ) );
		}

		$allowed   = $this->get_allowed_types();
		$file_info = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $allowed );
		if ( empty( $file_info['ext'] ) || ! isset( $allowed[ $file_info['ext'] ] ) ) {
			wsf_ajax_error( __( 'نوع فایل انتخاب‌شده مجاز نیست.', 'webisoft-school-forms' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$upload = wp_handle_upload( $file, array( 'test_form' => false, 'mimes' => $allowed ) );
		if ( isset( $upload['error'] ) ) {
			wsf_ajax_error( $upload['error'] );
		}

		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $upload['type'],
				'post_title'     => sanitize_file_name( pathinfo( $file['name'], PATHINFO_FILENAME ) ),
				'post_content'   => '',
				'post_status'    => 'private',
			),
			$upload['file']
		);

		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $upload['file'] );
			wsf_ajax_error( __( 'ذخیره فایل با خطا مواجه شد.', 'webisoft-school-forms' ) );
		}

		global $wpdb;
		$result = $wpdb->insert(
			wsf_table( 'resume' ),
			array(
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'phone'        => $phone_clean,
				'education'    => $education,
				'file_id'      => intval( $attachment_id ),
				'file_name'    => sanitize_file_name( $file['name'] ),
				'file_url'     => esc_url_raw( $upload['url'] ),
				'submitted_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
		);

		if ( false === $result ) {
			wp_delete_attachment( $attachment_id, true );
			wsf_ajax_error( __( 'ذخیره اطلاعات با خطا مواجه شد.', 'webisoft-school-forms' ) );
		}

		wsf_ajax_success( __( 'رزومه شما با موفقیت ارسال شد. با تشکر از شما.', 'webisoft-school-forms' ) );
	}
}
