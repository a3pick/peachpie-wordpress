<?php
defined( 'ABSPATH' ) || exit;

/**
 * ماژول «مشاوره تحصیلی میخوام» — فرم دومرحله‌ای: جدول مقایسه‌ی ۴ طرح (در موبایل: کارت) و سپس مشخصات متقاضی.
 */
class WSF_Consulting_Module {

	const ID = 'consulting';

	public function register() {
		add_action( 'wp_ajax_wsf_submit_consulting', array( $this, 'handle_submit' ) );
		add_action( 'wp_ajax_nopriv_wsf_submit_consulting', array( $this, 'handle_submit' ) );
	}

	public function register_elementor_widget( $widgets_manager ) {
		require_once __DIR__ . '/elementor/class-widget-consulting.php';
		$widgets_manager->register( new WSF_Widget_Consulting() );
	}

	public function register_settings() {
		$keys = array(
			'button_text', 'plans_title', 'plans_desc', 'plans_footnote', 'semi_group_label',
			'select_btn_text', 'card_btn_text', 'features_matrix', 'featured_plan', 'featured_label', 'merge_common', 'common_label', 'mobile_visible_rows', 'font', 'accent_color',
			'education_options', 'major_options',
		);
		foreach ( $keys as $key ) {
			register_setting( 'wsf_settings_group', "wsf_consulting_{$key}" );
		}
		for ( $i = 1; $i <= 4; $i++ ) {
			foreach ( array( 'label', 'short', 'badge', 'price' ) as $field ) {
				register_setting( 'wsf_settings_group', "wsf_consulting_p{$i}_{$field}" );
			}
		}
	}

	public function get_education_options() {
		$raw = get_option( 'wsf_consulting_education_options', 'نهم,دهم,یازدهم,دوازدهم,فارغ التحصیل (پشت کنکوری)' );
		return array_filter( array_map( 'trim', explode( ',', $raw ) ) );
	}

	public function get_major_options() {
		$raw = get_option( 'wsf_consulting_major_options', 'ریاضی فیزیک,علوم تجربی,علوم انسانی,هنر,زبان,فنی و حرفه ای / کاردانش' );
		return array_filter( array_map( 'trim', explode( ',', $raw ) ) );
	}

	public function default_features_matrix() {
		return "جلسات | ۴ جلسه تلفنی | ۲ جلسه تلفنی و ۲ جلسه حضوری | ۱ تلفنی و ۲ حضوری + ۱ حضوری (مرادی) | هر هفته حضوری\n"
			. "برنامه شخصی | هفتگی | هفتگی | هفتگی | هفتگی\n"
			. "گزارش کار | هر شب پیام | هر شب پیام | هر شب پیام | هر شب پیام\n"
			. "پیگیری | تماس هفته‌ای ۱ بار | تماس هفته‌ای ۱ بار | تماس هفته‌ای ۱ بار | تماس هفته‌ای ۱ بار\n"
			. "آزمون شخصی | ماهی ۱ بار | ماهی ۲ بار | ماهی ۳ بار | هر هفته\n"
			. "کارگاه مشاوره | دارد | دارد | دارد | دارد\n"
			. "رفع اشکال دروس | ندارد | دارد | دارد | دارد\n"
			. "تحلیل آزمون | آنلاین | حضوری | حضوری | حضوری\n"
			. "طرح منتا | ندارد | در طرح سالانه دارد | در طرح سالانه دارد | در طرح سالانه دارد";
	}

	/**
	 * ردیف‌های جدول مقایسه: هر خط «نام ویژگی | طرح۱ | طرح۲ | طرح۳ | طرح۴».
	 *
	 * @return array<int,string[]>
	 */
	public function get_feature_rows() {
		$matrix = get_option( 'wsf_consulting_features_matrix', '' );
		if ( '' === trim( (string) $matrix ) ) {
			$matrix = $this->default_features_matrix();
		}
		$rows = array();
		foreach ( explode( "\n", trim( $matrix ) ) as $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			$rows[] = array_pad( array_map( 'trim', explode( '|', $line ) ), 5, '-' );
		}
		return $rows;
	}

	private function plan_defaults() {
		return array(
			1 => array( 'label' => 'آنلاین', 'short' => 'آنلاین', 'badge' => 'Online', 'price' => '۳.۸ میلیون', 'attendance' => 'آنلاین', 'badge_class' => 'online' ),
			2 => array( 'label' => 'نیمه حضوری - پشتیبان', 'short' => 'پشتیبان', 'badge' => 'Standard', 'price' => '۶.۸ میلیون', 'attendance' => 'حضوری', 'badge_class' => 'support' ),
			3 => array( 'label' => 'نیمه حضوری - پشتیبان و مرادی', 'short' => 'پشتیبان و مرادی', 'badge' => 'Premium', 'price' => '۸ میلیون', 'attendance' => 'حضوری', 'badge_class' => 'premium' ),
			4 => array( 'label' => 'حضوری VIP - مرادی', 'short' => 'حضوری VIP', 'badge' => 'مرادی', 'price' => '۱۲ میلیون', 'attendance' => 'حضوری', 'badge_class' => 'vip' ),
		);
	}

	/**
	 * چهار طرح ثابت (ساختار جدول ثابت است)؛ عنوان/نشان/قیمت قابل ویرایش.
	 * مقدار label همان چیزی است که در ستون «طرح انتخابی» ذخیره می‌شود.
	 */
	public function get_plans() {
		$plans = array();
		foreach ( $this->plan_defaults() as $i => $default ) {
			$plan = $default;
			foreach ( array( 'label', 'short', 'badge', 'price' ) as $field ) {
				$val = get_option( "wsf_consulting_p{$i}_{$field}", '' );
				if ( '' !== trim( (string) $val ) ) {
					$plan[ $field ] = $val;
					if ( 'price' === $field ) {
						// قیمت‌های ذخیره‌شده‌ی قبلی با پسوند «م» هم کامل نوشته شوند.
						$plan['price'] = preg_replace( '/\s*م$/u', ' میلیون', trim( $val ) );
					}
				}
			}
			$plans[ $i ] = $plan;
		}
		return $plans;
	}

	/* ---------------------------------------------------------------
	 * تنظیمات
	 * --------------------------------------------------------------- */
	public function render_settings_fields() {
		$opt = function ( $key, $default ) {
			return get_option( "wsf_consulting_{$key}", $default );
		};
		$font      = get_option( 'wsf_consulting_font', '' );
		$accent    = get_option( 'wsf_consulting_accent_color', '' );
		$education = $opt( 'education_options', 'نهم,دهم,یازدهم,دوازدهم,فارغ التحصیل (پشت کنکوری)' );
		$majors    = $opt( 'major_options', 'ریاضی فیزیک,علوم تجربی,علوم انسانی,هنر,زبان,فنی و حرفه ای / کاردانش' );
		$matrix    = get_option( 'wsf_consulting_features_matrix', '' );
		if ( '' === trim( (string) $matrix ) ) {
			$matrix = $this->default_features_matrix();
		}
		$plans = $this->get_plans();
		$fonts = wsf_get_elementor_fonts();
		?>
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'متن دکمه', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="regular-text" name="wsf_consulting_button_text" value="<?php echo esc_attr( $opt( 'button_text', 'مشاوره تحصیلی میخوام' ) ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'عنوان مرحله‌ی طرح‌ها', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="regular-text" name="wsf_consulting_plans_title" value="<?php echo esc_attr( $opt( 'plans_title', 'طرح‌های مشاوره' ) ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'توضیح مرحله‌ی طرح‌ها', 'webisoft-school-forms' ); ?></th>
				<td><textarea name="wsf_consulting_plans_desc" rows="2" class="large-text"><?php echo esc_textarea( $opt( 'plans_desc', 'طرح مورد نظرتان را انتخاب کنید تا فرم رزرو باز شود.' ) ); ?></textarea></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'تیتر گروه ستون‌های نیمه‌حضوری', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="regular-text" name="wsf_consulting_semi_group_label" value="<?php echo esc_attr( $opt( 'semi_group_label', 'نیمه حضوری' ) ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'متن دکمه‌ی انتخاب (جدول دسکتاپ / کارت موبایل)', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="text" class="regular-text" name="wsf_consulting_select_btn_text" value="<?php echo esc_attr( $opt( 'select_btn_text', 'انتخاب طرح' ) ); ?>">
					<input type="text" class="regular-text" name="wsf_consulting_card_btn_text" value="<?php echo esc_attr( $opt( 'card_btn_text', 'انتخاب این طرح' ) ); ?>">
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'یادداشت زیر جدول', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="large-text" name="wsf_consulting_plans_footnote" value="<?php echo esc_attr( $opt( 'plans_footnote', '* تمامی قیمت‌ها به میلیون تومان است.' ) ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'طرح پیشنهادی (هایلایت‌شده)', 'webisoft-school-forms' ); ?></th>
				<td>
					<select name="wsf_consulting_featured_plan">
						<option value="0"><?php esc_html_e( '— هیچ‌کدام —', 'webisoft-school-forms' ); ?></option>
						<?php foreach ( $plans as $i => $plan ) : ?>
							<option value="<?php echo (int) $i; ?>" <?php selected( (int) $opt( 'featured_plan', 0 ), $i ); ?>><?php echo esc_html( $plan['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
					<input type="text" class="regular-text" name="wsf_consulting_featured_label" value="<?php echo esc_attr( $opt( 'featured_label', 'پرطرفدار' ) ); ?>" placeholder="<?php esc_attr_e( 'برچسب، مثلاً پرطرفدار', 'webisoft-school-forms' ); ?>">
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'ردیف‌های مشترک در یک نوار', 'webisoft-school-forms' ); ?></th>
				<td>
					<label><input type="checkbox" name="wsf_consulting_merge_common" value="1" <?php checked( (int) $opt( 'merge_common', 0 ) ); ?>> <?php esc_html_e( 'ویژگی‌هایی که در هر ۴ طرح یکسان‌اند از جدول حذف و در یک نوار بالای آن نمایش داده شوند', 'webisoft-school-forms' ); ?></label><br>
					<input type="text" class="regular-text" name="wsf_consulting_common_label" value="<?php echo esc_attr( $opt( 'common_label', 'در همه‌ی طرح‌ها' ) ); ?>">
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'تعداد ویژگی‌های قابل‌مشاهده در کارت موبایل', 'webisoft-school-forms' ); ?></th>
				<td><input type="number" min="1" max="20" style="width:80px;" name="wsf_consulting_mobile_visible_rows" value="<?php echo esc_attr( (int) $opt( 'mobile_visible_rows', 4 ) ); ?>"><p class="description"><?php esc_html_e( 'بقیه‌ی ویژگی‌ها پشت دکمه‌ی «مشاهده‌ی ویژگی‌های بیشتر» قرار می‌گیرند.', 'webisoft-school-forms' ); ?></p></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'گزینه‌های مقطع تحصیلی', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="large-text" name="wsf_consulting_education_options" value="<?php echo esc_attr( $education ); ?>" dir="rtl"><p class="description"><?php esc_html_e( 'با ویرگول جدا کنید.', 'webisoft-school-forms' ); ?></p></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'گزینه‌های رشته تحصیلی', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="large-text" name="wsf_consulting_major_options" value="<?php echo esc_attr( $majors ); ?>" dir="rtl"><p class="description"><?php esc_html_e( 'با ویرگول جدا کنید.', 'webisoft-school-forms' ); ?></p></td>
			</tr>
		</table>

		<h3><?php esc_html_e( 'چهار طرح مشاوره (ستون‌های جدول)', 'webisoft-school-forms' ); ?></h3>
		<p class="description"><?php esc_html_e( 'ساختار جدول ثابت است (آنلاین | دو ستون نیمه‌حضوری | VIP) ولی عنوان‌ها، نشان‌ها و قیمت‌ها قابل ویرایش‌اند. «عنوان کامل» همان چیزی است که در لیست رزروها ذخیره می‌شود.', 'webisoft-school-forms' ); ?></p>
		<table class="form-table">
			<?php foreach ( $plans as $i => $plan ) : ?>
				<tr>
					<th><?php printf( esc_html__( 'طرح %d', 'webisoft-school-forms' ), $i ); ?></th>
					<td>
						<div style="display:flex; gap:12px; flex-wrap:wrap;">
							<label><?php esc_html_e( 'عنوان کامل', 'webisoft-school-forms' ); ?><br><input type="text" name="wsf_consulting_p<?php echo (int) $i; ?>_label" value="<?php echo esc_attr( $plan['label'] ); ?>" style="width:230px;"></label>
							<label><?php esc_html_e( 'عنوان کوتاه ستون', 'webisoft-school-forms' ); ?><br><input type="text" name="wsf_consulting_p<?php echo (int) $i; ?>_short" value="<?php echo esc_attr( $plan['short'] ); ?>" style="width:150px;"></label>
							<label><?php esc_html_e( 'نشان', 'webisoft-school-forms' ); ?><br><input type="text" name="wsf_consulting_p<?php echo (int) $i; ?>_badge" value="<?php echo esc_attr( $plan['badge'] ); ?>" style="width:110px;"></label>
							<label><?php esc_html_e( 'قیمت', 'webisoft-school-forms' ); ?><br><input type="text" name="wsf_consulting_p<?php echo (int) $i; ?>_price" value="<?php echo esc_attr( $plan['price'] ); ?>" style="width:110px;"></label>
						</div>
					</td>
				</tr>
			<?php endforeach; ?>
			<tr>
				<th><?php esc_html_e( 'جدول مقایسه‌ی ویژگی‌ها', 'webisoft-school-forms' ); ?></th>
				<td>
					<p class="description"><?php echo wp_kses( __( 'هر خط یک ویژگی است؛ مقادیر را با <code>|</code> جدا کنید. ترتیب: <strong>نام ویژگی | طرح ۱ | طرح ۲ | طرح ۳ | طرح ۴</strong>. مقدارهایی که «ندارد» دارند قرمز و «دارد» دارند سبز نمایش داده می‌شوند.', 'webisoft-school-forms' ), array( 'code' => array(), 'strong' => array() ) ); ?></p>
					<textarea name="wsf_consulting_features_matrix" rows="12" class="large-text" style="direction:rtl; text-align:right; line-height:1.6;"><?php echo esc_textarea( $matrix ); ?></textarea>
				</td>
			</tr>
		</table>

		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'رنگ برند اختصاصی این فرم', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="text" class="wsf-color-picker" name="wsf_consulting_accent_color" value="<?php echo esc_attr( $accent ); ?>" dir="ltr">
					<p class="description"><?php esc_html_e( 'خالی بگذارید تا رنگ برند عمومی استفاده شود.', 'webisoft-school-forms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'فونت اختصاصی این فرم', 'webisoft-school-forms' ); ?></th>
				<td>
					<select name="wsf_consulting_font" style="min-width:25em;">
						<option value=""><?php esc_html_e( '— پیش‌فرض عمومی —', 'webisoft-school-forms' ); ?></option>
						<option value="Tahoma, sans-serif" <?php selected( $font, 'Tahoma, sans-serif' ); ?>>Tahoma</option>
						<?php foreach ( $fonts as $f ) : ?>
							<option value="<?php echo esc_attr( $f ); ?>" <?php selected( $font, $f ); ?>><?php echo esc_html( $f ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</table>
		<?php
	}

	/* ---------------------------------------------------------------
	 * لیست ثبت‌نام‌ها
	 * --------------------------------------------------------------- */
	public function render_submissions_page() {
		// برچسب‌های قدیمی (مهندس مرادی/ترکیبی/منتور) می‌مانند تا رکوردهای قبلی قابل فیلتر باشند.
		$plans = array_values( array_unique( array_merge( array_values( wp_list_pluck( $this->get_plans(), 'label' ) ), array( 'مهندس مرادی', 'ترکیبی', 'منتور' ) ) ) );
		$list = new WSF_Submissions_List(
			array(
				'table'               => wsf_table( 'consulting' ),
				'page_slug'           => 'wsf-consulting',
				'title'               => __( 'مدیریت رزروهای مشاوره', 'webisoft-school-forms' ),
				'icon'                => '🎓',
				'columns'             => array(
					'first_name'      => __( 'نام', 'webisoft-school-forms' ),
					'last_name'       => __( 'نام خانوادگی', 'webisoft-school-forms' ),
					'phone'           => __( 'شماره تماس', 'webisoft-school-forms' ),
					'attendance_type' => __( 'نحوه برگزاری', 'webisoft-school-forms' ),
					'plan_type'       => __( 'طرح انتخابی', 'webisoft-school-forms' ),
					'education_level' => __( 'مقطع', 'webisoft-school-forms' ),
					'major'           => __( 'رشته', 'webisoft-school-forms' ),
				),
				'filters'             => array(
					'first_name'      => array( 'label' => __( 'نام', 'webisoft-school-forms' ), 'type' => 'text' ),
					'last_name'       => array( 'label' => __( 'نام خانوادگی', 'webisoft-school-forms' ), 'type' => 'text' ),
					'phone'           => array( 'label' => __( 'شماره تماس', 'webisoft-school-forms' ), 'type' => 'text' ),
					'attendance_type' => array( 'label' => __( 'نحوه برگزاری', 'webisoft-school-forms' ), 'type' => 'select', 'options' => array( 'حضوری', 'آنلاین' ) ),
					'plan_type'       => array( 'label' => __( 'طرح', 'webisoft-school-forms' ), 'type' => 'select', 'options' => $plans ),
				),
				'csv_action'          => 'wsf_export_consulting_csv',
				'csv_filename_prefix' => 'consulting-submissions',
				'nonce_prefix'        => 'wsf_consulting',
			)
		);
		$list->render();
	}

	/* ---------------------------------------------------------------
	 * AJAX
	 * --------------------------------------------------------------- */
	public function handle_submit() {
		check_ajax_referer( 'wsf_submit_consulting', 'wsf_nonce' );

		$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
		$last_name  = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
		$phone      = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$edu_level  = isset( $_POST['education_level'] ) ? sanitize_text_field( wp_unslash( $_POST['education_level'] ) ) : '';
		$major      = isset( $_POST['major'] ) ? sanitize_text_field( wp_unslash( $_POST['major'] ) ) : '';
		$attendance = isset( $_POST['attendance_type'] ) ? sanitize_text_field( wp_unslash( $_POST['attendance_type'] ) ) : '';
		$plan       = isset( $_POST['plan_type'] ) ? sanitize_text_field( wp_unslash( $_POST['plan_type'] ) ) : '';

		if ( ! $first_name || ! $last_name || ! $phone || ! $edu_level || ! $major || ! $attendance || ! $plan ) {
			wsf_ajax_error( __( 'لطفاً تمام فیلدهای الزامی را تکمیل کنید.', 'webisoft-school-forms' ) );
		}

		if ( ! in_array( $attendance, array( 'حضوری', 'آنلاین' ), true ) ) {
			wsf_ajax_error( __( 'نوع برگزاری نامعتبر است.', 'webisoft-school-forms' ) );
		}

		$phone_clean = wsf_clean_phone( $phone );
		if ( strlen( $phone_clean ) < 8 ) {
			wsf_ajax_error( __( 'شماره تماس وارد شده معتبر نیست.', 'webisoft-school-forms' ) );
		}

		global $wpdb;
		$result = $wpdb->insert(
			wsf_table( 'consulting' ),
			array(
				'first_name'      => $first_name,
				'last_name'       => $last_name,
				'phone'           => $phone_clean,
				'education_level' => $edu_level,
				'major'           => $major,
				'attendance_type' => $attendance,
				'plan_type'       => $plan,
				'submitted_at'    => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $result ) {
			wsf_ajax_error( __( 'ذخیره اطلاعات با خطا مواجه شد.', 'webisoft-school-forms' ) );
		}

		wsf_ajax_success( __( 'رزرو شما با موفقیت ثبت شد. با تشکر.', 'webisoft-school-forms' ) );
	}
}
