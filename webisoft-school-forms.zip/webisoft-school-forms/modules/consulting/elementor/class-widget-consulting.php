<?php
defined( 'ABSPATH' ) || exit;

class WSF_Widget_Consulting extends \Elementor\Widget_Base {

	use WSF_Elementor_Widget_Trait;

	public function get_name() { return 'wsf-consulting'; }
	public function get_title() { return __( 'Webisoft: فرم مشاوره تحصیلی', 'webisoft-school-forms' ); }
	public function get_icon() { return 'eicon-form-horizontal'; }

	public function get_style_depends() { return array( 'wsf-frontend' ); }
	public function get_script_depends() { return array( 'wsf-frontend' ); }

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array( 'label' => __( 'محتوا', 'webisoft-school-forms' ) ) );

		$this->add_control(
			'button_text',
			array(
				'label'       => __( 'متن دکمه', 'webisoft-school-forms' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => get_option( 'wsf_consulting_button_text', 'مشاوره تحصیلی میخوام' ),
				'description' => __( 'خالی بگذارید تا متن تنظیم‌شده در «تنظیمات فرم‌ها» استفاده شود.', 'webisoft-school-forms' ),
			)
		);

		$this->add_wsf_popup_id_control();

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', array( 'label' => __( 'ظاهر', 'webisoft-school-forms' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_wsf_css_var_color_control( 'accent_color', 'wsf-accent', __( 'رنگ برند (این نمونه)', 'webisoft-school-forms' ) );
		$this->add_wsf_typography_control( 'button_typography', '{{WRAPPER}} .wsf-trigger-btn', __( 'تایپوگرافی دکمه', 'webisoft-school-forms' ) );
		$this->add_wsf_corner_radius_control( 'trigger_radius', 'wsf-trigger-radius', __( 'گردی گوشه‌های دکمه‌ی اصلی', 'webisoft-school-forms' ) );
		$this->add_wsf_radius_control( 'modal_radius', 'wsf-radius', __( 'گردی گوشه‌های مودال', 'webisoft-school-forms' ), 14 );
		$this->end_controls_section();
	}

	/** کلاس رنگی سلول جدول/آیکن کارت بر اساس متن: «ندارد» قرمز، «دارد» سبز. */
	private function cell_state( $text ) {
		if ( false !== strpos( $text, 'ندارد' ) ) {
			return 'no';
		}
		if ( false !== strpos( $text, 'دارد' ) ) {
			return 'yes';
		}
		return '';
	}

	/** وضعیت آیکن در کارت موبایل: ✅ مثبت، ❌ منفی، ⚠️ سایر. */
	private function card_state( $text ) {
		if ( false !== strpos( $text, 'ندارد' ) ) {
			return array( '❌', 'no' );
		}
		if ( false !== strpos( $text, 'دارد' ) || false !== strpos( $text, 'تلفنی' ) || false !== strpos( $text, 'هفتگی' ) ) {
			return array( '✅', 'yes' );
		}
		return array( '⚠️', 'warn' );
	}

	protected function render() {
		$settings   = $this->get_settings_for_display();
		$uid        = 'wsf-consulting-' . $this->get_id();
		$opt        = function ( $key, $default ) {
			return get_option( "wsf_consulting_{$key}", $default );
		};
		$button_txt = $settings['button_text'] ?: $opt( 'button_text', 'مشاوره تحصیلی میخوام' );
		$plans_title = $opt( 'plans_title', 'طرح‌های مشاوره' );
		$plans_desc  = $opt( 'plans_desc', 'طرح مورد نظرتان را انتخاب کنید تا فرم رزرو باز شود.' );
		$footnote    = $opt( 'plans_footnote', '* تمامی قیمت‌ها به میلیون تومان است.' );
		$semi_label  = $opt( 'semi_group_label', 'نیمه حضوری' );
		$select_btn  = $opt( 'select_btn_text', 'انتخاب طرح' );
		$card_btn    = $opt( 'card_btn_text', 'انتخاب این طرح' );

		$module    = wsf()->consulting;
		$plans     = $module->get_plans();
		$features  = $module->get_feature_rows();
		$education = $module->get_education_options();
		$majors    = $module->get_major_options();

		$featured     = (int) $opt( 'featured_plan', 0 );
		$feat_label   = $opt( 'featured_label', 'پرطرفدار' );
		$common_label = $opt( 'common_label', 'در همه‌ی طرح‌ها' );
		$merge        = (bool) $opt( 'merge_common', 0 );

		// ردیفی که مقدارش در هر ۴ طرح یکی و مثبت است به نوار «در همه‌ی طرح‌ها» می‌رود.
		$common = array();
		$rows   = array();
		foreach ( $features as $row ) {
			$vals = array_slice( $row, 1, 4 );
			if ( $merge && 1 === count( array_unique( $vals ) ) && '' !== $vals[0] && '-' !== $vals[0] && false === strpos( $vals[0], 'ندارد' ) ) {
				$common[] = $row;
			} else {
				$rows[] = $row;
			}
		}

		$visible_rows = max( 1, (int) $opt( 'mobile_visible_rows', 4 ) );

		$mark = function ( $text ) {
			$text = trim( $text );
			if ( 'دارد' === $text ) {
				return '<span class="wsf-mark wsf-mark-yes" title="دارد">✓</span>';
			}
			if ( 'ندارد' === $text ) {
				return '<span class="wsf-mark wsf-mark-no" title="ندارد">✕</span>';
			}
			return esc_html( $text );
		};

		$fill = function ( $plan ) {
			return wp_json_encode( array( 'attendance_type' => $plan['attendance'], 'plan_type' => $plan['label'] ), JSON_UNESCAPED_UNICODE );
		};
		?>
		<div class="wsf-widget"<?php echo $this->get_wsf_popup_id_attr( $settings ); // phpcs:ignore -- escaped in helper ?> data-wsf-module="consulting" id="<?php echo esc_attr( $uid ); ?>">
			<button type="button" class="wsf-trigger-btn" data-wsf-open><?php echo esc_html( $button_txt ); ?></button>

			<div class="wsf-modal" id="<?php echo esc_attr( $uid ); ?>-modal" aria-hidden="true">
				<div class="wsf-overlay"></div>
				<div class="wsf-modal-content wsf-modal-wide">
					<button type="button" class="wsf-close" aria-label="<?php esc_attr_e( 'بستن', 'webisoft-school-forms' ); ?>">×</button>

					<form class="wsf-form" data-wsf-action="wsf_submit_consulting" data-wsf-close-on-success="1">
						<?php wp_nonce_field( 'wsf_submit_consulting', 'wsf_nonce' ); ?>
						<input type="hidden" name="attendance_type" value="">
						<input type="hidden" name="plan_type" value="">

						<div class="wsf-step wsf-step-active" data-step="0">
							<h2 class="wsf-form-title"><?php echo esc_html( $plans_title ); ?></h2>
							<p class="wsf-form-desc"><?php echo nl2br( esc_html( $plans_desc ) ); ?></p>

							<?php if ( $common ) : ?>
								<div class="wsf-common-strip">
									<strong><?php echo esc_html( $common_label ); ?>:</strong>
									<?php foreach ( $common as $row ) : ?>
										<span class="wsf-chip">
											<?php if ( 'دارد' === trim( $row[1] ) ) : ?>
												<span class="wsf-mark wsf-mark-yes">✓</span> <?php echo esc_html( $row[0] ); ?>
											<?php else : ?>
												<?php echo esc_html( $row[0] ); ?>: <b><?php echo esc_html( $row[1] ); ?></b>
											<?php endif; ?>
										</span>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>

							<div class="wsf-plan-table-wrap" tabindex="0">
								<table class="wsf-plan-table">
									<thead>
										<tr>
											<th class="wsf-plan-service-head"><?php esc_html_e( 'تفاوت طرح‌ها', 'webisoft-school-forms' ); ?></th>
											<?php foreach ( $plans as $i => $p ) : ?>
												<th data-col="<?php echo (int) $i; ?>" class="<?php echo $featured === $i ? 'wsf-featured' : ''; ?>">
													<div class="wsf-plan-head">
														<span class="wsf-featured-tag"><?php echo $featured === $i ? esc_html( $feat_label ) : ''; ?></span>
														<span class="wsf-plan-kicker"><?php echo in_array( $i, array( 2, 3 ), true ) ? esc_html( $semi_label ) : ''; ?></span>
														<span class="wsf-plan-name"><?php echo esc_html( $p['short'] ); ?></span>
														<small class="wsf-badge wsf-badge-<?php echo esc_attr( $p['badge_class'] ); ?>"><?php echo esc_html( $p['badge'] ); ?></small>
														<span class="wsf-plan-price"><?php echo esc_html( $p['price'] ); ?></span>
														<button type="button" class="wsf-plan-select" data-wsf-next="1" data-wsf-fill="<?php echo esc_attr( $fill( $p ) ); ?>"><?php echo esc_html( $select_btn ); ?></button>
													</div>
												</th>
											<?php endforeach; ?>
										</tr>
									</thead>
									<tbody>
										<?php foreach ( $rows as $row ) : ?>
											<tr>
												<th><?php echo esc_html( $row[0] ); ?></th>
												<?php for ( $c = 1; $c <= 4; $c++ ) : ?>
													<td data-col="<?php echo (int) $c; ?>" class="<?php echo esc_attr( trim( ( $this->cell_state( $row[ $c ] ) ? 'wsf-' . $this->cell_state( $row[ $c ] ) : '' ) . ( $featured === $c ? ' wsf-featured' : '' ) ) ); ?>"><?php echo $mark( $row[ $c ] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
												<?php endfor; ?>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
							</div>

							<div class="wsf-plan-cards">
								<?php foreach ( $plans as $col => $p ) : ?>
									<div class="wsf-plan-card<?php echo $featured === $col ? ' wsf-featured' : ''; ?>">
										<?php if ( $featured === $col ) : ?><span class="wsf-featured-tag"><?php echo esc_html( $feat_label ); ?></span><?php endif; ?>
										<div class="wsf-plan-card-top">
											<div>
												<div class="wsf-plan-card-name"><?php echo esc_html( $p['label'] ); ?></div>
												<small class="wsf-badge wsf-badge-<?php echo esc_attr( $p['badge_class'] ); ?>"><?php echo esc_html( $p['badge'] ); ?></small>
											</div>
											<div class="wsf-plan-card-price"><?php echo esc_html( $p['price'] ); ?></div>
										</div>
										<ul class="wsf-plan-card-features">
											<?php foreach ( $features as $n => $row ) : list( $icon, $state ) = $this->card_state( $row[ $col ] ); ?>
												<li<?php echo $n >= $visible_rows ? ' class="wsf-more"' : ''; ?>>
													<span class="wsf-plan-card-icon wsf-icon-<?php echo esc_attr( $state ); ?>"><?php echo esc_html( $icon ); ?></span>
													<span><strong><?php echo esc_html( $row[0] ); ?>:</strong> <?php echo esc_html( $row[ $col ] ); ?></span>
												</li>
											<?php endforeach; ?>
										</ul>
										<?php if ( count( $features ) > $visible_rows ) : ?>
											<button type="button" class="wsf-more-btn" data-wsf-more data-more="<?php esc_attr_e( 'مشاهده‌ی ویژگی‌های بیشتر', 'webisoft-school-forms' ); ?>" data-less="<?php esc_attr_e( 'نمایش کمتر', 'webisoft-school-forms' ); ?>"><span class="wsf-more-label"><?php esc_html_e( 'مشاهده‌ی ویژگی‌های بیشتر', 'webisoft-school-forms' ); ?></span><span class="wsf-more-arrow" aria-hidden="true"></span></button>
										<?php endif; ?>
										<button type="button" class="wsf-btn" data-wsf-next="1" data-wsf-fill="<?php echo esc_attr( $fill( $p ) ); ?>"><?php echo esc_html( $card_btn ); ?></button>
									</div>
								<?php endforeach; ?>
							</div>

							<?php if ( $footnote ) : ?>
								<p class="wsf-plan-footnote"><?php echo esc_html( $footnote ); ?></p>
							<?php endif; ?>
						</div>

						<div class="wsf-step" data-step="1">
							<h2 class="wsf-form-title"><?php esc_html_e( 'مشخصات شما', 'webisoft-school-forms' ); ?></h2>
							<p class="wsf-form-desc"><?php esc_html_e( 'جهت نهایی‌سازی، اطلاعات زیر را وارد کنید.', 'webisoft-school-forms' ); ?> <strong class="wsf-chosen-plan" data-wsf-chosen="plan_type"></strong></p>

							<div class="wsf-row">
								<div class="wsf-field">
									<label><?php esc_html_e( 'نام', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
									<input type="text" name="first_name" required>
								</div>
								<div class="wsf-field">
									<label><?php esc_html_e( 'نام خانوادگی', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
									<input type="text" name="last_name" required>
								</div>
							</div>

							<div class="wsf-field">
								<label><?php esc_html_e( 'شماره تماس', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
								<input type="tel" name="phone" required placeholder="09123456789" dir="ltr">
							</div>

							<div class="wsf-row">
								<div class="wsf-field">
									<label><?php esc_html_e( 'مقطع تحصیلی', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
									<select name="education_level" required>
										<option value=""><?php esc_html_e( 'انتخاب کنید', 'webisoft-school-forms' ); ?></option>
										<?php foreach ( $education as $o ) : ?>
											<option value="<?php echo esc_attr( $o ); ?>"><?php echo esc_html( $o ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="wsf-field">
									<label><?php esc_html_e( 'رشته تحصیلی', 'webisoft-school-forms' ); ?><span class="wsf-req">*</span></label>
									<select name="major" required>
										<option value=""><?php esc_html_e( 'انتخاب کنید', 'webisoft-school-forms' ); ?></option>
										<?php foreach ( $majors as $o ) : ?>
											<option value="<?php echo esc_attr( $o ); ?>"><?php echo esc_html( $o ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>

							<div class="wsf-message"></div>

							<div class="wsf-actions-row">
								<button type="button" class="wsf-btn wsf-btn-secondary" data-wsf-prev="0"><?php esc_html_e( 'بازگشت به طرح‌ها', 'webisoft-school-forms' ); ?></button>
								<button type="submit" class="wsf-btn">
									<span class="wsf-submit-text"><?php esc_html_e( 'ثبت نهایی', 'webisoft-school-forms' ); ?></span>
									<span class="wsf-loading-text"><?php esc_html_e( 'در حال ثبت...', 'webisoft-school-forms' ); ?></span>
								</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php
	}
}
