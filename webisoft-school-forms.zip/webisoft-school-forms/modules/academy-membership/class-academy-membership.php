<?php
defined( 'ABSPATH' ) || exit;

/**
 * ماژول «می‌خوام یکی از اعضای آکادمی باشم» — فرم تک‌مرحله‌ای عضویت دانش‌آموزی:
 * نام، نام خانوادگی، شماره تماس، مقطع، رشته. بدون آپلود فایل و بدون مرحله‌ی
 * انتخاب نوع حضور (برخلاف ماژول‌های دیگر).
 */
class WSF_Academy_Membership_Module {

	const ID = 'academy_membership';

	public function register() {
		add_action( 'wp_ajax_wsf_submit_academy_membership', array( $this, 'handle_submit' ) );
		add_action( 'wp_ajax_nopriv_wsf_submit_academy_membership', array( $this, 'handle_submit' ) );
	}

	public function register_elementor_widget( $widgets_manager ) {
		require_once __DIR__ . '/elementor/class-widget-academy-membership.php';
		$widgets_manager->register( new WSF_Widget_Academy_Membership() );
	}

	public function register_settings() {
		register_setting( 'wsf_settings_group', 'wsf_academy_membership_button_text' );
		register_setting( 'wsf_settings_group', 'wsf_academy_membership_font' );
		register_setting( 'wsf_settings_group', 'wsf_academy_membership_accent_color' );
		register_setting( 'wsf_settings_group', 'wsf_academy_membership_education_options' );
		register_setting( 'wsf_settings_group', 'wsf_academy_membership_major_options' );
	}

	public function get_education_options() {
		$raw = get_option( 'wsf_academy_membership_education_options', 'نهم,دهم,یازدهم,دوازدهم,فارغ التحصیل (پشت کنکوری)' );
		return array_filter( array_map( 'trim', explode( ',', $raw ) ) );
	}

	public function get_major_options() {
		$raw = get_option( 'wsf_academy_membership_major_options', 'ریاضی فیزیک,علوم تجربی,علوم انسانی,هنر,زبان,فنی و حرفه ای / کاردانش' );
		return array_filter( array_map( 'trim', explode( ',', $raw ) ) );
	}

	/* ---------------------------------------------------------------
	 * تنظیمات
	 * --------------------------------------------------------------- */
	public function render_settings_fields() {
		$button_text = get_option( 'wsf_academy_membership_button_text', 'میخوام یکی از اعضای آکادمی باشم' );
		$font        = get_option( 'wsf_academy_membership_font', '' );
		$accent      = get_option( 'wsf_academy_membership_accent_color', '' );
		$education   = get_option( 'wsf_academy_membership_education_options', 'نهم,دهم,یازدهم,دوازدهم,فارغ التحصیل (پشت کنکوری)' );
		$majors      = get_option( 'wsf_academy_membership_major_options', 'ریاضی فیزیک,علوم تجربی,علوم انسانی,هنر,زبان,فنی و حرفه ای / کاردانش' );
		$fonts       = wsf_get_elementor_fonts();
		?>
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'متن دکمه', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="regular-text" name="wsf_academy_membership_button_text" value="<?php echo esc_attr( $button_text ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'گزینه‌های مقطع تحصیلی', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="text" class="large-text" name="wsf_academy_membership_education_options" value="<?php echo esc_attr( $education ); ?>" dir="rtl">
					<p class="description"><?php esc_html_e( 'با ویرگول (,) از هم جدا کنید.', 'webisoft-school-forms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'گزینه‌های رشته تحصیلی', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="text" class="large-text" name="wsf_academy_membership_major_options" value="<?php echo esc_attr( $majors ); ?>" dir="rtl">
					<p class="description"><?php esc_html_e( 'با ویرگول (,) از هم جدا کنید.', 'webisoft-school-forms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'رنگ برند اختصاصی این فرم', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="text" class="wsf-color-picker" name="wsf_academy_membership_accent_color" value="<?php echo esc_attr( $accent ); ?>" dir="ltr">
					<p class="description"><?php esc_html_e( 'خالی بگذارید تا رنگ برند عمومی استفاده شود.', 'webisoft-school-forms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'فونت اختصاصی این فرم', 'webisoft-school-forms' ); ?></th>
				<td>
					<select name="wsf_academy_membership_font" style="min-width:25em;">
						<option value=""><?php esc_html_e( '— پیش‌فرض عمومی —', 'webisoft-school-forms' ); ?></option>
						<option value="Tahoma, sans-serif" <?php selected( $font, 'Tahoma, sans-serif' ); ?>>Tahoma</option>
						<?php foreach ( $fonts as $f ) : ?>
							<option value="<?php echo esc_attr( $f ); ?>" <?php selected( $font, $f ); ?>><?php echo esc_html( $f ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</table>
		<?php
	}

	/* ---------------------------------------------------------------
	 * لیست ثبت‌نام‌ها
	 * --------------------------------------------------------------- */
	public function render_submissions_page() {
		$list = new WSF_Submissions_List(
			array(
				'table'               => wsf_table( 'academy_membership' ),
				'page_slug'           => 'wsf-academy-membership',
				'title'               => __( 'مدیریت عضویت‌های آکادمی', 'webisoft-school-forms' ),
				'icon'                => '🎓',
				'columns'             => array(
					'first_name'      => __( 'نام', 'webisoft-school-forms' ),
					'last_name'       => __( 'نام خانوادگی', 'webisoft-school-forms' ),
					'phone'           => __( 'شماره تماس', 'webisoft-school-forms' ),
					'education_level' => __( 'مقطع', 'webisoft-school-forms' ),
					'major'           => __( 'رشته', 'webisoft-school-forms' ),
				),
				'filters'             => array(
					'first_name'      => array( 'label' => __( 'نام', 'webisoft-school-forms' ), 'type' => 'text' ),
					'last_name'       => array( 'label' => __( 'نام خانوادگی', 'webisoft-school-forms' ), 'type' => 'text' ),
					'phone'           => array( 'label' => __( 'شماره تماس', 'webisoft-school-forms' ), 'type' => 'text' ),
					'education_level' => array( 'label' => __( 'مقطع', 'webisoft-school-forms' ), 'type' => 'select', 'options' => $this->get_education_options() ),
					'major'           => array( 'label' => __( 'رشته', 'webisoft-school-forms' ), 'type' => 'select', 'options' => $this->get_major_options() ),
				),
				'csv_action'          => 'wsf_export_academy_membership_csv',
				'csv_filename_prefix' => 'academy-membership-submissions',
				'nonce_prefix'        => 'wsf_academy_membership',
			)
		);
		$list->render();
	}

	/* ---------------------------------------------------------------
	 * AJAX
	 * --------------------------------------------------------------- */
	public function handle_submit() {
		check_ajax_referer( 'wsf_submit_academy_membership', 'wsf_nonce' );

		$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
		$last_name  = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
		$phone      = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$edu_level  = isset( $_POST['education_level'] ) ? sanitize_text_field( wp_unslash( $_POST['education_level'] ) ) : '';
		$major      = isset( $_POST['major'] ) ? sanitize_text_field( wp_unslash( $_POST['major'] ) ) : '';

		if ( ! $first_name || ! $last_name || ! $phone || ! $edu_level || ! $major ) {
			wsf_ajax_error( __( 'لطفاً تمام فیلدهای الزامی را تکمیل کنید.', 'webisoft-school-forms' ) );
		}

		$phone_clean = wsf_clean_phone( $phone );
		if ( strlen( $phone_clean ) < 8 ) {
			wsf_ajax_error( __( 'شماره تماس وارد شده معتبر نیست.', 'webisoft-school-forms' ) );
		}

		global $wpdb;
		$result = $wpdb->insert(
			wsf_table( 'academy_membership' ),
			array(
				'first_name'      => $first_name,
				'last_name'       => $last_name,
				'phone'           => $phone_clean,
				'education_level' => $edu_level,
				'major'           => $major,
				'submitted_at'    => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $result ) {
			wsf_ajax_error( __( 'ذخیره اطلاعات با خطا مواجه شد.', 'webisoft-school-forms' ) );
		}

		wsf_ajax_success( __( 'درخواست عضویت شما با موفقیت ثبت شد. با تشکر.', 'webisoft-school-forms' ) );
	}
}
