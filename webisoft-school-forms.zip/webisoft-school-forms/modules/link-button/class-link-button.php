<?php
defined( 'ABSPATH' ) || exit;

/**
 * ماژول «دکمه لینک» — ساده‌ترین ویجت پلاگین: فقط یک متن و یک لینک، بدون
 * فرم/مودال/دیتابیس. کاملاً از همان تنظیمات سراسری ظاهر (رنگ/فونت/رادیوس)
 * پیروی می‌کند تا هم‌رنگ و هم‌شکل بقیه‌ی دکمه‌ها باشد؛ برای مواردی مثل
 * «مشکل استرس دارم» که فقط باید به یک صفحه/سایت دیگر لینک شود.
 */
class WSF_Link_Button_Module {

	const ID = 'link_button';

	public function register() {
		// بدون AJAX/دیتابیس — چیزی برای هوک‌کردن نیست.
	}

	public function register_settings() {
		// بدون تنظیمات اختصاصی — کاملاً از سبک سراسری پیروی می‌کند.
	}

	public function register_elementor_widget( $widgets_manager ) {
		require_once __DIR__ . '/elementor/class-widget-link-button.php';
		$widgets_manager->register( new WSF_Widget_Link_Button() );
	}
}
