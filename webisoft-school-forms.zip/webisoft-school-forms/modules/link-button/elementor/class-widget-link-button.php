<?php
defined( 'ABSPATH' ) || exit;

class WSF_Widget_Link_Button extends \Elementor\Widget_Base {

	use WSF_Elementor_Widget_Trait;

	public function get_name() { return 'wsf-link-button'; }
	public function get_title() { return __( 'Webisoft: دکمه لینک', 'webisoft-school-forms' ); }
	public function get_icon() { return 'eicon-button'; }

	public function get_style_depends() { return array( 'wsf-frontend' ); }

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array( 'label' => __( 'محتوا', 'webisoft-school-forms' ) ) );

		$this->add_control(
			'button_text',
			array(
				'label'   => __( 'متن دکمه', 'webisoft-school-forms' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'کلیک کنید', 'webisoft-school-forms' ),
			)
		);

		$this->add_control(
			'link',
			array(
				'label'       => __( 'لینک', 'webisoft-school-forms' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'webisoft-school-forms' ),
				'default'     => array( 'url' => '#' ),
				'show_external' => true,
			)
		);

		$this->add_control(
			'icon',
			array(
				'label'        => __( 'آیکون (اختیاری)', 'webisoft-school-forms' ),
				'type'         => \Elementor\Controls_Manager::ICONS,
				'skin'         => 'inline',
				'label_block'  => false,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', array( 'label' => __( 'ظاهر', 'webisoft-school-forms' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_wsf_css_var_color_control( 'accent_color', 'wsf-accent', __( 'رنگ برند (این نمونه)', 'webisoft-school-forms' ) );
		$this->add_wsf_typography_control( 'button_typography', '{{WRAPPER}} .wsf-trigger-btn', __( 'تایپوگرافی دکمه', 'webisoft-school-forms' ) );
		$this->add_wsf_corner_radius_control( 'trigger_radius', 'wsf-trigger-radius', __( 'گردی گوشه‌های دکمه', 'webisoft-school-forms' ) );
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$target = '';
		$rel    = '';
		if ( ! empty( $settings['link']['is_external'] ) ) {
			$target = ' target="_blank"';
		}
		if ( ! empty( $settings['link']['nofollow'] ) ) {
			$rel = ' rel="nofollow"';
		}
		$url = ! empty( $settings['link']['url'] ) ? $settings['link']['url'] : '#';
		?>
		<a
			href="<?php echo esc_url( $url ); ?>"<?php echo $target; // phpcs:ignore -- static string, no user input ?><?php echo $rel; // phpcs:ignore -- static string, no user input ?>
			class="wsf-widget wsf-trigger-btn"
			data-wsf-module="link_button"
		>
			<?php if ( ! empty( $settings['icon']['value'] ) ) : ?>
				<?php \Elementor\Icons_Manager::render_icon( $settings['icon'], array( 'aria-hidden' => 'true' ) ); ?>
			<?php endif; ?>
			<?php echo esc_html( $settings['button_text'] ); ?>
		</a>
		<?php
	}
}
