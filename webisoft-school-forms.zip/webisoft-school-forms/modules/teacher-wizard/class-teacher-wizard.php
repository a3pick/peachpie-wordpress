<?php
defined( 'ABSPATH' ) || exit;

/**
 * ماژول «ویزارد هوشمند» — فرم‌سازِ چندمرحله‌ایِ پویا، متصل به JetEngine/
 * JetSmartFilters، که کاربر را با کوئری‌استرینگ تکسونومی به یک صفحه‌ی
 * آرشیو هدایت می‌کند.
 *
 * برخلاف بقیه‌ی ماژول‌ها، اینجا یک ویجت المنتور با چند «ویزارد» مستقل کار
 * می‌کند: هر ویزارد (مراحل + پست‌تایپ هدف + آدرس آرشیو) یک پستِ از نوع CPT
 * اختصاصی wsf_wizard است — یعنی می‌شود چند سناریوی کاملاً جدا (مثلاً یکی
 * برای اساتید، یکی برای یک پست‌تایپ دیگر) ساخت و هرکدام را روی هر صفحه‌ای
 * با ویجت جدا (و انتخاب «کدام ویزارد» در تنظیمات همان ویجت) نمایش داد.
 */
class WSF_Teacher_Wizard_Module {

	const ID  = 'teacher_wizard';
	const CPT = 'wsf_wizard';

	public function register() {
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'save_post_' . self::CPT, array( $this, 'save_meta_box' ) );
		add_action( 'admin_init', array( $this, 'maybe_migrate_legacy_wizard' ) );

		add_action( 'wp_ajax_wsf_wizard_get_terms', array( $this, 'handle_get_terms' ) );
		add_action( 'wp_ajax_nopriv_wsf_wizard_get_terms', array( $this, 'handle_get_terms' ) );
		add_action( 'wp_ajax_wsf_wizard_save_log', array( $this, 'handle_save_log' ) );
		add_action( 'wp_ajax_nopriv_wsf_wizard_save_log', array( $this, 'handle_save_log' ) );

		add_action( 'admin_post_wsf_export_wizard_csv', array( $this, 'handle_csv_export' ) );
		add_action( 'admin_post_wsf_clear_wizard_logs', array( $this, 'handle_clear_logs' ) );
	}

	public function register_elementor_widget( $widgets_manager ) {
		require_once __DIR__ . '/elementor/class-widget-teacher-wizard.php';
		$widgets_manager->register( new WSF_Widget_Teacher_Wizard() );
	}

	public function register_settings() {
		register_setting( 'wsf_settings_group', 'wsf_wizard_button_text' );
		register_setting( 'wsf_settings_group', 'wsf_wizard_font' );
		register_setting( 'wsf_settings_group', 'wsf_wizard_accent_color' );
	}

	/* ---------------------------------------------------------------
	 * پست‌تایپ «ویزارد هوشمند»: هر پست = یک سناریوی مستقل (مراحل + پست‌تایپ
	 * هدف + آدرس آرشیو). از UI بومیِ وردپرس (لیست/افزودن/ویرایش/سطل زباله)
	 * به‌جای ساختن یک CRUD کاملاً دستی استفاده می‌کنیم.
	 * --------------------------------------------------------------- */
	public function register_post_type() {
		register_post_type(
			self::CPT,
			array(
				'labels'              => array(
					'name'               => __( 'ویزاردهای هوشمند', 'webisoft-school-forms' ),
					'singular_name'      => __( 'ویزارد هوشمند', 'webisoft-school-forms' ),
					'add_new'            => __( 'افزودن ویزارد جدید', 'webisoft-school-forms' ),
					'add_new_item'       => __( 'افزودن ویزارد جدید', 'webisoft-school-forms' ),
					'edit_item'          => __( 'ویرایش ویزارد', 'webisoft-school-forms' ),
					'new_item'           => __( 'ویزارد جدید', 'webisoft-school-forms' ),
					'view_item'          => __( 'مشاهده ویزارد', 'webisoft-school-forms' ),
					'search_items'       => __( 'جست‌وجوی ویزارد', 'webisoft-school-forms' ),
					'not_found'          => __( 'هیچ ویزاردی ساخته نشده — روی «افزودن ویزارد جدید» بزنید.', 'webisoft-school-forms' ),
					'not_found_in_trash' => __( 'ویزاردی در سطل زباله نیست.', 'webisoft-school-forms' ),
					'all_items'          => __( 'همه‌ی ویزاردها', 'webisoft-school-forms' ),
				),
				'public'               => false,
				'show_ui'              => true,
				'show_in_menu'         => 'wsf-dashboard',
				'show_in_admin_bar'    => false,
				'menu_icon'            => 'dashicons-networking',
				'supports'             => array( 'title' ),
				'capability_type'      => 'post',
				'map_meta_cap'         => true,
				'has_archive'          => false,
				'rewrite'              => false,
				'exclude_from_search'  => true,
				'publicly_queryable'   => false,
			)
		);
	}

	public function add_meta_box() {
		add_meta_box( 'wsf_wizard_builder', __( 'مراحل و تنظیمات این ویزارد', 'webisoft-school-forms' ), array( $this, 'render_meta_box' ), self::CPT, 'normal', 'high' );
	}

	public function render_meta_box( $post ) {
		wp_nonce_field( 'wsf_wizard_meta', 'wsf_wizard_meta_nonce' );

		global $wpdb;
		$filters = $wpdb->get_results(
			"SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type IN ('smart-filters','jet-smart-filters') AND post_status != 'trash'"
		);
		$filter_options = array();
		foreach ( (array) $filters as $f ) {
			$filter_options[] = array( 'id' => $f->ID, 'title' => $f->post_title );
		}

		$cpt_options = array();
		foreach ( get_post_types( array( 'public' => true, '_builtin' => false ), 'objects' ) as $pt ) {
			if ( ! in_array( $pt->name, array( 'elementor_library', 'smart-filters', 'jet-engine', 'jet-smart-filters', self::CPT ), true ) ) {
				$cpt_options[] = array( 'slug' => $pt->name, 'title' => $pt->label );
			}
		}

		$saved_steps = get_post_meta( $post->ID, '_wsf_steps', true );
		$saved_steps = $saved_steps ? $saved_steps : '[]';
		$target_cpt  = get_post_meta( $post->ID, '_wsf_target_cpt', true ) ?: 'teacher';
		$archive_url = get_post_meta( $post->ID, '_wsf_archive_url', true ) ?: site_url( '/' );
		?>
		<div class="wsf-a-grid" style="margin-bottom:18px;">
			<div class="wsf-a-form-group">
				<label><?php esc_html_e( 'پست‌تایپ پایه (جهت استخراج داده‌ها)', 'webisoft-school-forms' ); ?></label>
				<select name="wsf_target_cpt" class="wsf-a-form-control">
					<?php foreach ( $cpt_options as $cpt ) : ?>
						<option value="<?php echo esc_attr( $cpt['slug'] ); ?>" <?php selected( $target_cpt, $cpt['slug'] ); ?>><?php echo esc_html( $cpt['title'] ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="wsf-a-form-group">
				<label><?php esc_html_e( 'آدرس دقیق صفحه آرشیو', 'webisoft-school-forms' ); ?></label>
				<input type="text" name="wsf_archive_url" value="<?php echo esc_attr( $archive_url ); ?>" class="wsf-a-form-control" dir="ltr">
				<p class="wsf-a-hint"><?php esc_html_e( 'آدرس صفحه‌ای که با المنتور ساخته‌اید (مثلاً https://example.com/teachers/)', 'webisoft-school-forms' ); ?></p>
			</div>
		</div>

		<div class="wsf-a-card-head">
			<h3 style="margin:0;"><?php esc_html_e( 'مراحل ویزارد', 'webisoft-school-forms' ); ?></h3>
			<button type="button" class="wsf-a-btn wsf-a-btn-sm" id="wsf-wizard-add-step">+ <?php esc_html_e( 'افزودن مرحله', 'webisoft-school-forms' ); ?></button>
		</div>
		<input type="hidden" name="wsf_steps" id="wsf-wizard-builder-data" value="<?php echo esc_attr( $saved_steps ); ?>">
		<div id="wsf-wizard-builder-container"></div>
		<script>
			window.wsfWizardFilters = <?php echo wp_json_encode( $filter_options ); ?>;
		</script>
		<?php
	}

	public function save_meta_box( $post_id ) {
		if ( ! isset( $_POST['wsf_wizard_meta_nonce'] ) || ! wp_verify_nonce( wp_unslash( $_POST['wsf_wizard_meta_nonce'] ), 'wsf_wizard_meta' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		$steps_json = isset( $_POST['wsf_steps'] ) ? wp_unslash( $_POST['wsf_steps'] ) : '[]';
		json_decode( $steps_json );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			$steps_json = '[]';
		}
		update_post_meta( $post_id, '_wsf_steps', $steps_json );
		update_post_meta( $post_id, '_wsf_target_cpt', isset( $_POST['wsf_target_cpt'] ) ? sanitize_key( wp_unslash( $_POST['wsf_target_cpt'] ) ) : '' );
		update_post_meta( $post_id, '_wsf_archive_url', isset( $_POST['wsf_archive_url'] ) ? esc_url_raw( wp_unslash( $_POST['wsf_archive_url'] ) ) : '' );
	}

	/**
	 * اگر یک نسخه‌ی قدیمی (تک-ویزارد، مبتنی بر options) از قبل مراحلی ذخیره
	 * کرده بود، یک‌بار به‌صورت خودکار به یک پست wsf_wizard منتقلش می‌کنیم تا
	 * تنظیمات قبلی کاربر از بین نرود.
	 */
	public function maybe_migrate_legacy_wizard() {
		if ( get_option( 'wsf_wizard_migrated' ) ) {
			return;
		}
		$legacy_steps = get_option( 'wsf_wizard_builder_data', '' );
		if ( $legacy_steps && '[]' !== $legacy_steps ) {
			$id = wp_insert_post(
				array(
					'post_type'   => self::CPT,
					'post_title'  => __( 'ویزارد ۱ (منتقل‌شده از نسخه‌ی قبل)', 'webisoft-school-forms' ),
					'post_status' => 'publish',
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, '_wsf_steps', $legacy_steps );
				update_post_meta( $id, '_wsf_target_cpt', get_option( 'wsf_wizard_target_cpt', 'teacher' ) );
				update_post_meta( $id, '_wsf_archive_url', get_option( 'wsf_wizard_archive_url', site_url( '/' ) ) );
			}
		}
		update_option( 'wsf_wizard_migrated', 1 );
	}

	/**
	 * لیست ویزاردهای منتشرشده برای پر کردن کنترل «کدام ویزارد» در ویجت المنتور.
	 *
	 * @return array<int,string> [post_id => عنوان]
	 */
	public function get_wizard_options() {
		$posts = get_posts(
			array(
				'post_type'      => self::CPT,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		$options = array();
		foreach ( $posts as $p ) {
			$options[ $p->ID ] = $p->post_title;
		}
		return $options;
	}

	/**
	 * داده‌ی کامل یک ویزارد مشخص (مراحل + پست‌تایپ هدف + آدرس آرشیو).
	 *
	 * @return array{steps:array,target_cpt:string,archive_url:string}|null
	 */
	public function get_wizard( $wizard_id ) {
		$wizard_id = intval( $wizard_id );
		if ( ! $wizard_id || get_post_type( $wizard_id ) !== self::CPT ) {
			return null;
		}
		$steps = json_decode( get_post_meta( $wizard_id, '_wsf_steps', true ), true );
		return array(
			'steps'       => is_array( $steps ) ? $steps : array(),
			'target_cpt'  => get_post_meta( $wizard_id, '_wsf_target_cpt', true ) ?: 'teacher',
			'archive_url' => get_post_meta( $wizard_id, '_wsf_archive_url', true ) ?: site_url( '/' ),
		);
	}

	/* ---------------------------------------------------------------
	 * تب «ویزارد هوشمند» در تنظیمات فرم‌ها (فقط ظاهر؛ ساختار مراحل داخل
	 * خودِ هر پست wsf_wizard است)
	 * --------------------------------------------------------------- */
	public function render_settings_fields() {
		$button_text = get_option( 'wsf_wizard_button_text', 'کلاس خصوصی لازم دارم' );
		$font        = get_option( 'wsf_wizard_font', '' );
		$accent      = get_option( 'wsf_wizard_accent_color', '' );
		$fonts       = wsf_get_elementor_fonts();
		?>
		<p class="description">
			<?php
			printf(
				/* translators: %s: لینک لیست ویزاردها */
				wp_kses( __( 'هر ویزارد (مراحل، اتصال به فیلترهای جت‌اسمارت‌فیلترز، پست‌تایپ هدف، آدرس آرشیو) یک آیتم مستقل در <a href="%s">«ویزاردهای هوشمند»</a> در منوی اصلی است — می‌توانید چند ویزارد بسازید و هرکدام را در یک ویجت جدا نمایش دهید.', 'webisoft-school-forms' ), array( 'a' => array( 'href' => array() ) ) ),
				esc_url( admin_url( 'edit.php?post_type=' . self::CPT ) )
			);
			?>
		</p>
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'متن پیش‌فرض دکمه', 'webisoft-school-forms' ); ?></th>
				<td><input type="text" class="regular-text" name="wsf_wizard_button_text" value="<?php echo esc_attr( $button_text ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'رنگ برند اختصاصی این نوع فرم', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="text" class="wsf-color-picker" name="wsf_wizard_accent_color" value="<?php echo esc_attr( $accent ); ?>" dir="ltr">
					<p class="description"><?php esc_html_e( 'خالی بگذارید تا رنگ برند عمومی استفاده شود.', 'webisoft-school-forms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'فونت اختصاصی این نوع فرم', 'webisoft-school-forms' ); ?></th>
				<td>
					<select name="wsf_wizard_font" style="min-width:25em;">
						<option value=""><?php esc_html_e( '— پیش‌فرض عمومی —', 'webisoft-school-forms' ); ?></option>
						<option value="Tahoma, sans-serif" <?php selected( $font, 'Tahoma, sans-serif' ); ?>>Tahoma</option>
						<?php foreach ( $fonts as $f ) : ?>
							<option value="<?php echo esc_attr( $f ); ?>" <?php selected( $font, $f ); ?>><?php echo esc_html( $f ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</table>
		<?php
	}

	/* ---------------------------------------------------------------
	 * صفحه‌ی گزارشات
	 * --------------------------------------------------------------- */
	public function render_logs_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'شما اجازه دسترسی به این صفحه را ندارید.', 'webisoft-school-forms' ) );
		}

		if ( isset( $_POST['wsf_clear_wizard_logs_inline'] ) ) {
			check_admin_referer( 'wsf_clear_wizard_logs' );
			global $wpdb;
			$wpdb->query( 'TRUNCATE TABLE ' . wsf_table( 'wizard_logs' ) );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'دیتابیس گزارش‌ها پاک شد.', 'webisoft-school-forms' ) . '</p></div>';
		}

		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . wsf_table( 'wizard_logs' ) . ' ORDER BY id DESC LIMIT 500', ARRAY_A );
		?>
		<div class="wsf-a-wrap">
			<?php
			wsf_admin_page_header(
				'📊',
				__( 'گزارشات ویزارد هوشمند', 'webisoft-school-forms' ),
				__( 'انتخاب‌های کاربران در همه‌ی ویزاردها، برای تحلیل رفتار جست‌وجو.', 'webisoft-school-forms' ),
				'<a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wsf_export_wizard_csv' ), 'wsf_export_wizard_csv' ) ) . '" class="wsf-a-btn wsf-a-btn-sec">📥 ' . esc_html__( 'خروجی CSV', 'webisoft-school-forms' ) . '</a>'
			);
			?>

			<div class="wsf-a-card">
				<form method="post" onsubmit="return confirm('<?php echo esc_js( __( 'هشدار: تمام گزارش‌ها حذف می‌شوند. مطمئن هستید؟', 'webisoft-school-forms' ) ); ?>');" style="margin-bottom:16px;">
					<?php wp_nonce_field( 'wsf_clear_wizard_logs' ); ?>
					<input type="hidden" name="wsf_clear_wizard_logs_inline" value="1">
					<button type="submit" class="wsf-a-btn wsf-a-btn-danger wsf-a-btn-sm"><?php esc_html_e( 'پاکسازی کل دیتابیس گزارش‌ها', 'webisoft-school-forms' ); ?></button>
				</form>
				<table class="wsf-a-table">
					<thead><tr><th style="width:80px;"><?php esc_html_e( 'شناسه', 'webisoft-school-forms' ); ?></th><th style="width:160px;"><?php esc_html_e( 'ویزارد', 'webisoft-school-forms' ); ?></th><th style="width:180px;"><?php esc_html_e( 'تاریخ و زمان', 'webisoft-school-forms' ); ?></th><th><?php esc_html_e( 'انتخاب‌های کاربر', 'webisoft-school-forms' ); ?></th></tr></thead>
					<tbody>
						<?php if ( empty( $rows ) ) : ?>
							<tr><td colspan="4"><?php esc_html_e( 'هیچ داده‌ای تاکنون ثبت نشده است.', 'webisoft-school-forms' ); ?></td></tr>
						<?php else : ?>
							<?php foreach ( $rows as $row ) : ?>
								<?php
								$data      = json_decode( $row['log_data'], true );
								$wizard_id = intval( $row['wizard_id'] ?? 0 );
								$w_title   = $wizard_id ? get_the_title( $wizard_id ) : '';
								?>
								<tr>
									<td><?php echo esc_html( $row['id'] ); ?></td>
									<td><?php echo esc_html( $w_title ?: '—' ); ?></td>
									<td dir="ltr" style="text-align:right;"><?php echo esc_html( wsf_format_jalali_datetime( $row['submitted_at'] ) ); ?></td>
									<td>
										<?php if ( is_array( $data ) ) : ?>
											<?php foreach ( $data as $key => $val ) : ?>
												<span class="wsf-a-badge wsf-a-badge-info" style="margin:2px;">
													<strong><?php echo esc_html( $key ); ?>:</strong> <?php echo esc_html( is_array( $val ) ? implode( '، ', $val ) : $val ); ?>
												</span>
											<?php endforeach; ?>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	public function handle_csv_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی غیرمجاز.', 'webisoft-school-forms' ) );
		}
		check_admin_referer( 'wsf_export_wizard_csv' );

		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . wsf_table( 'wizard_logs' ) . ' ORDER BY id DESC', ARRAY_A );

		$csv_rows = array();
		foreach ( $rows as $row ) {
			$data    = json_decode( $row['log_data'], true );
			$details = array();
			if ( is_array( $data ) ) {
				foreach ( $data as $key => $val ) {
					$details[] = $key . ': ' . ( is_array( $val ) ? implode( '، ', $val ) : $val );
				}
			}
			$wizard_id  = intval( $row['wizard_id'] ?? 0 );
			$csv_rows[] = array( $row['id'], $wizard_id ? get_the_title( $wizard_id ) : '', $row['submitted_at'], implode( ' | ', $details ) );
		}

		wsf_stream_csv( 'wizard-reports-' . gmdate( 'Y-m-d' ) . '.csv', array( 'ردیف', 'ویزارد', 'تاریخ ثبت', 'جزئیات انتخاب شده' ), $csv_rows );
	}

	public function handle_clear_logs() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی غیرمجاز.', 'webisoft-school-forms' ) );
		}
		check_admin_referer( 'wsf_clear_wizard_logs' );
		global $wpdb;
		$wpdb->query( 'TRUNCATE TABLE ' . wsf_table( 'wizard_logs' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=wsf-wizard-logs&cleared=1' ) );
		exit;
	}

	/* ---------------------------------------------------------------
	 * AJAX: دریافت گزینه‌های یک مرحله‌ی داینامیک (وابسته به مراحل قبل)
	 * --------------------------------------------------------------- */
	public function handle_get_terms() {
		check_ajax_referer( 'wsf_wizard_nonce', 'wsf_nonce' );

		$wizard = $this->get_wizard( $_POST['wizard_id'] ?? 0 );
		if ( ! $wizard ) {
			wp_send_json_error( __( 'ویزارد پیدا نشد', 'webisoft-school-forms' ) );
		}

		$filter_id  = isset( $_POST['filter_id'] ) ? intval( $_POST['filter_id'] ) : 0;
		$deps       = isset( $_POST['deps'] ) && is_array( $_POST['deps'] ) ? wp_unslash( $_POST['deps'] ) : array();
		$target_cpt = $wizard['target_cpt'];

		$current_tax = get_post_meta( $filter_id, '_source_taxonomy', true );
		if ( ! $current_tax ) {
			wp_send_json_error( __( 'تکسونومی فیلتر پیدا نشد', 'webisoft-school-forms' ) );
		}

		$tax_query = array( 'relation' => 'AND' );
		foreach ( $deps as $dep ) {
			$dep_filter_id = isset( $dep['filter_id'] ) ? intval( $dep['filter_id'] ) : 0;
			$dep_tax       = get_post_meta( $dep_filter_id, '_source_taxonomy', true );
			if ( $dep_tax && ! empty( $dep['value'] ) ) {
				$tax_query[] = array(
					'taxonomy' => sanitize_key( $dep_tax ),
					'field'    => 'term_id',
					'terms'    => array_map( 'intval', (array) $dep['value'] ),
				);
			}
		}

		if ( count( $tax_query ) > 1 ) {
			$post_ids = get_posts(
				array(
					'post_type'      => sanitize_key( $target_cpt ),
					'posts_per_page' => -1,
					'tax_query'      => $tax_query, // phpcs:ignore -- built from server-side stored filter meta, not raw user taxonomy strings
					'fields'         => 'ids',
				)
			);
			$terms = empty( $post_ids ) ? array() : wp_get_object_terms( $post_ids, $current_tax );
		} else {
			$terms = get_terms( array( 'taxonomy' => $current_tax, 'hide_empty' => true ) );
		}

		$result = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$result[] = array( 'id' => $t->term_id, 'name' => $t->name );
			}
		}

		wp_send_json_success( array( 'taxonomy' => $current_tax, 'terms' => $result ) );
	}

	/* ---------------------------------------------------------------
	 * AJAX: ثبت لاگ انتخاب‌های کاربر برای گزارش‌گیری
	 * --------------------------------------------------------------- */
	public function handle_save_log() {
		check_ajax_referer( 'wsf_wizard_nonce', 'wsf_nonce' );

		$wizard_id = intval( $_POST['wizard_id'] ?? 0 );

		$log_data = isset( $_POST['log_data'] ) ? wp_unslash( $_POST['log_data'] ) : '{}';
		json_decode( $log_data ); // فقط برای اطمینان از JSON معتبر بودن قبل از ذخیره.
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			$log_data = '{}';
		}

		global $wpdb;
		$wpdb->insert(
			wsf_table( 'wizard_logs' ),
			array(
				'wizard_id'    => $wizard_id,
				'log_data'     => $log_data,
				'submitted_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s' )
		);

		wp_send_json_success();
	}
}
