<?php
defined( 'ABSPATH' ) || exit;

class WSF_Widget_Teacher_Wizard extends \Elementor\Widget_Base {

	use WSF_Elementor_Widget_Trait;

	public function get_name() { return 'wsf-teacher-wizard'; }
	public function get_title() { return __( 'Webisoft: ویزارد هوشمند اساتید', 'webisoft-school-forms' ); }
	public function get_icon() { return 'eicon-post-navigation'; }

	public function get_style_depends() { return array( 'wsf-frontend' ); }
	public function get_script_depends() { return array( 'wsf-frontend', 'wsf-teacher-wizard-frontend' ); }

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array( 'label' => __( 'محتوا', 'webisoft-school-forms' ) ) );

		$wizard_options = wsf()->teacher_wizard->get_wizard_options();

		if ( $wizard_options ) {
			$this->add_control(
				'wizard_id',
				array(
					'label'   => __( 'کدام ویزارد نمایش داده شود؟', 'webisoft-school-forms' ),
					'type'    => \Elementor\Controls_Manager::SELECT,
					'options' => $wizard_options,
					'default' => array_key_first( $wizard_options ),
				)
			);
		} else {
			$this->add_control(
				'no_wizard_notice',
				array(
					'type'            => \Elementor\Controls_Manager::RAW_HTML,
					'raw'             => sprintf(
						/* translators: %s: لینک ساخت ویزارد */
						__( '⚠️ هنوز هیچ ویزاردی نساخته‌اید. از <a href="%s" target="_blank">اینجا</a> یک ویزارد جدید بسازید و بعد این ویجت را دوباره انتخاب کنید.', 'webisoft-school-forms' ),
						esc_url( admin_url( 'post-new.php?post_type=' . WSF_Teacher_Wizard_Module::CPT ) )
					),
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
				)
			);
		}

		$this->add_control(
			'button_text',
			array(
				'label'       => __( 'متن دکمه', 'webisoft-school-forms' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => get_option( 'wsf_wizard_button_text', 'کلاس خصوصی لازم دارم' ),
				'description' => __( 'خالی بگذارید تا متن تنظیم‌شده در «تنظیمات فرم‌ها» استفاده شود.', 'webisoft-school-forms' ),
			)
		);

		$this->add_wsf_popup_id_control();

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', array( 'label' => __( 'ظاهر', 'webisoft-school-forms' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_wsf_css_var_color_control( 'accent_color', 'wsf-accent', __( 'رنگ برند (این نمونه)', 'webisoft-school-forms' ) );
		$this->add_wsf_typography_control( 'button_typography', '{{WRAPPER}} .wsf-trigger-btn', __( 'تایپوگرافی دکمه', 'webisoft-school-forms' ) );
		$this->add_wsf_corner_radius_control( 'trigger_radius', 'wsf-trigger-radius', __( 'گردی گوشه‌های دکمه‌ی اصلی', 'webisoft-school-forms' ) );
		$this->add_wsf_radius_control( 'modal_radius', 'wsf-radius', __( 'گردی گوشه‌های مودال', 'webisoft-school-forms' ), 14 );
		$this->add_wsf_corner_radius_control( 'option_radius', 'wsf-option-radius', __( 'گردی گوشه‌های لیست گزینه‌ها', 'webisoft-school-forms' ) );
		$this->end_controls_section();
	}

	protected function render() {
		$settings   = $this->get_settings_for_display();
		$uid        = 'wsf-wizard-' . $this->get_id();
		$button_txt = $settings['button_text'] ?: get_option( 'wsf_wizard_button_text', 'کلاس خصوصی لازم دارم' );

		$wizard_id = intval( $settings['wizard_id'] ?? 0 );
		$wizard    = wsf()->teacher_wizard->get_wizard( $wizard_id );

		if ( ! $wizard || empty( $wizard['steps'] ) ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<p style="padding:15px;background:#fff3cd;border:1px solid #ffe08a;border-radius:8px;">' . esc_html__( 'هنوز مرحله‌ای برای این ویزارد تعریف نشده است.', 'webisoft-school-forms' ) . '</p>';
			}
			return;
		}

		$steps       = $wizard['steps'];
		$archive_url = $wizard['archive_url'];
		?>
		<div class="wsf-widget"<?php echo $this->get_wsf_popup_id_attr( $settings ); // phpcs:ignore -- escaped in helper ?> data-wsf-module="teacher_wizard" id="<?php echo esc_attr( $uid ); ?>">
			<button type="button" class="wsf-trigger-btn" data-wsf-open><?php echo esc_html( $button_txt ); ?></button>

			<div class="wsf-modal" id="<?php echo esc_attr( $uid ); ?>-modal" aria-hidden="true">
				<div class="wsf-overlay"></div>
				<div class="wsf-modal-content">
					<button type="button" class="wsf-close" aria-label="<?php esc_attr_e( 'بستن', 'webisoft-school-forms' ); ?>">×</button>

					<div data-wsf-wizard data-wizard-id="<?php echo (int) $wizard_id; ?>" data-archive-url="<?php echo esc_url( $archive_url ); ?>">
						<?php wp_nonce_field( 'wsf_wizard_nonce', 'wsf_nonce' ); ?>

						<?php foreach ( $steps as $index => $step ) : ?>
							<div
								class="wsf-step <?php echo 0 === $index ? 'wsf-step-active' : ''; ?>"
								data-step="<?php echo (int) $index; ?>"
								data-type="<?php echo esc_attr( $step['type'] ); ?>"
								data-filter="<?php echo esc_attr( $step['filter_id'] ?? '' ); ?>"
								data-multi="<?php echo ! empty( $step['is_multi'] ) ? '1' : '0'; ?>"
								data-qtitle="<?php echo esc_attr( $step['q_title'] ); ?>"
							>
								<h2 class="wsf-form-title"><?php echo esc_html( $step['q_title'] ); ?></h2>

								<div class="wsf-wizard-loading" hidden><?php esc_html_e( 'در حال یافتن گزینه‌های مرتبط...', 'webisoft-school-forms' ); ?></div>

								<div class="wsf-radio-group wsf-wizard-options">
									<?php if ( 'manual' === $step['type'] ) : ?>
										<?php
										$opts      = array_filter( array_map( 'trim', explode( ',', $step['manual_options'] ?? '' ) ) );
										$is_multi  = ! empty( $step['is_multi'] );
										$input_type = $is_multi ? 'checkbox' : 'radio';
										foreach ( $opts as $opt ) :
											?>
											<label class="wsf-option-card">
												<input type="<?php echo esc_attr( $input_type ); ?>" name="step_<?php echo (int) $index; ?>[]" value="<?php echo esc_attr( $opt ); ?>" data-label="<?php echo esc_attr( $opt ); ?>">
												<span class="wsf-option-check<?php echo $is_multi ? '' : ' wsf-check-round'; ?>"></span>
												<span class="wsf-option-label"><?php echo esc_html( $opt ); ?></span>
											</label>
										<?php endforeach; ?>
									<?php endif; ?>
								</div>

								<div class="wsf-actions-row">
									<?php if ( $index > 0 ) : ?>
										<button type="button" class="wsf-btn wsf-btn-secondary" data-wsf-wizard-prev="<?php echo (int) ( $index - 1 ); ?>"><?php esc_html_e( 'مرحله قبل', 'webisoft-school-forms' ); ?></button>
									<?php endif; ?>

									<?php if ( $index < count( $steps ) - 1 ) : ?>
										<button type="button" class="wsf-btn" data-wsf-wizard-next="<?php echo (int) ( $index + 1 ); ?>"><?php esc_html_e( 'مرحله بعد', 'webisoft-school-forms' ); ?></button>
									<?php else : ?>
										<button type="button" class="wsf-btn wsf-wizard-submit"><?php esc_html_e( 'مشاهده نتایج', 'webisoft-school-forms' ); ?></button>
									<?php endif; ?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}
