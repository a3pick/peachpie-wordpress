<?php
/**
 * Plugin Name: فرم‌های Webisoft
 * Description: مجموعه فرم‌های چندمرحله‌ای سایت (همکاری، رزومه، مشاوره تحصیلی، ویزارد هوشمند اساتید) به‌صورت ویجت‌های المنتور با تنظیمات کامل از داشبورد وردپرس.
 * Version: 1.7.0
 * Author: Webisoft
 * Text Domain: webisoft-school-forms
 */

defined( 'ABSPATH' ) || exit;

define( 'WSF_VERSION', '1.7.0' );
define( 'WSF_FILE', __FILE__ );
define( 'WSF_PATH', plugin_dir_path( __FILE__ ) );
define( 'WSF_URL', plugin_dir_url( __FILE__ ) );

require_once WSF_PATH . 'includes/functions.php';
require_once WSF_PATH . 'includes/class-elementor-trait.php';
require_once WSF_PATH . 'includes/class-submissions-list.php';
require_once WSF_PATH . 'includes/class-installer.php';
require_once WSF_PATH . 'includes/class-plugin.php';

require_once WSF_PATH . 'modules/resume/class-resume.php';
require_once WSF_PATH . 'modules/academy-membership/class-academy-membership.php';
require_once WSF_PATH . 'modules/consulting/class-consulting.php';
require_once WSF_PATH . 'modules/teacher-wizard/class-teacher-wizard.php';
require_once WSF_PATH . 'modules/link-button/class-link-button.php';

register_activation_hook( __FILE__, array( 'WSF_Installer', 'activate' ) );

function wsf() {
	return WSF_Plugin::instance();
}

wsf();
