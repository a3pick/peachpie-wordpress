<?php
defined( 'ABSPATH' ) || exit;

/**
 * دسته‌بندی اختصاصی ویجت‌های این پلاگین در پنل المنتور.
 */
add_action(
	'elementor/elements/categories_registered',
	function ( $elements_manager ) {
		$elements_manager->add_category(
			'wsf-forms',
			array(
				'title' => __( 'فرم‌های Webisoft', 'webisoft-school-forms' ),
				'icon'  => 'fa fa-wpforms',
			)
		);
	}
);

/**
 * تریت مشترک ویجت‌های این پلاگین: دسته‌بندی، کلمات کلیدی و کنترل‌های
 * پرکاربرد تب استایل (رنگ برند/متن با متغیر CSS، تایپوگرافی، گردی گوشه).
 */
trait WSF_Elementor_Widget_Trait {

	public function get_categories() {
		return array( 'wsf-forms' );
	}

	public function get_keywords() {
		return array( 'form', 'فرم', 'مودال', 'Webisoft' );
	}

	/**
	 * کنترل رنگ که مقدارش را با !important روی یک متغیر CSS در سطح
	 * {{WRAPPER}} می‌گذارد — هرگز مستقیم روی یک property نهایی، تا هم از
	 * باگ اختصاصیت ID غلبه کند و هم بشود در CSS پایه با var(--x, پیش‌فرض) خواند.
	 */
	protected function add_wsf_css_var_color_control( $id, $css_var, $label, $default = '' ) {
		$this->add_control(
			$id,
			array(
				'label'     => $label,
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => $default,
				'selectors' => array( '{{WRAPPER}}' => '--' . $css_var . ': {{VALUE}} !important;' ),
			)
		);
	}

	protected function add_wsf_typography_control( $id, $selector, $label ) {
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => $id,
				'label'    => $label,
				'selector' => $selector,
			)
		);
	}

	/**
	 * کنترل اسلایدر گردی گوشه — عمداً بدون «default» عددی ثابت (فقط برای
	 * راهنمای توضیحات از $hint_default استفاده می‌شود). اگر یک SLIDER مقدار
	 * پیش‌فرض عددی داشته باشد، المنتور همیشه (حتی وقتی کاربر دست نزده) آن را
	 * با !important روی {{WRAPPER}} چاپ می‌کند و تنظیم سراسری/ماژول را برای
	 * همیشه بی‌اثر می‌کند — چون برخلاف کنترل رنگ، اسلایدر رشته‌ی خالی ندارد.
	 * راه‌حل: مقدار اولیه‌ی size را واقعاً خالی («size» => '') می‌گذاریم تا
	 * وقتی کاربر لمسش نکرده هیچ CSS‌ای تولید نشود و لایه‌ی سراسری برنده بماند.
	 */
	protected function add_wsf_radius_control( $id, $css_var, $label, $hint_default = 12 ) {
		$this->add_control(
			$id,
			array(
				'label'       => $label,
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'size_units'  => array( 'px' ),
				'range'       => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'default'     => array( 'size' => '', 'unit' => 'px' ),
				/* translators: %d: مقدار پیش‌فرض سراسری فعلی به پیکسل */
				'description' => sprintf( __( 'خالی/دست‌نخورده بگذارید تا مقدار «تنظیمات فرم‌ها» (پیش‌فرض فعلی: %dpx) استفاده شود.', 'webisoft-school-forms' ), $hint_default ),
				'selectors'   => array( '{{WRAPPER}}' => '--' . $css_var . ': {{SIZE}}{{UNIT}} !important;' ),
			)
		);
	}

	/**
	 * کنترل «گردی مستقل هر گوشه» برای لیست گزینه‌ها: چون فقط ردیف اول (دو
	 * گوشه‌ی بالا) و ردیف آخر (دو گوشه‌ی پایین) واقعاً گرد می‌شوند، از کنترل
	 * DIMENSIONS چهارتایی خودِ المنتور استفاده می‌کنیم — TOP/RIGHT/BOTTOM/LEFT
	 * دقیقاً روی بالا-چپ/بالا-راست/پایین-راست/پایین-چپ نگاشت می‌شوند (همان
	 * ترتیب شورت‌هندِ خودِ CSS برای border-radius).
	 */
	protected function add_wsf_corner_radius_control( $id, $css_var_prefix, $label ) {
		$this->add_control(
			$id,
			array(
				'label'       => $label,
				'type'        => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units'  => array( 'px' ),
				'default'     => array( 'top' => '', 'right' => '', 'bottom' => '', 'left' => '', 'unit' => 'px', 'isLinked' => false ),
				'description' => __( 'بالا-چپ / بالا-راست / پایین-راست / پایین-چپ. خالی بگذارید تا مقدار «تنظیمات فرم‌ها» استفاده شود.', 'webisoft-school-forms' ),
				'selectors'   => array(
					'{{WRAPPER}}' => '--' . $css_var_prefix . '-tl: {{TOP}}{{UNIT}} !important; --' . $css_var_prefix . '-tr: {{RIGHT}}{{UNIT}} !important; --' . $css_var_prefix . '-br: {{BOTTOM}}{{UNIT}} !important; --' . $css_var_prefix . '-bl: {{LEFT}}{{UNIT}} !important;',
				),
			)
		);
	}

	/**
	 * کنترل «شناسه پاپ‌آپ»: با لینک منو/دکمه‌ای به شکل #شناسه، مودال همین ویجت باز می‌شود.
	 */
	protected function add_wsf_popup_id_control() {
		$this->add_control(
			'popup_id',
			array(
				'label'       => __( 'شناسه پاپ‌آپ (برای منو)', 'webisoft-school-forms' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => 'resume-popup',
				'description' => __( 'فقط حروف انگلیسی، عدد، خط تیره و آندرلاین. سپس در منو یک «لینک دلخواه» با آدرس #resume-popup بسازید. ویجت باید در همان صفحه (مثلاً فوتر یا هدر سراسری) وجود داشته باشد.', 'webisoft-school-forms' ),
			)
		);
	}

	protected function get_wsf_popup_id_attr( $settings ) {
		$id = isset( $settings['popup_id'] ) ? sanitize_html_class( ltrim( trim( $settings['popup_id'] ), '#' ) ) : '';
		return '' !== $id ? ' data-wsf-popup-id="' . esc_attr( $id ) . '"' : '';
	}
}
