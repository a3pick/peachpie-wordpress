<?php
defined( 'ABSPATH' ) || exit;

/**
 * نام کامل جدول دیتابیس با پیشوند وردپرس.
 */
function wsf_table( $suffix ) {
	global $wpdb;
	return $wpdb->prefix . 'wsf_' . $suffix;
}

/**
 * پاک‌سازی شماره تماس: فقط رقم و + نگه می‌دارد.
 */
function wsf_clean_phone( $phone ) {
	return preg_replace( '/[^0-9+]/', '', (string) $phone );
}

/**
 * تبدیل هگز به «R G B» فاصله‌جدا برای تزریق به‌عنوان متغیر CSS، جهت
 * ساخت پس‌زمینه/سایه‌های کم‌رنگ همراه با رنگ برند با color-mix/rgb().
 */
function wsf_hex_to_rgb( $hex ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( strlen( $hex ) === 3 ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( strlen( $hex ) !== 6 ) {
		return '233 30 99';
	}
	return sprintf( '%d %d %d', hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
}

/**
 * لیست فونت‌های اختصاصی آپلودشده در المنتور (Custom Fonts) برای انتخاب در تنظیمات فرم‌ها.
 */
function wsf_get_elementor_fonts() {
	global $wpdb;
	$fonts = $wpdb->get_col(
		"SELECT post_title FROM {$wpdb->posts} WHERE post_type = 'elementor_font' AND post_status = 'publish'"
	);
	return is_array( $fonts ) ? $fonts : array();
}

/**
 * گزینه سراسری تنظیمات پلاگین (رنگ/فونت پیش‌فرض مشترک بین همه فرم‌ها).
 */
function wsf_get_global_style( $key, $default = '' ) {
	$defaults = array(
		// برند و گزینه‌ها
		'accent_color'       => '#7f54b3', // بنفش Webisoft
		'option_bg'          => '#191c21', // همان رنگ دقیقِ چک‌باکس/فرم مسترکلاس
		'option_bg_hover'    => '#42454c', // رنگ هاور/انتخاب‌شده (طبق نمونه‌برداری مستقیم کاربر از مسترکلاس)
		'checkbox_bg'        => '#42454c', // داخل چک‌باکسِ خالی
		'option_text'        => '#ffffff',
		'option_radius_tl'   => '10',
		'option_radius_tr'   => '10',
		'option_radius_br'   => '10',
		'option_radius_bl'   => '10',
		'trigger_radius_tl'  => '10',
		'trigger_radius_tr'  => '10',
		'trigger_radius_br'  => '10',
		'trigger_radius_bl'  => '10',
		'btn_radius'         => '10',
		'modal_radius'       => '14',
		'show_option_check'  => 1,
		// مودال و متن‌ها (طبق نمونه‌برداری کاربر از مسترکلاس: پاپ‌آپ کاملاً تیره)
		'modal_bg'           => '#000000',
		'heading_color'      => '#ffffff',
		'desc_color'         => '#9aa0a6',
		'label_color'        => '#ffffff',
		'close_color'        => '#9aa0a6',
		// فیلدهای فرم
		'field_bg'           => '#222327',
		'field_border'       => '#42454c',
		'field_text'         => '#ffffff',
		// دکمه‌ها
		'btn_secondary_bg'   => '#f0f0f0',
		'btn_secondary_text' => '#333333',
		// پیام‌ها
		'success_bg'         => '#e7f7ed',
		'success_text'       => '#176b35',
		'error_bg'           => '#fdeaea',
		'error_text'         => '#aa1111',
		// فونت و تایپوگرافی
		'font'               => 'inherit',
		'heading_size'       => '22',
		'heading_weight'     => '700',
		'desc_size'          => '14.5',
		'desc_weight'        => '400',
		'btn_size'           => '16',
		'btn_weight'         => '600',
		'option_size'        => '15.5',
		'option_weight'      => '500',
	);
	$opts = get_option( 'wsf_global_style', array() );
	if ( isset( $opts[ $key ] ) && $opts[ $key ] !== '' ) {
		return $opts[ $key ];
	}
	return isset( $defaults[ $key ] ) ? $defaults[ $key ] : $default;
}

/**
 * نگاشت کلید تنظیمات سراسری => [نام متغیر CSS، واحد]. اضافه‌کردن هر رنگ/سایز
 * جدید فقط با اضافه‌کردن یک خط اینجا (و یک پیش‌فرض در wsf_get_global_style)
 * کامل می‌شود — هم در :root سراسری و هم در override هر ماژول استفاده می‌شود.
 */
function wsf_css_var_map() {
	return array(
		'accent_color'       => array( 'wsf-accent', '' ),
		'option_bg'          => array( 'wsf-option-bg', '' ),
		'option_bg_hover'    => array( 'wsf-option-bg-hover', '' ),
		'checkbox_bg'        => array( 'wsf-checkbox-bg', '' ),
		'option_text'        => array( 'wsf-option-text', '' ),
		'option_radius_tl'   => array( 'wsf-option-radius-tl', 'px' ),
		'option_radius_tr'   => array( 'wsf-option-radius-tr', 'px' ),
		'option_radius_br'   => array( 'wsf-option-radius-br', 'px' ),
		'option_radius_bl'   => array( 'wsf-option-radius-bl', 'px' ),
		'trigger_radius_tl'  => array( 'wsf-trigger-radius-tl', 'px' ),
		'trigger_radius_tr'  => array( 'wsf-trigger-radius-tr', 'px' ),
		'trigger_radius_br'  => array( 'wsf-trigger-radius-br', 'px' ),
		'trigger_radius_bl'  => array( 'wsf-trigger-radius-bl', 'px' ),
		'btn_radius'         => array( 'wsf-btn-radius', 'px' ),
		'modal_radius'       => array( 'wsf-radius', 'px' ),
		'modal_bg'           => array( 'wsf-modal-bg', '' ),
		'heading_color'      => array( 'wsf-heading-color', '' ),
		'desc_color'         => array( 'wsf-desc-color', '' ),
		'label_color'        => array( 'wsf-label-color', '' ),
		'close_color'        => array( 'wsf-close-color', '' ),
		'field_bg'           => array( 'wsf-field-bg', '' ),
		'field_border'       => array( 'wsf-field-border', '' ),
		'field_text'         => array( 'wsf-field-text', '' ),
		'btn_secondary_bg'   => array( 'wsf-btn-secondary-bg', '' ),
		'btn_secondary_text' => array( 'wsf-btn-secondary-text', '' ),
		'success_bg'         => array( 'wsf-success-bg', '' ),
		'success_text'       => array( 'wsf-success-text', '' ),
		'error_bg'           => array( 'wsf-error-bg', '' ),
		'error_text'         => array( 'wsf-error-text', '' ),
		'font'               => array( 'wsf-font', '' ),
		'heading_size'       => array( 'wsf-heading-size', 'px' ),
		'heading_weight'     => array( 'wsf-heading-weight', '' ),
		'desc_size'          => array( 'wsf-desc-size', 'px' ),
		'desc_weight'        => array( 'wsf-desc-weight', '' ),
		'btn_size'           => array( 'wsf-btn-size', 'px' ),
		'btn_weight'         => array( 'wsf-btn-weight', '' ),
		'option_size'        => array( 'wsf-option-size', 'px' ),
		'option_weight'      => array( 'wsf-option-weight', '' ),
	);
}

/**
 * رشته‌ی کامل «--var:value;» برای همه‌ی کلیدهای سراسری، جهت تزریق در :root.
 */
function wsf_build_css_vars() {
	$css = '--wsf-option-check-display:' . ( wsf_get_global_style( 'show_option_check' ) ? 'flex' : 'none' ) . ';';
	foreach ( wsf_css_var_map() as $key => $meta ) {
		list( $var, $unit ) = $meta;
		$css .= "--{$var}:" . wsf_get_global_style( $key ) . "{$unit};";
	}
	return $css;
}

/**
 * گزینه‌های وزن فونت قابل انتخاب در تنظیمات (برچسب فارسی => مقدار CSS).
 */
function wsf_get_font_weight_options() {
	return array(
		'400' => __( 'عادی (400)', 'webisoft-school-forms' ),
		'500' => __( 'متوسط (500)', 'webisoft-school-forms' ),
		'600' => __( 'نیمه‌ضخیم (600)', 'webisoft-school-forms' ),
		'700' => __( 'ضخیم (700)', 'webisoft-school-forms' ),
		'800' => __( 'خیلی ضخیم (800)', 'webisoft-school-forms' ),
	);
}

/**
 * خواندن یک گزینه‌ی سبک برای یک ماژول خاص، با ارث‌بری از سبک سراسری وقتی
 * مقدار ماژول خالی («inherit») باشد. لایه‌ی سوم (نمونه در المنتور) با
 * متغیرهای CSS روی {{WRAPPER}} پیاده می‌شود، نه اینجا.
 */
function wsf_get_style_option( $module, $key, $global_key, $default = '' ) {
	$value = get_option( "wsf_{$module}_{$key}", '' );
	if ( $value !== '' ) {
		return $value;
	}
	return wsf_get_global_style( $global_key, $default );
}

/**
 * تیره‌کردن یک رنگ هگز به میزان درصد مشخص (برای رنگ hover دکمه/هدر ادمین).
 */
function wsf_darken_hex( $hex, $percent ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( strlen( $hex ) !== 6 ) {
		return '#' . $hex;
	}
	$rgb = array_map(
		function ( $c ) use ( $percent ) {
			return max( 0, min( 255, (int) round( hexdec( $c ) * ( 1 - $percent / 100 ) ) ) );
		},
		str_split( $hex, 2 )
	);
	return '#' . implode( '', array_map( function ( $c ) { return str_pad( dechex( $c ), 2, '0', STR_PAD_LEFT ); }, $rgb ) );
}

/**
 * هدر گرادیانی مشترک همه‌ی صفحات ادمین این پلاگین (همان استاندارد pilates-booking-core)
 * — رنگش از همان «رنگ برند» تنظیمات عمومی می‌آید تا پنل ادمین و ویجت‌های فرانت یکدست بمانند.
 */
function wsf_admin_page_header( $icon, $title, $subtitle = '', $action_html = '' ) {
	echo '<div class="wsf-a-hero">';
	echo '<div class="wsf-a-hero-title">';
	echo '<span class="wsf-a-hero-icon">' . esc_html( $icon ) . '</span>';
	echo '<div><h1>' . esc_html( $title ) . '</h1>';
	if ( $subtitle ) {
		echo '<p>' . esc_html( $subtitle ) . '</p>';
	}
	echo '</div></div>';
	if ( $action_html ) {
		echo '<div class="wsf-a-hero-action">' . $action_html . '</div>'; // phpcs:ignore -- caller passes trusted markup
	}
	echo '</div>';
}

/**
 * نمایش شماره‌گذاری‌شده‌ی HTML امن برای پیام موفقیت/خطا در پاسخ AJAX.
 */
function wsf_ajax_error( $message ) {
	wp_send_json_error( array( 'message' => $message ) );
}

function wsf_ajax_success( $message ) {
	wp_send_json_success( array( 'message' => $message ) );
}

/* -------------------------------------------------------------------
 * تقویم شمسی — همان الگوریتم/همان الگو که در pilates-booking-core جواب داده:
 * فیلد نمایشی همیشه شمسی است، مقداری که واقعاً ذخیره/فیلتر می‌شود همیشه
 * میلادیِ Y-m-d است، بنابراین PHP هیچ‌وقت لازم نیست چیزی درباره‌ی شمسی «حل» کند.
 * ------------------------------------------------------------------- */

function wsf_to_persian_digits( $str ) {
	$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
	$fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
	return str_replace( $en, $fa, (string) $str );
}

function wsf_gregorian_to_jalali( $gy, $gm, $gd ) {
	$g_days_in_month = array( 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
	$j_days_in_month = array( 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29 );

	$gy2 = $gy - 1600;
	$gm2 = $gm - 1;
	$gd2 = $gd - 1;

	$g_day_no = 365 * $gy2 + (int) ( ( $gy2 + 3 ) / 4 ) - (int) ( ( $gy2 + 99 ) / 100 ) + (int) ( ( $gy2 + 399 ) / 400 );

	for ( $i = 0; $i < $gm2; $i++ ) {
		$g_day_no += $g_days_in_month[ $i ];
	}
	if ( $gm2 > 1 && ( ( $gy2 % 4 === 0 && $gy2 % 100 !== 0 ) || $gy2 % 400 === 0 ) ) {
		$g_day_no++;
	}
	$g_day_no += $gd2;

	$j_day_no = $g_day_no - 79;
	$j_np     = (int) ( $j_day_no / 12053 );
	$j_day_no %= 12053;

	$jy = 979 + 33 * $j_np + 4 * (int) ( $j_day_no / 1461 );
	$j_day_no %= 1461;

	if ( $j_day_no >= 366 ) {
		$jy += (int) ( ( $j_day_no - 1 ) / 365 );
		$j_day_no = ( $j_day_no - 1 ) % 365;
	}

	for ( $i = 0; $i < 11 && $j_day_no >= $j_days_in_month[ $i ]; $i++ ) {
		$j_day_no -= $j_days_in_month[ $i ];
	}
	$jm = $i + 1;
	$jd = $j_day_no + 1;
	return array( $jy, $jm, $jd );
}

function wsf_format_jalali_date( $mysql_date_or_time, $with_persian_digits = true ) {
	if ( empty( $mysql_date_or_time ) || '0000-00-00' === $mysql_date_or_time ) {
		return '';
	}
	$ts               = is_numeric( $mysql_date_or_time ) ? $mysql_date_or_time : strtotime( $mysql_date_or_time );
	list( $jy, $jm, $jd ) = wsf_gregorian_to_jalali( (int) date( 'Y', $ts ), (int) date( 'n', $ts ), (int) date( 'j', $ts ) );
	$out              = sprintf( '%04d/%02d/%02d', $jy, $jm, $jd );
	return $with_persian_digits ? wsf_to_persian_digits( $out ) : $out;
}

function wsf_format_jalali_datetime( $mysql_datetime, $with_persian_digits = true ) {
	if ( empty( $mysql_datetime ) ) {
		return '';
	}
	$ts   = strtotime( $mysql_datetime );
	$date = wsf_format_jalali_date( $ts, $with_persian_digits );
	$time = date( 'H:i', $ts );
	return $date . ' - ' . ( $with_persian_digits ? wsf_to_persian_digits( $time ) : $time );
}

/**
 * فیلد تاریخ شمسی برای فرم‌های ادمین: نمایش همیشه شمسی، اما مقداری که واقعاً
 * GET/POST می‌شود میلادیِ Y-m-d است (سازگار با فیلتر SQL موجود بدون تغییر).
 * جاوااسکریپت آن در assets/js/jalali-datepicker.js پیاده شده.
 */
function wsf_jalali_date_field( $name, $gregorian_value = '', $placeholder = 'انتخاب تاریخ', $optional = true ) {
	$display = $gregorian_value ? wsf_format_jalali_date( $gregorian_value ) : '';
	ob_start();
	?>
	<span class="wsf-jalali-field" <?php echo $optional ? 'data-optional="1"' : ''; ?>>
		<input type="text" class="wsf-jalali-display" readonly value="<?php echo esc_attr( $display ); ?>" placeholder="<?php echo esc_attr( $placeholder ); ?>">
		<input type="hidden" class="wsf-jalali-value" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $gregorian_value ); ?>">
	</span>
	<?php
	return ob_get_clean();
}

/**
 * خروجی CSV یک آرایه از ردیف‌ها با هدر مشخص (BOM برای اکسل فارسی).
 */
function wsf_stream_csv( $filename, array $headers, array $rows ) {
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=' . $filename );

	$output = fopen( 'php://output', 'w' );
	fwrite( $output, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );
	fputcsv( $output, $headers );
	foreach ( $rows as $row ) {
		fputcsv( $output, $row );
	}
	fclose( $output );
	exit;
}
