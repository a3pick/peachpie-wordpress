<?php
defined( 'ABSPATH' ) || exit;

/**
 * هسته‌ی مرکزی پلاگین: منوی ادمین، اسکریپت/استایل مشترک، تنظیمات سراسری،
 * و صدا زدن register() هر ۴ ماژول.
 */
final class WSF_Plugin {

	private static $instance;

	/** @var WSF_Resume_Module */
	public $resume;
	/** @var WSF_Academy_Membership_Module */
	public $academy_membership;
	/** @var WSF_Consulting_Module */
	public $consulting;
	/** @var WSF_Teacher_Wizard_Module */
	public $teacher_wizard;
	/** @var WSF_Link_Button_Module */
	public $link_button;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->resume             = new WSF_Resume_Module();
		$this->academy_membership = new WSF_Academy_Membership_Module();
		$this->consulting         = new WSF_Consulting_Module();
		$this->teacher_wizard     = new WSF_Teacher_Wizard_Module();
		$this->link_button        = new WSF_Link_Button_Module();

		add_action( 'init', array( 'WSF_Installer', 'maybe_upgrade' ) );

		add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_global_settings' ) );
		add_action( 'admin_init', array( $this, 'maybe_reset_global_style' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'register_frontend_assets' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		add_action( 'wp_footer', array( $this, 'render_global_popup_template' ), 5 );
		add_action( 'wp_footer', array( $this, 'render_global_popups' ), 6 );
		add_shortcode( 'wsf_form', array( $this, 'shortcode_form' ) );

		foreach ( $this->modules() as $module ) {
			$module->register();
		}
	}

	private function modules() {
		return array( $this->resume, $this->academy_membership, $this->consulting, $this->teacher_wizard, $this->link_button );
	}

	/* ---------------------------------------------------------------
	 * دارایی‌های فرانت: فقط register می‌شوند؛ المنتور خودش با
	 * get_style_depends()/get_script_depends() هر ویجت، فقط در صفحاتی
	 * که آن ویجت واقعاً استفاده شده لود می‌کند.
	 * --------------------------------------------------------------- */
	public function register_frontend_assets() {
		wp_register_style( 'wsf-frontend', WSF_URL . 'assets/css/frontend.css', array(), WSF_VERSION );
		wp_register_script( 'wsf-frontend', WSF_URL . 'assets/js/frontend.js', array(), WSF_VERSION, true );
		wp_register_script( 'wsf-teacher-wizard-frontend', WSF_URL . 'assets/js/teacher-wizard-frontend.js', array( 'wsf-frontend' ), WSF_VERSION, true );
		wp_localize_script(
			'wsf-frontend',
			'wsfVars',
			array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ) )
		);

		$css  = ':root{' . wsf_build_css_vars() . '}';
		$css .= $this->module_style_override_css( 'resume' );
		$css .= $this->module_style_override_css( 'academy_membership' );
		$css .= $this->module_style_override_css( 'consulting' );
		$css .= $this->module_style_override_css( 'teacher_wizard' );

		wp_add_inline_style( 'wsf-frontend', $css );
	}

	/**
	 * اگر یک ماژول رنگ/فونت اختصاصی خودش را تنظیم کرده باشد (نه خالی)،
	 * یک قانون CSS محدود به همان ماژول اضافه می‌کند تا سبک سراسری را
	 * برای آن ماژول بازنویسی کند — لایه‌ی دوم از سه لایه.
	 */
	private function module_style_override_css( $module ) {
		$accent = get_option( "wsf_{$module}_accent_color", '' );
		$font   = get_option( "wsf_{$module}_font", '' );
		$css    = '';
		if ( $accent !== '' ) {
			$css .= "[data-wsf-module=\"{$module}\"]{--wsf-accent:{$accent} !important;}";
		}
		if ( $font !== '' ) {
			$css .= "[data-wsf-module=\"{$module}\"]{--wsf-font:{$font} !important;}";
		}
		return $css;
	}

	/**
	 * خروجی گرفتن از یک قالب المنتور (حاوی ویجت‌های فرم با «شناسه پاپ‌آپ») در فوتر
	 * همه‌ی صفحات؛ تا لینک منو (#شناسه) در هر صفحه‌ای مودال را باز کند.
	 */
	public function global_popup_modules() {
		return array(
			'resume'             => array( __( 'همکاری / رزومه', 'webisoft-school-forms' ), 'WSF_Widget_Resume', 'modules/resume/elementor/class-widget-resume.php' ),
			'academy_membership' => array( __( 'عضویت آکادمی', 'webisoft-school-forms' ), 'WSF_Widget_Academy_Membership', 'modules/academy-membership/elementor/class-widget-academy-membership.php' ),
			'consulting'         => array( __( 'مشاوره تحصیلی', 'webisoft-school-forms' ), 'WSF_Widget_Consulting', 'modules/consulting/elementor/class-widget-consulting.php' ),
			'teacher_wizard'     => array( __( 'ویزارد اساتید', 'webisoft-school-forms' ), 'WSF_Widget_Teacher_Wizard', 'modules/teacher-wizard/elementor/class-widget-teacher-wizard.php' ),
		);
	}

	public function sanitize_global_popups( $value ) {
		$out = array();
		foreach ( array_keys( $this->global_popup_modules() ) as $key ) {
			$id = is_array( $value ) && isset( $value[ $key ] ) ? sanitize_html_class( ltrim( trim( (string) $value[ $key ] ), '#' ) ) : '';
			if ( '' !== $id ) {
				$out[ $key ] = $id;
			}
		}
		return $out;
	}

	/**
	 * پاپ‌آپ‌های سراسری بدون ساخت قالب: برای هر فرمی که در تنظیمات شناسه گرفته،
	 * همان ویجت (با تنظیمات پیش‌فرض و متن‌های «تنظیمات فرم‌ها») در فوتر همه‌ی
	 * صفحات چاپ می‌شود و دکمه‌ی خودش مخفی است؛ فقط لینک منو آن را باز می‌کند.
	 */
	public function render_global_popups() {
		$popups = get_option( 'wsf_global_popups', array() );
		if ( is_admin() || is_feed() ) {
			return;
		}
		if ( empty( $popups ) || ! is_array( $popups ) ) {
			echo "\n<!-- WSF global popups: هیچ شناسه‌ای در تنظیمات ذخیره نشده -->\n";
			return;
		}
		if ( ! class_exists( '\\Elementor\\Widget_Base' ) ) {
			echo "\n<!-- WSF global popups: المنتور فعال نیست -->\n";
			return;
		}
		if ( class_exists( '\\Elementor\\Plugin' ) ) {
			$el = \Elementor\Plugin::$instance;
			if ( ( $el->editor && $el->editor->is_edit_mode() ) || ( $el->preview && $el->preview->is_preview_mode() ) ) {
				return;
			}
		}
		$modules = $this->global_popup_modules();
		wp_enqueue_style( 'wsf-frontend' );
		wp_enqueue_script( 'wsf-frontend' );
		foreach ( $popups as $key => $popup_id ) {
			if ( empty( $modules[ $key ] ) || '' === $popup_id ) {
				continue;
			}
			list( , $class, $file ) = $modules[ $key ];
			require_once WSF_PATH . $file;
			if ( 'teacher_wizard' === $key ) {
				wp_enqueue_script( 'wsf-teacher-wizard-frontend' );
			}
			try {
				$widget = new $class(
					array(
						'id'         => 'g' . substr( md5( $key ), 0, 6 ),
						'elType'     => 'widget',
						'widgetType' => ( new $class() )->get_name(),
						'settings'   => array( 'popup_id' => $popup_id ),
					),
					array()
				);
				ob_start();
				$widget->render_content();
				$html = ob_get_clean();
			} catch ( \Throwable $e ) {
				if ( ob_get_level() ) { ob_end_clean(); }
				echo "\n<!-- WSF global popups: خطا در " . esc_html( $key ) . ': ' . esc_html( str_replace( '--', '- -', $e->getMessage() ) ) . " -->\n";
				continue;
			}
			echo "\n<!-- WSF global popup rendered: " . esc_html( $key ) . ' = ' . esc_html( $popup_id ) . " -->\n";
			echo '<div class="wsf-global-popup">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- widget output is escaped inside render()
		}
	}

	/**
	 * شورت‌کد: [wsf_form type="consulting"] یا
	 * [wsf_form type="resume" popup="resume-popup" button="0"]
	 * type: resume | academy_membership | consulting | teacher_wizard
	 * popup: شناسه‌ی پاپ‌آپ برای لینک منو (اختیاری)
	 * button: 0 = دکمه‌ی خودِ فرم مخفی (فقط با لینک/منو باز شود)
	 */
	public function shortcode_form( $atts ) {
		$atts = shortcode_atts( array( 'type' => 'consulting', 'popup' => '', 'button' => '1' ), $atts, 'wsf_form' );
		$key  = str_replace( '-', '_', sanitize_key( $atts['type'] ) );
		$mods = $this->global_popup_modules();
		if ( empty( $mods[ $key ] ) || ! class_exists( '\\Elementor\\Widget_Base' ) ) {
			return current_user_can( 'edit_posts' ) ? '<!-- wsf_form: نوع نامعتبر یا المنتور غیرفعال -->' : '';
		}
		list( , $class, $file ) = $mods[ $key ];
		require_once WSF_PATH . $file;
		wp_enqueue_style( 'wsf-frontend' );
		wp_enqueue_script( 'wsf-frontend' );
		if ( 'teacher_wizard' === $key ) {
			wp_enqueue_script( 'wsf-teacher-wizard-frontend' );
		}
		try {
			$widget = new $class(
				array(
					'id'         => 's' . substr( md5( $key . $atts['popup'] . wp_rand() ), 0, 6 ),
					'elType'     => 'widget',
					'widgetType' => ( new $class() )->get_name(),
					'settings'   => array( 'popup_id' => sanitize_html_class( $atts['popup'] ) ),
				),
				array()
			);
			ob_start();
			$widget->render_content();
			$html = ob_get_clean();
		} catch ( \Throwable $e ) {
			if ( ob_get_level() ) { ob_end_clean(); }
			return current_user_can( 'edit_posts' ) ? '<!-- wsf_form error: ' . esc_html( str_replace( '--', '- -', $e->getMessage() ) ) . ' -->' : '';
		}
		$cls = '0' === (string) $atts['button'] ? 'wsf-global-popup' : 'wsf-shortcode-form';
		return '<div class="' . esc_attr( $cls ) . '">' . $html . '</div>';
	}

	public function render_global_popup_template() {
		$template_id = absint( get_option( 'wsf_global_popup_template', 0 ) );
		if ( ! $template_id || ! class_exists( '\\Elementor\\Plugin' ) || is_admin() || is_feed() ) {
			return;
		}
		if ( 'publish' !== get_post_status( $template_id ) ) {
			return;
		}
		$elementor = \Elementor\Plugin::$instance;
		if ( $elementor->editor->is_edit_mode() || $elementor->preview->is_preview_mode() ) {
			return;
		}
		if ( is_singular() && (int) get_queried_object_id() === $template_id ) {
			return; // خودِ قالب را باز کرده‌اند: دوبار چاپ نشود.
		}
		echo '<div class="wsf-global-popups">';
		echo $elementor->frontend->get_builder_content_for_display( $template_id, true ); // phpcs:ignore WordPress.Security.EscapeOutput -- Elementor output
		echo '</div>';
	}

	public function register_widgets( $widgets_manager ) {
		foreach ( $this->modules() as $module ) {
			$module->register_elementor_widget( $widgets_manager );
		}
	}

	/* ---------------------------------------------------------------
	 * منوی ادمین
	 * --------------------------------------------------------------- */
	public function register_admin_menu() {
		add_menu_page(
			__( 'فرم‌های Webisoft', 'webisoft-school-forms' ),
			__( 'فرم‌های Webisoft', 'webisoft-school-forms' ),
			'manage_options',
			'wsf-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-feedback',
			26
		);

		add_submenu_page( 'wsf-dashboard', __( 'داشبورد', 'webisoft-school-forms' ), __( 'داشبورد', 'webisoft-school-forms' ), 'manage_options', 'wsf-dashboard', array( $this, 'render_dashboard' ) );
		add_submenu_page( 'wsf-dashboard', __( 'ثبت‌نام‌های همکاری', 'webisoft-school-forms' ), __( 'ثبت‌نام‌های همکاری', 'webisoft-school-forms' ), 'manage_options', 'wsf-resume', array( $this->resume, 'render_submissions_page' ) );
		add_submenu_page( 'wsf-dashboard', __( 'عضویت‌های آکادمی', 'webisoft-school-forms' ), __( 'عضویت‌های آکادمی', 'webisoft-school-forms' ), 'manage_options', 'wsf-academy-membership', array( $this->academy_membership, 'render_submissions_page' ) );
		add_submenu_page( 'wsf-dashboard', __( 'رزروهای مشاوره', 'webisoft-school-forms' ), __( 'رزروهای مشاوره', 'webisoft-school-forms' ), 'manage_options', 'wsf-consulting', array( $this->consulting, 'render_submissions_page' ) );
		add_submenu_page( 'wsf-dashboard', __( 'گزارش ویزارد هوشمند', 'webisoft-school-forms' ), __( 'گزارش ویزارد هوشمند', 'webisoft-school-forms' ), 'manage_options', 'wsf-wizard-logs', array( $this->teacher_wizard, 'render_logs_page' ) );
		add_submenu_page( 'wsf-dashboard', __( 'تنظیمات فرم‌ها', 'webisoft-school-forms' ), __( 'تنظیمات فرم‌ها', 'webisoft-school-forms' ), 'manage_options', 'wsf-settings', array( $this, 'render_settings_page' ) );
		add_submenu_page( 'wsf-dashboard', __( 'ابزار عیب‌یابی', 'webisoft-school-forms' ), __( 'ابزار عیب‌یابی', 'webisoft-school-forms' ), 'manage_options', 'wsf-diagnostics', array( $this, 'render_diagnostics_page' ) );
	}

	/**
	 * صفحه‌ی «ابزار عیب‌یابی»: یک گزارش متنیِ کامل از دقیقاً همان چیزهایی که در
	 * این گفتگو مدام لازم بوده دستی با اسکرین‌شات چک شود — مقدار واقعیِ ذخیره‌شده
	 * در دیتابیس، CSS واقعیِ تولیدشده، وضعیت کش/آبجکت‌کش، و پلاگین‌های فعال —
	 * تا کاربر فقط یک دکمه بزند و کل متن را برای من کپی/پیست کند.
	 */
	public function render_diagnostics_page() {
		if ( isset( $_POST['wsf_clear_elementor_cache'] ) && check_admin_referer( 'wsf_clear_elementor_cache' ) && class_exists( '\Elementor\Plugin' ) ) {
			try {
				\Elementor\Plugin::$instance->files_manager->clear_cache();
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'کش فایل‌های CSS المنتور پاک شد.', 'webisoft-school-forms' ) . '</p></div>';
			} catch ( \Throwable $e ) {
				echo '<div class="notice notice-error"><p>' . esc_html( $e->getMessage() ) . '</p></div>';
			}
		}

		$report = $this->build_diagnostics_report();

		$scan_post_id = isset( $_POST['wsf_scan_post_id'] ) ? intval( $_POST['wsf_scan_post_id'] ) : 0;
		$scan_result  = '';
		if ( $scan_post_id && check_admin_referer( 'wsf_scan_post', 'wsf_scan_nonce' ) ) {
			$scan_result = $this->scan_post_for_widget_overrides( $scan_post_id );
		}
		?>
		<div class="wsf-a-wrap">
			<?php wsf_admin_page_header( '🛠️', __( 'ابزار عیب‌یابی', 'webisoft-school-forms' ), __( 'این گزارش را کامل کپی کنید و برای پشتیبانی بفرستید — همه‌ی چیزهایی که برای پیدا کردن علت «تنظیمات اعمال نمی‌شود» لازم است، اینجاست.', 'webisoft-school-forms' ) ); ?>

			<div class="wsf-a-card">
				<h3><?php esc_html_e( 'اسکن یک صفحه‌ی خاص برای «مقدار دستیِ چسبیده به ویجت»', 'webisoft-school-forms' ); ?></h3>
				<p class="description"><?php esc_html_e( 'شناسه‌ی همون صفحه‌ای که ویجت‌های فرم روشه رو وارد کنید (توی آدرس ادمین وردپرس وقتی صفحه رو ویرایش می‌کنید، عدد post=XXXX هست). این ابزار داخل داده‌ی خودِ المنتور برای اون صفحه می‌گرده و می‌گه دقیقاً کدوم ویجت، کدوم رنگ/گردی رو به‌صورت دستی (مستقل از تنظیمات سراسری) ذخیره کرده.', 'webisoft-school-forms' ); ?></p>
				<form method="post" style="display:flex; gap:10px; align-items:center;">
					<?php wp_nonce_field( 'wsf_scan_post', 'wsf_scan_nonce' ); ?>
					<input type="number" name="wsf_scan_post_id" placeholder="<?php esc_attr_e( 'مثلاً 123', 'webisoft-school-forms' ); ?>" value="<?php echo esc_attr( $scan_post_id ?: '' ); ?>" style="width:150px;">
					<button type="submit" class="wsf-a-btn"><?php esc_html_e( 'اسکن کن', 'webisoft-school-forms' ); ?></button>
				</form>
				<?php if ( $scan_result ) : ?>
					<pre style="background:#111; color:#0f0; padding:14px; border-radius:8px; margin-top:14px; overflow:auto; direction:ltr; text-align:left; font-size:12px;"><?php echo esc_html( $scan_result ); ?></pre>
				<?php endif; ?>
			</div>

			<div class="wsf-a-card">
				<div class="wsf-a-card-head">
					<h3><?php esc_html_e( 'گزارش کامل', 'webisoft-school-forms' ); ?></h3>
					<button type="button" class="wsf-a-btn wsf-a-btn-sm" id="wsf-copy-diag">📋 <?php esc_html_e( 'کپی گزارش', 'webisoft-school-forms' ); ?></button>
				</div>
				<textarea id="wsf-diag-output" readonly style="width:100%; min-height:480px; font-family:monospace; font-size:12px; direction:ltr; text-align:left; white-space:pre;"><?php echo esc_textarea( $report ); ?></textarea>
			</div>

			<div class="wsf-a-card">
				<h3><?php esc_html_e( 'اقدامات سریع', 'webisoft-school-forms' ); ?></h3>
				<form method="post">
					<?php wp_nonce_field( 'wsf_clear_elementor_cache' ); ?>
					<input type="hidden" name="wsf_clear_elementor_cache" value="1">
					<button type="submit" class="wsf-a-btn"><?php esc_html_e( 'پاکسازی کش فایل‌های CSS المنتور', 'webisoft-school-forms' ); ?></button>
				</form>
			</div>
		</div>
		<script>
			document.getElementById('wsf-copy-diag').addEventListener('click', function () {
				var el = document.getElementById('wsf-diag-output');
				el.select();
				el.setSelectionRange(0, 999999);
				navigator.clipboard && navigator.clipboard.writeText(el.value);
				this.textContent = '✅ <?php echo esc_js( __( 'کپی شد', 'webisoft-school-forms' ) ); ?>';
			});
		</script>
		<?php
	}

	private function build_diagnostics_report() {
		global $wp_version, $wpdb;

		$lines   = array();
		$lines[] = '=== WSF Diagnostics — ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC ===';
		$lines[] = '';
		$lines[] = '-- پلاگین --';
		$lines[] = 'WSF_VERSION: ' . WSF_VERSION;
		$lines[] = 'frontend.css filemtime: ' . ( file_exists( WSF_PATH . 'assets/css/frontend.css' ) ? gmdate( 'Y-m-d H:i:s', filemtime( WSF_PATH . 'assets/css/frontend.css' ) ) . ' UTC' : 'یافت نشد' );
		$lines[] = '';

		$lines[] = '-- محیط --';
		$lines[] = 'WordPress: ' . $wp_version;
		$lines[] = 'PHP: ' . PHP_VERSION;
		$lines[] = 'Elementor: ' . ( defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : 'نصب نیست' );
		$lines[] = 'Elementor CSS print method: ' . get_option( 'elementor_css_print_method', 'نامشخص' );
		$lines[] = 'Persistent object cache فعال: ' . ( wp_using_ext_object_cache() ? 'بله' : 'خیر' );
		$lines[] = '';

		$lines[] = '-- پلاگین‌های فعال (کش/بهینه‌سازها با * مشخص شده‌اند) --';
		$known_cache_plugins = array( 'wp-rocket', 'litespeed-cache', 'w3-total-cache', 'wp-super-cache', 'autoptimize', 'sg-cachepress', 'wp-fastest-cache', 'cache-enabler', 'breeze', 'hummingbird-performance', 'nitropack' );
		foreach ( (array) get_option( 'active_plugins', array() ) as $plugin_file ) {
			$slug     = strtok( $plugin_file, '/' );
			$is_cache = in_array( $slug, $known_cache_plugins, true );
			$lines[]  = ( $is_cache ? '*** ' : '- ' ) . $plugin_file;
		}
		$lines[] = '';

		$lines[] = '-- مقدار واقعیِ ذخیره‌شده در wp_options["wsf_global_style"] --';
		$stored  = get_option( 'wsf_global_style', array() );
		$lines[] = wp_json_encode( $stored, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		$lines[] = '';

		$lines[] = '-- خروجی wsf_get_global_style() برای هر کلید (بعد از اعمال پیش‌فرض) --';
		foreach ( array_keys( wsf_css_var_map() ) as $key ) {
			$lines[] = $key . ' = ' . wsf_get_global_style( $key );
		}
		$lines[] = '';

		$lines[] = '-- رشته‌ی CSS واقعی که همین الان در PHP تولید می‌شود (باید داخل <style> صفحه دقیقاً همین باشد) --';
		$lines[] = ':root{' . wsf_build_css_vars() . '}';
		$lines[] = '';

		$lines[] = '-- Override اختصاصیِ هر ماژول (اگر خالی نباشد، همان مقدار برای آن ماژول رو همه‌چیز بالا برنده است) --';
		foreach ( array( 'resume', 'academy_membership', 'consulting', 'teacher_wizard' ) as $mod ) {
			$lines[] = $mod . '.accent_color = "' . get_option( "wsf_{$mod}_accent_color", '' ) . '"';
			$lines[] = $mod . '.font = "' . get_option( "wsf_{$mod}_font", '' ) . '"';
		}
		$lines[] = '';

		$lines[] = '-- wsf_db_version گزینه --';
		$lines[] = (string) get_option( 'wsf_db_version', '' );

		return implode( "\n", $lines );
	}

	/**
	 * داخل _elementor_data خودِ صفحه می‌گردد و هر ویجت وبیسافتی را که یکی از
	 * کنترل‌های override (رنگ برند اختصاصی/گردی گوشه‌ی اختصاصی و ...) را
	 * به‌صورت غیرخالی ذخیره کرده گزارش می‌کند — یعنی همان چیزی که همیشه
	 * روی تنظیمات سراسری برای «همان یک ویجت» برنده می‌ماند.
	 */
	private function scan_post_for_widget_overrides( $post_id ) {
		$raw = get_post_meta( $post_id, '_elementor_data', true );
		if ( empty( $raw ) ) {
			return "پستِ #{$post_id} یا وجود ندارد یا هنوز با المنتور ذخیره نشده (_elementor_data خالی است).";
		}
		$data = json_decode( is_string( $raw ) ? $raw : wp_json_encode( $raw ), true );
		if ( ! is_array( $data ) ) {
			return 'JSON قابل خواندن نبود.';
		}

		$override_keys = array( 'accent_color', 'font', 'trigger_radius', 'option_radius', 'modal_radius', 'btn_radius' );
		$found         = array();

		$walk = function ( $elements ) use ( &$walk, &$found, $override_keys ) {
			foreach ( (array) $elements as $el ) {
				if ( ! empty( $el['widgetType'] ) && strpos( $el['widgetType'], 'wsf-' ) === 0 ) {
					$hits = array();
					foreach ( $override_keys as $key ) {
						if ( empty( $el['settings'][ $key ] ) ) {
							continue;
						}
						$val = $el['settings'][ $key ];
						$is_empty = is_array( $val )
							? ( ( ! isset( $val['size'] ) || '' === $val['size'] ) && ( ! isset( $val['top'] ) || ( '' === $val['top'] && '' === ( $val['right'] ?? '' ) && '' === ( $val['bottom'] ?? '' ) && '' === ( $val['left'] ?? '' ) ) ) )
							: ( '' === $val );
						if ( ! $is_empty ) {
							$hits[ $key ] = $val;
						}
					}
					if ( $hits ) {
						$found[] = array(
							'id'         => $el['id'] ?? '?',
							'widgetType' => $el['widgetType'],
							'hits'       => $hits,
						);
					}
				}
				if ( ! empty( $el['elements'] ) ) {
					$walk( $el['elements'] );
				}
			}
		};
		$walk( $data );

		if ( ! $found ) {
			return "هیچ مقدار دستیِ چسبیده‌ای روی هیچ ویجت وبیسافتی توی این صفحه پیدا نشد.\nیعنی این صفحه از تنظیمات سراسری پیروی می‌کند — اگر بازهم رنگ/گردی اشتباه می‌بینید، قطعاً مشکل کش (فایل CSS خارجی المنتور یا کش هاست) است، نه یک override.";
		}

		$out = array();
		foreach ( $found as $w ) {
			$out[] = "ویجت #{$w['id']} ({$w['widgetType']}):";
			foreach ( $w['hits'] as $key => $val ) {
				$out[] = "  - {$key} = " . ( is_array( $val ) ? wp_json_encode( $val ) : $val );
			}
		}
		return implode( "\n", $out );
	}

	public function admin_assets( $hook ) {
		$is_wizard_edit_screen = in_array( $hook, array( 'post.php', 'post-new.php' ), true )
			&& isset( $_GET['post_type'] ) && WSF_Teacher_Wizard_Module::CPT === $_GET['post_type'];
		global $post;
		if ( 'post.php' === $hook && $post && WSF_Teacher_Wizard_Module::CPT === $post->post_type ) {
			$is_wizard_edit_screen = true;
		}

		if ( strpos( (string) $hook, 'wsf-' ) === false && ! $is_wizard_edit_screen ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_style( 'wsf-admin', WSF_URL . 'assets/css/admin.css', array(), WSF_VERSION );
		$accent = wsf_get_global_style( 'accent_color' );
		wp_add_inline_style( 'wsf-admin', ':root{--wsf-a-primary:' . $accent . ';--wsf-a-primary-hover:' . wsf_darken_hex( $accent, 15 ) . ';}' );
		wp_enqueue_script( 'wsf-jalali-datepicker', WSF_URL . 'assets/js/jalali-datepicker.js', array( 'jquery' ), WSF_VERSION, true );
		wp_enqueue_script( 'wsf-admin', WSF_URL . 'assets/js/admin.js', array( 'jquery', 'wp-color-picker' ), WSF_VERSION, true );

		if ( $is_wizard_edit_screen ) {
			wp_enqueue_script( 'wsf-wizard-builder', WSF_URL . 'assets/js/wizard-builder.js', array(), WSF_VERSION, true );
		}
	}

	public function render_dashboard() {
		global $wpdb;
		$counts = array(
			'resume'             => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wsf_table( 'resume' ) ),
			'academy_membership' => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wsf_table( 'academy_membership' ) ),
			'consulting'         => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wsf_table( 'consulting' ) ),
			'wizard'             => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wsf_table( 'wizard_logs' ) ),
		);
		?>
		<div class="wsf-a-wrap">
			<?php wsf_admin_page_header( '📋', __( 'فرم‌های Webisoft', 'webisoft-school-forms' ), __( 'پنج ویجت المنتور آماده (۴ فرم + یک دکمه‌ی لینک ساده) — هرکدام را از دسته‌ی «فرم‌های Webisoft» به هر صفحه‌ای بکشید.', 'webisoft-school-forms' ), '<a href="' . esc_url( admin_url( 'admin.php?page=wsf-settings' ) ) . '" class="wsf-a-btn wsf-a-btn-sec">⚙️ ' . esc_html__( 'تنظیمات فرم‌ها', 'webisoft-school-forms' ) . '</a>' ); ?>

			<div class="wsf-a-dash-cards">
				<div class="wsf-a-dash-card">
					<h3><?php esc_html_e( 'ثبت‌نام‌های همکاری', 'webisoft-school-forms' ); ?></h3>
					<p class="wsf-a-dash-count"><?php echo esc_html( number_format_i18n( $counts['resume'] ) ); ?></p>
					<a class="wsf-a-btn wsf-a-btn-sm" href="<?php echo esc_url( admin_url( 'admin.php?page=wsf-resume' ) ); ?>"><?php esc_html_e( 'مشاهده', 'webisoft-school-forms' ); ?></a>
				</div>
				<div class="wsf-a-dash-card">
					<h3><?php esc_html_e( 'عضویت‌های آکادمی', 'webisoft-school-forms' ); ?></h3>
					<p class="wsf-a-dash-count"><?php echo esc_html( number_format_i18n( $counts['academy_membership'] ) ); ?></p>
					<a class="wsf-a-btn wsf-a-btn-sm" href="<?php echo esc_url( admin_url( 'admin.php?page=wsf-academy-membership' ) ); ?>"><?php esc_html_e( 'مشاهده', 'webisoft-school-forms' ); ?></a>
				</div>
				<div class="wsf-a-dash-card">
					<h3><?php esc_html_e( 'رزروهای مشاوره', 'webisoft-school-forms' ); ?></h3>
					<p class="wsf-a-dash-count"><?php echo esc_html( number_format_i18n( $counts['consulting'] ) ); ?></p>
					<a class="wsf-a-btn wsf-a-btn-sm" href="<?php echo esc_url( admin_url( 'admin.php?page=wsf-consulting' ) ); ?>"><?php esc_html_e( 'مشاهده', 'webisoft-school-forms' ); ?></a>
				</div>
				<div class="wsf-a-dash-card">
					<h3><?php esc_html_e( 'گزارش ویزارد هوشمند', 'webisoft-school-forms' ); ?></h3>
					<p class="wsf-a-dash-count"><?php echo esc_html( number_format_i18n( $counts['wizard'] ) ); ?></p>
					<a class="wsf-a-btn wsf-a-btn-sm" href="<?php echo esc_url( admin_url( 'admin.php?page=wsf-wizard-logs' ) ); ?>"><?php esc_html_e( 'مشاهده', 'webisoft-school-forms' ); ?></a>
				</div>
			</div>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------
	 * تنظیمات سراسری (لایه اول از سه‌لایه رنگ/فونت)
	 * --------------------------------------------------------------- */
	public function register_global_settings() {
		register_setting( 'wsf_settings_group', 'wsf_global_popups', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_global_popups' ), 'default' => array() ) );
		register_setting( 'wsf_settings_group', 'wsf_global_popup_template', array( 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 0 ) );
		register_setting( 'wsf_settings_group', 'wsf_global_style', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_global_style' ) ) );
		foreach ( $this->modules() as $module ) {
			$module->register_settings();
		}
	}

	/**
	 * چون ذخیره‌ی فرم همیشه هرچه در آن لحظه در فیلدها بوده را کامل می‌نویسد،
	 * اگر کاربر یک‌بار (حتی برای چیز دیگری) دکمه‌ی ذخیره را زده باشد، مقادیر
	 * پیش‌فرضِ آن لحظه برای همیشه در دیتابیس «قفل» می‌شوند و تغییر دادن پیش‌فرض
	 * در کد دیگر اثری ندارد. این دکمه ساده‌ترین راه فرار از آن قفل است.
	 */
	public function maybe_reset_global_style() {
		if ( ! isset( $_POST['wsf_reset_global_style'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'wsf_reset_global_style' );
		delete_option( 'wsf_global_style' );
		wp_safe_redirect( admin_url( 'admin.php?page=wsf-settings&reset=1' ) );
		exit;
	}

	public function sanitize_global_style( $value ) {
		$weight_options = array_keys( wsf_get_font_weight_options() );
		$sanitize_weight = function ( $val, $default ) use ( $weight_options ) {
			return in_array( (string) $val, $weight_options, true ) ? (string) $val : $default;
		};
		$sanitize_size = function ( $val, $default ) {
			$val = (float) $val;
			return $val > 0 ? (string) $val : $default;
		};
		// برخلاف سایز فونت، مقدار گردی گوشه باید بتواند دقیقاً صفر باشد
		// (گوشه‌های وسطِ یک لیست متصل باید کاملاً صاف/صفر شوند).
		$sanitize_radius = function ( $val, $default ) {
			return is_numeric( $val ) && (float) $val >= 0 ? (string) (float) $val : $default;
		};

		$hex = function ( $val, $default ) {
			return sanitize_hex_color( $val ?? '' ) ?: $default;
		};

		return array(
			// برند و گزینه‌ها
			'accent_color'       => $hex( $value['accent_color'] ?? '', '#7f54b3' ),
			'option_bg'          => $hex( $value['option_bg'] ?? '', '#191c21' ),
			'option_bg_hover'    => $hex( $value['option_bg_hover'] ?? '', '#42454c' ),
			'checkbox_bg'        => $hex( $value['checkbox_bg'] ?? '', '#42454c' ),
			'option_text'        => $hex( $value['option_text'] ?? '', '#ffffff' ),
			'option_radius_tl'   => $sanitize_radius( $value['option_radius_tl'] ?? '', '10' ),
			'option_radius_tr'   => $sanitize_radius( $value['option_radius_tr'] ?? '', '10' ),
			'option_radius_br'   => $sanitize_radius( $value['option_radius_br'] ?? '', '10' ),
			'option_radius_bl'   => $sanitize_radius( $value['option_radius_bl'] ?? '', '10' ),
			'trigger_radius_tl'  => $sanitize_radius( $value['trigger_radius_tl'] ?? '', '10' ),
			'trigger_radius_tr'  => $sanitize_radius( $value['trigger_radius_tr'] ?? '', '10' ),
			'trigger_radius_br'  => $sanitize_radius( $value['trigger_radius_br'] ?? '', '10' ),
			'trigger_radius_bl'  => $sanitize_radius( $value['trigger_radius_bl'] ?? '', '10' ),
			'btn_radius'         => $sanitize_radius( $value['btn_radius'] ?? '', '10' ),
			'modal_radius'       => $sanitize_radius( $value['modal_radius'] ?? '', '14' ),
			'show_option_check'  => empty( $value['show_option_check'] ) ? 0 : 1,
			// مودال و متن‌ها
			'modal_bg'           => $hex( $value['modal_bg'] ?? '', '#000000' ),
			'heading_color'      => $hex( $value['heading_color'] ?? '', '#ffffff' ),
			'desc_color'         => $hex( $value['desc_color'] ?? '', '#9aa0a6' ),
			'label_color'        => $hex( $value['label_color'] ?? '', '#ffffff' ),
			'close_color'        => $hex( $value['close_color'] ?? '', '#9aa0a6' ),
			// فیلدهای فرم
			'field_bg'           => $hex( $value['field_bg'] ?? '', '#222327' ),
			'field_border'       => $hex( $value['field_border'] ?? '', '#42454c' ),
			'field_text'         => $hex( $value['field_text'] ?? '', '#ffffff' ),
			// دکمه‌ها
			'btn_secondary_bg'   => $hex( $value['btn_secondary_bg'] ?? '', '#f0f0f0' ),
			'btn_secondary_text' => $hex( $value['btn_secondary_text'] ?? '', '#333333' ),
			// پیام‌ها
			'success_bg'         => $hex( $value['success_bg'] ?? '', '#e7f7ed' ),
			'success_text'       => $hex( $value['success_text'] ?? '', '#176b35' ),
			'error_bg'           => $hex( $value['error_bg'] ?? '', '#fdeaea' ),
			'error_text'         => $hex( $value['error_text'] ?? '', '#aa1111' ),
			// فونت و تایپوگرافی
			'font'               => sanitize_text_field( $value['font'] ?? 'inherit' ),
			'heading_size'       => $sanitize_size( $value['heading_size'] ?? '', '22' ),
			'heading_weight'     => $sanitize_weight( $value['heading_weight'] ?? '', '700' ),
			'desc_size'          => $sanitize_size( $value['desc_size'] ?? '', '14.5' ),
			'desc_weight'        => $sanitize_weight( $value['desc_weight'] ?? '', '400' ),
			'btn_size'           => $sanitize_size( $value['btn_size'] ?? '', '16' ),
			'btn_weight'         => $sanitize_weight( $value['btn_weight'] ?? '', '600' ),
			'option_size'        => $sanitize_size( $value['option_size'] ?? '', '15.5' ),
			'option_weight'      => $sanitize_weight( $value['option_weight'] ?? '', '500' ),
		);
	}

	public function render_settings_page() {
		?>
		<div class="wsf-a-wrap">
			<?php
			wsf_admin_page_header(
				'⚙️',
				__( 'تنظیمات فرم‌ها', 'webisoft-school-forms' ),
				__( 'متن، رنگ، فونت و گردی گوشه‌ی همه‌ی ویجت‌ها (۴ فرم + دکمه‌ی لینک) از اینجا مدیریت می‌شود.', 'webisoft-school-forms' ),
				'<form method="post" style="margin:0;" onsubmit="return confirm(\'' . esc_js( __( 'همه‌ی رنگ‌ها/فونت‌های سراسری به پیش‌فرض کارخانه برمی‌گردند. مطمئنید؟', 'webisoft-school-forms' ) ) . '\');">' . wp_nonce_field( 'wsf_reset_global_style', '_wpnonce', true, false ) . '<input type="hidden" name="wsf_reset_global_style" value="1"><button type="submit" class="wsf-a-btn wsf-a-btn-sec">↺ ' . esc_html__( 'بازنشانی رنگ‌ها به پیش‌فرض', 'webisoft-school-forms' ) . '</button></form>'
			);
			if ( isset( $_GET['reset'] ) ) {
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'رنگ‌های سراسری به پیش‌فرض بازگشت.', 'webisoft-school-forms' ) . '</p></div>';
			}
			?>

			<nav class="wsf-a-tabs">
				<button type="button" class="wsf-a-tab active" data-tab="global"><?php esc_html_e( 'عمومی', 'webisoft-school-forms' ); ?></button>
				<button type="button" class="wsf-a-tab" data-tab="resume"><?php esc_html_e( 'همکاری', 'webisoft-school-forms' ); ?></button>
				<button type="button" class="wsf-a-tab" data-tab="academy-membership"><?php esc_html_e( 'عضویت آکادمی', 'webisoft-school-forms' ); ?></button>
				<button type="button" class="wsf-a-tab" data-tab="consulting"><?php esc_html_e( 'مشاوره', 'webisoft-school-forms' ); ?></button>
				<button type="button" class="wsf-a-tab" data-tab="wizard"><?php esc_html_e( 'ویزارد هوشمند', 'webisoft-school-forms' ); ?></button>
			</nav>

			<form method="post" action="options.php">
				<?php settings_fields( 'wsf_settings_group' ); ?>

				<div class="wsf-a-panel" data-panel="global">
					<div class="wsf-a-card">
						<h3><?php esc_html_e( 'پاپ‌آپ در همه‌ی صفحات (برای لینک منو)', 'webisoft-school-forms' ); ?></h3>
						<p class="description"><?php esc_html_e( 'بدون نیاز به ساخت قالب یا قرار دادن ویجت: برای هر فرم یک شناسه بنویسید (مثلاً consulting-popup، بدون #). آن فرم در فوتر همه‌ی صفحات بارگذاری می‌شود و لینک منو با آدرس #شناسه آن را باز می‌کند. خالی = غیرفعال.', 'webisoft-school-forms' ); ?></p>
						<?php $gp = (array) get_option( 'wsf_global_popups', array() ); ?>
						<table class="form-table"><tbody>
						<?php foreach ( $this->global_popup_modules() as $gkey => $ginfo ) : ?>
							<tr><th scope="row"><?php echo esc_html( $ginfo[0] ); ?></th><td><input type="text" dir="ltr" class="regular-text" name="wsf_global_popups[<?php echo esc_attr( $gkey ); ?>]" value="<?php echo esc_attr( isset( $gp[ $gkey ] ) ? $gp[ $gkey ] : '' ); ?>" placeholder="<?php echo esc_attr( str_replace( '_', '-', $gkey ) ); ?>-popup"></td></tr>
						<?php endforeach; ?>
						</tbody></table>
						<hr>
						<h4><?php esc_html_e( 'روش جایگزین: قالب Elementor (یا شورت‌کد [wsf_form type="consulting"] در هر صفحه)', 'webisoft-school-forms' ); ?></h4>
						<p class="description"><?php esc_html_e( 'در Elementor یک «قالب ذخیره‌شده» (Saved Template / Section) بسازید، ویجت‌های فرم را داخلش بگذارید و برای هر کدام «شناسه پاپ‌آپ» بدهید. شناسه‌ی عددی (ID) همان قالب را اینجا وارد کنید تا در فوتر همه‌ی صفحات چاپ شود. سپس لینک منو مثل #consulting-popup در هر صفحه‌ای کار می‌کند.', 'webisoft-school-forms' ); ?></p>
						<p><input type="number" min="0" name="wsf_global_popup_template" value="<?php echo esc_attr( (int) get_option( 'wsf_global_popup_template', 0 ) ); ?>" class="small-text" placeholder="0"> <span class="description"><?php esc_html_e( 'ID قالب (۰ = غیرفعال). ID را از آدرس ویرایش قالب (post=123) یا ستون Shortcode فهرست قالب‌ها بردارید.', 'webisoft-school-forms' ); ?></span></p>
					</div>
					<div class="wsf-a-card"><?php $this->render_global_settings_fields(); ?></div>
				</div>
				<div class="wsf-a-panel" data-panel="resume" hidden>
					<div class="wsf-a-card"><?php $this->resume->render_settings_fields(); ?></div>
				</div>
				<div class="wsf-a-panel" data-panel="academy-membership" hidden>
					<div class="wsf-a-card"><?php $this->academy_membership->render_settings_fields(); ?></div>
				</div>
				<div class="wsf-a-panel" data-panel="consulting" hidden>
					<div class="wsf-a-card"><?php $this->consulting->render_settings_fields(); ?></div>
				</div>
				<div class="wsf-a-panel" data-panel="wizard" hidden>
					<div class="wsf-a-card"><?php $this->teacher_wizard->render_settings_fields(); ?></div>
				</div>

				<?php submit_button( __( 'ذخیره همه‌ی تنظیمات', 'webisoft-school-forms' ) ); ?>
			</form>
		</div>
		<?php
	}

	private function color_field_row( $key, $label, $desc = '' ) {
		$value = wsf_get_global_style( $key );
		?>
		<tr>
			<th><?php echo esc_html( $label ); ?></th>
			<td>
				<input type="text" class="wsf-color-picker" name="wsf_global_style[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" dir="ltr">
				<?php if ( $desc ) : ?><p class="description"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * ردیف تنظیمِ گردی هر ۴ گوشه به‌صورت مجزا (بالا-چپ/بالا-راست/پایین-راست/پایین-چپ).
	 * برای ساخت «لیست متصل» از چند ویجت پشت‌سرهم: روی اولین ویجت فقط گوشه‌های
	 * بالا را گرد بگذارید، وسطی‌ها را همه صفر، آخری را فقط گوشه‌های پایین.
	 */
	private function corner_radius_field_row( $prefix, $label, $desc = '' ) {
		$corners = array(
			'tl' => __( 'بالا-چپ', 'webisoft-school-forms' ),
			'tr' => __( 'بالا-راست', 'webisoft-school-forms' ),
			'br' => __( 'پایین-راست', 'webisoft-school-forms' ),
			'bl' => __( 'پایین-چپ', 'webisoft-school-forms' ),
		);
		?>
		<tr>
			<th><?php echo esc_html( $label ); ?></th>
			<td>
				<div style="display:flex; gap:14px; flex-wrap:wrap;">
					<?php foreach ( $corners as $suffix => $corner_label ) : ?>
						<label style="display:flex; flex-direction:column; gap:4px; font-weight:400; font-size:12px;">
							<?php echo esc_html( $corner_label ); ?>
							<input type="number" min="0" max="60" style="width:80px;" name="wsf_global_style[<?php echo esc_attr( $prefix . '_' . $suffix ); ?>]" value="<?php echo esc_attr( wsf_get_global_style( $prefix . '_' . $suffix ) ); ?>">
						</label>
					<?php endforeach; ?>
				</div>
				<?php if ( $desc ) : ?><p class="description"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
			</td>
		</tr>
		<?php
	}

	private function render_global_settings_fields() {
		$style = array(
			'font'              => wsf_get_global_style( 'font' ),
			'btn_radius'        => wsf_get_global_style( 'btn_radius' ),
			'show_option_check' => wsf_get_global_style( 'show_option_check' ),
			'heading_size'      => wsf_get_global_style( 'heading_size' ),
			'heading_weight'    => wsf_get_global_style( 'heading_weight' ),
			'desc_size'         => wsf_get_global_style( 'desc_size' ),
			'desc_weight'       => wsf_get_global_style( 'desc_weight' ),
			'btn_size'          => wsf_get_global_style( 'btn_size' ),
			'btn_weight'        => wsf_get_global_style( 'btn_weight' ),
			'option_size'       => wsf_get_global_style( 'option_size' ),
			'option_weight'     => wsf_get_global_style( 'option_weight' ),
		);
		$fonts          = wsf_get_elementor_fonts();
		$weight_options = wsf_get_font_weight_options();
		?>
		<p class="description">
			<?php esc_html_e( 'این‌ها تنظیمات «سراسری» هستند: پیش‌فرضِ هر ۵ ویجت، از قبل شبیه سبک مسترکلاس تنظیم شده. اگر یک ویجت خاص باید رنگ/گردیِ متفاوتی داشته باشد، لازم نیست اینجا چیزی تغییر بدهید — همان ویجت را در المنتور انتخاب کنید و از تب «Style» خودش override کنید؛ فقط همان یک نمونه عوض می‌شود.', 'webisoft-school-forms' ); ?>
		</p>

		<div style="background:#f8f6ff; border:1px solid #e4defa; border-radius:10px; padding:16px 18px; margin-bottom:20px;">
			<h3 style="margin-top:0;"><?php esc_html_e( 'رنگ‌بندی سریع', 'webisoft-school-forms' ); ?></h3>
			<p class="description" style="margin-top:-8px;"><?php esc_html_e( 'این ۴ رنگ روی تقریباً همه‌چیز اثر می‌گذارند — بقیه‌ی رنگ‌های ریز اختیاری هستند و پایین صفحه، داخل «تنظیمات پیشرفته» قرار دارند.', 'webisoft-school-forms' ); ?></p>
			<div class="wsf-a-grid">
				<?php
				$this->color_field_row( 'accent_color', __( 'رنگ برند (دکمه‌های داخل مودال + تیک انتخاب)', 'webisoft-school-forms' ) );
				$this->color_field_row( 'modal_bg', __( 'پس‌زمینه‌ی پاپ‌آپ', 'webisoft-school-forms' ) );
				$this->color_field_row( 'option_bg', __( 'پس‌زمینه‌ی ردیف‌ها (دکمه‌ی اصلی + لیست گزینه‌ها)', 'webisoft-school-forms' ) );
				$this->color_field_row( 'option_bg_hover', __( 'پس‌زمینه‌ی ردیف در هاور/انتخاب', 'webisoft-school-forms' ) );
				$this->color_field_row( 'checkbox_bg', __( 'داخل چک‌باکس/رادیوِ خالی', 'webisoft-school-forms' ) );
				$this->color_field_row( 'option_text', __( 'رنگ متن روی ردیف‌های تیره', 'webisoft-school-forms' ) );
				$this->color_field_row( 'field_bg', __( 'پس‌زمینه‌ی فیلدهای فرم (نام، تلفن، ...)', 'webisoft-school-forms' ) );
				?>
			</div>
		</div>

		<h3><?php esc_html_e( 'گردی گوشه‌ها و فونت', 'webisoft-school-forms' ); ?></h3>
		<table class="form-table">
			<?php
			$this->corner_radius_field_row(
				'trigger_radius',
				__( 'گردی گوشه‌های دکمه‌ی اصلی (بازکننده‌ی فرم)', 'webisoft-school-forms' ),
				__( 'اگر چند ویجت را پشت‌سرهم می‌چینید تا یک لیست متصل بسازند: روی ویجت اول فقط بالا-چپ/بالا-راست را گرد بگذارید، وسطی‌ها را همه صفر، ویجت آخر را فقط پایین-چپ/پایین-راست.', 'webisoft-school-forms' )
			);
			$this->corner_radius_field_row(
				'option_radius',
				__( 'گردی گوشه‌های لیست گزینه‌ها (داخل مودال)', 'webisoft-school-forms' ),
				__( 'همین منطق برای گزینه‌ی اول و آخرِ داخل هر مودال به‌صورت خودکار اعمال می‌شود.', 'webisoft-school-forms' )
			);
			?>
			<tr>
				<th><?php esc_html_e( 'گردی گوشه‌های خودِ پاپ‌آپ (مودال)', 'webisoft-school-forms' ); ?></th>
				<td><input type="number" min="0" max="40" style="width:90px;" name="wsf_global_style[modal_radius]" value="<?php echo esc_attr( wsf_get_global_style( 'modal_radius' ) ); ?>"> px</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'گردی گوشه‌های دکمه‌های داخل مودال', 'webisoft-school-forms' ); ?></th>
				<td><input type="number" min="0" max="40" style="width:90px;" name="wsf_global_style[btn_radius]" value="<?php echo esc_attr( $style['btn_radius'] ); ?>"> px</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'آیکون چک‌باکس/رادیو کنار گزینه‌ها', 'webisoft-school-forms' ); ?></th>
				<td>
					<label><input type="checkbox" name="wsf_global_style[show_option_check]" value="1" <?php checked( $style['show_option_check'] ); ?>> <?php esc_html_e( 'نمایش داده شود', 'webisoft-school-forms' ); ?></label>
					<p class="description"><?php esc_html_e( 'اگر خاموش کنید، ردیف گزینه‌ها بدون آیکون چک‌باکس/رادیو نمایش داده می‌شود و فقط با روشن‌شدن پس‌زمینه، انتخاب مشخص می‌شود.', 'webisoft-school-forms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'فونت فرم‌ها', 'webisoft-school-forms' ); ?></th>
				<td>
					<select name="wsf_global_style[font]" style="min-width:25em;">
						<option value="inherit" <?php selected( $style['font'], 'inherit' ); ?>><?php esc_html_e( 'پیش‌فرض المنتور/قالب', 'webisoft-school-forms' ); ?></option>
						<option value="Tahoma, sans-serif" <?php selected( $style['font'], 'Tahoma, sans-serif' ); ?>>Tahoma</option>
						<?php if ( $fonts ) : ?>
							<optgroup label="<?php esc_attr_e( 'فونت‌های اختصاصی المنتور', 'webisoft-school-forms' ); ?>">
								<?php foreach ( $fonts as $font ) : ?>
									<option value="<?php echo esc_attr( $font ); ?>" <?php selected( $style['font'], $font ); ?>><?php echo esc_html( $font ); ?></option>
								<?php endforeach; ?>
							</optgroup>
						<?php endif; ?>
					</select>
				</td>
			</tr>
		</table>

		<details style="margin-top:10px;">
			<summary style="cursor:pointer; font-weight:700; font-size:14px; padding:8px 0;"><?php esc_html_e( '⚙️ تنظیمات پیشرفته رنگ (اختیاری — برای وقتی رنگ‌بندی سریع کافی نیست)', 'webisoft-school-forms' ); ?></summary>

			<h3><?php esc_html_e( 'متن‌های مودال', 'webisoft-school-forms' ); ?></h3>
			<table class="form-table">
				<?php
				$this->color_field_row( 'heading_color', __( 'رنگ تیتر هر مرحله', 'webisoft-school-forms' ) );
				$this->color_field_row( 'desc_color', __( 'رنگ متن توضیحات', 'webisoft-school-forms' ) );
				$this->color_field_row( 'label_color', __( 'رنگ برچسب فیلدها', 'webisoft-school-forms' ) );
				$this->color_field_row( 'close_color', __( 'رنگ دکمه‌ی بستن (×)', 'webisoft-school-forms' ) );
				?>
			</table>

			<h3><?php esc_html_e( 'فیلدهای فرم', 'webisoft-school-forms' ); ?></h3>
			<table class="form-table">
				<?php
				$this->color_field_row( 'field_border', __( 'رنگ حاشیه‌ی فیلد', 'webisoft-school-forms' ) );
				$this->color_field_row( 'field_text', __( 'رنگ متن ورودی فیلد', 'webisoft-school-forms' ) );
				?>
			</table>

			<h3><?php esc_html_e( 'دکمه‌ی «مرحله قبل / انصراف»', 'webisoft-school-forms' ); ?></h3>
			<table class="form-table">
				<?php
				$this->color_field_row( 'btn_secondary_bg', __( 'پس‌زمینه‌ی دکمه ثانویه', 'webisoft-school-forms' ) );
				$this->color_field_row( 'btn_secondary_text', __( 'رنگ متن دکمه ثانویه', 'webisoft-school-forms' ) );
				?>
			</table>

			<h3><?php esc_html_e( 'پیام موفقیت / خطا', 'webisoft-school-forms' ); ?></h3>
			<table class="form-table">
				<?php
				$this->color_field_row( 'success_bg', __( 'پس‌زمینه‌ی پیام موفقیت', 'webisoft-school-forms' ) );
				$this->color_field_row( 'success_text', __( 'رنگ متن پیام موفقیت', 'webisoft-school-forms' ) );
				$this->color_field_row( 'error_bg', __( 'پس‌زمینه‌ی پیام خطا', 'webisoft-school-forms' ) );
				$this->color_field_row( 'error_text', __( 'رنگ متن پیام خطا', 'webisoft-school-forms' ) );
				?>
			</table>
		</details>

		<h3><?php esc_html_e( 'تایپوگرافی (سایز و وزن هر بخش)', 'webisoft-school-forms' ); ?></h3>
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'تیتر هر مرحله', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="number" step="0.5" min="10" style="width:90px;" name="wsf_global_style[heading_size]" value="<?php echo esc_attr( $style['heading_size'] ); ?>"> px
					<select name="wsf_global_style[heading_weight]">
						<?php foreach ( $weight_options as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $style['heading_weight'], $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'متن توضیحات', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="number" step="0.5" min="10" style="width:90px;" name="wsf_global_style[desc_size]" value="<?php echo esc_attr( $style['desc_size'] ); ?>"> px
					<select name="wsf_global_style[desc_weight]">
						<?php foreach ( $weight_options as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $style['desc_weight'], $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'متن گزینه‌ها (کارت‌های انتخابی)', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="number" step="0.5" min="10" style="width:90px;" name="wsf_global_style[option_size]" value="<?php echo esc_attr( $style['option_size'] ); ?>"> px
					<select name="wsf_global_style[option_weight]">
						<?php foreach ( $weight_options as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $style['option_weight'], $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'متن دکمه‌ها', 'webisoft-school-forms' ); ?></th>
				<td>
					<input type="number" step="0.5" min="10" style="width:90px;" name="wsf_global_style[btn_size]" value="<?php echo esc_attr( $style['btn_size'] ); ?>"> px
					<select name="wsf_global_style[btn_weight]">
						<?php foreach ( $weight_options as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $style['btn_weight'], $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</table>
		<?php
	}
}
