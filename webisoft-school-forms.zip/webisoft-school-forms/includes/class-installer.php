<?php
defined( 'ABSPATH' ) || exit;

/**
 * ساخت جدول‌های دیتابیس هر ۴ فرم روی فعال‌سازی پلاگین.
 */
class WSF_Installer {

	const DB_VERSION = '1.2.0';

	public static function activate() {
		self::create_tables();
		update_option( 'wsf_db_version', self::DB_VERSION );
	}

	/**
	 * علاوه بر activation hook، هر بار نسخه دیتابیس عوض شود هم صدا زده می‌شود
	 * (مثلاً بعد از آپدیت پلاگین با ستون جدید) — از WSF_Plugin::init() روی 'init' فراخوانی می‌شود.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'wsf_db_version' ) !== self::DB_VERSION ) {
			self::create_tables();
			update_option( 'wsf_db_version', self::DB_VERSION );
		}
	}

	private static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = array();

		// توجه: جدول قدیمی wsf_join_us دیگر اینجا مدیریت نمی‌شود (ماژول حذف شد)،
		// ولی خودِ جدول و داده‌های قبلی‌اش دست‌نخورده روی دیتابیس باقی می‌ماند.

		$sql[] = "CREATE TABLE " . wsf_table( 'academy_membership' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			first_name VARCHAR(100) NOT NULL,
			last_name VARCHAR(100) NOT NULL,
			phone VARCHAR(30) NOT NULL,
			education_level VARCHAR(100) NOT NULL,
			major VARCHAR(100) NOT NULL,
			submitted_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY first_name (first_name),
			KEY phone (phone),
			KEY education_level (education_level),
			KEY major (major),
			KEY submitted_at (submitted_at)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE " . wsf_table( 'resume' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			first_name VARCHAR(100) NOT NULL,
			last_name VARCHAR(100) NOT NULL,
			phone VARCHAR(30) NOT NULL,
			education VARCHAR(100) NOT NULL,
			file_id BIGINT UNSIGNED DEFAULT 0,
			file_name VARCHAR(255) DEFAULT '',
			file_url TEXT,
			submitted_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY first_name (first_name),
			KEY phone (phone),
			KEY education (education),
			KEY submitted_at (submitted_at)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE " . wsf_table( 'consulting' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			first_name VARCHAR(100) NOT NULL,
			last_name VARCHAR(100) NOT NULL,
			phone VARCHAR(30) NOT NULL,
			education_level VARCHAR(100) NOT NULL,
			major VARCHAR(100) NOT NULL,
			attendance_type VARCHAR(50) NOT NULL,
			plan_type VARCHAR(50) NOT NULL,
			submitted_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY first_name (first_name),
			KEY phone (phone),
			KEY attendance_type (attendance_type),
			KEY plan_type (plan_type),
			KEY submitted_at (submitted_at)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE " . wsf_table( 'wizard_logs' ) . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			wizard_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			log_data LONGTEXT NOT NULL,
			submitted_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY wizard_id (wizard_id),
			KEY submitted_at (submitted_at)
		) {$charset_collate};";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}
}
