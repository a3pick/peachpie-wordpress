<?php
defined( 'ABSPATH' ) || exit;

/**
 * رندر مشترک صفحه‌ی «لیست ثبت‌نام‌ها» برای هر فرمی که در یک جدول اختصاصی
 * ذخیره می‌شود: فیلتر، جدول، صفحه‌بندی، خروجی CSV و «منطقه خطر» (پاک‌سازی کامل).
 * هر ماژول (رزومه/همکاری، عضویت آکادمی، مشاوره) به‌جای اینکه این ~150 خط را دوباره
 * بنویسد، فقط یک نمونه از این کلاس با تنظیمات خودش می‌سازد.
 */
class WSF_Submissions_List {

	private $args;

	/**
	 * @param array $args {
	 *   @type string   $table               نام کامل جدول (خروجی wsf_table()).
	 *   @type string   $page_slug           اسلاگ صفحه‌ی ادمین (برای فرم فیلتر GET).
	 *   @type string   $title               عنوان بالای صفحه.
	 *   @type array    $columns             ['db_key' => 'برچسب ستون', ...] به ترتیب نمایش.
	 *   @type array    $filters             ['db_key' => ['label' => '', 'type' => 'text'|'select', 'options' => []]].
	 *   @type bool     $date_filter         آیا فیلتر «از تاریخ/تا تاریخ» روی submitted_at نمایش داده شود.
	 *   @type string   $csv_action          نام اکشن admin-post برای خروجی CSV.
	 *   @type string   $csv_filename_prefix پیشوند نام فایل CSV.
	 *   @type string   $nonce_prefix        پیشوند یکتا برای nonce های حذف/پاک‌سازی/CSV.
	 *   @type callable $row_cell            function($row, $key) => HTML امن سلول؛ اگر ندهید esc_html($row->$key) استفاده می‌شود.
	 *   @type callable $before_delete       function($row) — مثلاً حذف فایل پیوست پیش از حذف ردیف.
	 *   @type callable $before_clear        function() — مثلاً حذف همه‌ی فایل‌های پیوست پیش از TRUNCATE.
	 * }
	 */
	public function __construct( array $args ) {
		$this->args = wp_parse_args(
			$args,
			array(
				'date_filter'   => true,
				'row_cell'      => null,
				'before_delete' => null,
				'before_clear'  => null,
				'csv_columns'   => null, // اگر ستون‌های نمایش جدول برای CSV مناسب نیستند (مثلاً یک ستون دکمه‌ی دانلود)، اینجا نگاشت جداگانه بدهید.
			)
		);

		add_action( 'admin_post_' . $this->args['csv_action'], array( $this, 'handle_csv_export' ) );
	}

	private function table() {
		return $this->args['table'];
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'شما اجازه دسترسی به این صفحه را ندارید.', 'webisoft-school-forms' ) );
		}

		global $wpdb;
		$table = $this->table();

		$this->maybe_handle_delete( $table );
		$this->maybe_handle_clear( $table );

		list( $where_sql, $params, $filter_values ) = $this->build_where();

		$per_page     = 20;
		$current_page = isset( $_GET['paged'] ) ? max( 1, intval( $_GET['paged'] ) ) : 1;
		$offset       = ( $current_page - 1 ) * $per_page;

		$count_sql   = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$total_items = ! empty( $params ) ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql );

		$data_sql    = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY submitted_at DESC LIMIT %d OFFSET %d";
		$data_params = array_merge( $params, array( $per_page, $offset ) );
		$rows        = $wpdb->get_results( $wpdb->prepare( $data_sql, $data_params ) );
		$total_pages = ceil( $total_items / $per_page );

		?>
		<div class="wsf-a-wrap">
			<?php
			wsf_admin_page_header(
				$this->args['icon'] ?? '🗂️',
				$this->args['title'],
				sprintf(
					/* translators: %s: تعداد کل رکوردها با فرمت محلی */
					__( 'تعداد کل رکوردهای فعلی: %s', 'webisoft-school-forms' ),
					number_format_i18n( $total_items )
				),
				'<a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=' . $this->args['csv_action'] ), $this->args['csv_action'] ) ) . '" class="wsf-a-btn wsf-a-btn-sec">📥 ' . esc_html__( 'خروجی CSV', 'webisoft-school-forms' ) . '</a>'
			);
			?>

			<div class="wsf-a-card">
				<div class="wsf-a-card-head">
					<h3><?php esc_html_e( 'فیلتر', 'webisoft-school-forms' ); ?></h3>
				</div>
				<form method="get">
					<input type="hidden" name="page" value="<?php echo esc_attr( $this->args['page_slug'] ); ?>">
					<div class="wsf-a-grid">
						<?php foreach ( $this->args['filters'] as $key => $filter ) : ?>
							<div class="wsf-a-form-group">
								<label><?php echo esc_html( $filter['label'] ); ?></label>
								<?php if ( ( $filter['type'] ?? 'text' ) === 'select' ) : ?>
									<select name="<?php echo esc_attr( $key ); ?>" class="wsf-a-form-control">
										<option value=""><?php esc_html_e( 'همه', 'webisoft-school-forms' ); ?></option>
										<?php foreach ( $filter['options'] as $opt ) : ?>
											<option value="<?php echo esc_attr( $opt ); ?>" <?php selected( $filter_values[ $key ], $opt ); ?>><?php echo esc_html( $opt ); ?></option>
										<?php endforeach; ?>
									</select>
								<?php else : ?>
									<input type="text" class="wsf-a-form-control" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $filter_values[ $key ] ); ?>">
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
						<?php if ( $this->args['date_filter'] ) : ?>
							<div class="wsf-a-form-group"><label><?php esc_html_e( 'از تاریخ', 'webisoft-school-forms' ); ?></label><?php echo wsf_jalali_date_field( 'date_from', $filter_values['date_from'], __( 'انتخاب تاریخ', 'webisoft-school-forms' ) ); // phpcs:ignore -- خروجی خودش esc شده ?></div>
							<div class="wsf-a-form-group"><label><?php esc_html_e( 'تا تاریخ', 'webisoft-school-forms' ); ?></label><?php echo wsf_jalali_date_field( 'date_to', $filter_values['date_to'], __( 'انتخاب تاریخ', 'webisoft-school-forms' ) ); // phpcs:ignore -- خروجی خودش esc شده ?></div>
						<?php endif; ?>
					</div>
					<div style="display:flex; gap:10px; margin-top:6px;">
						<button type="submit" class="wsf-a-btn"><?php esc_html_e( 'اعمال فیلتر', 'webisoft-school-forms' ); ?></button>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . $this->args['page_slug'] ) ); ?>" class="wsf-a-btn wsf-a-btn-sec"><?php esc_html_e( 'حذف فیلترها', 'webisoft-school-forms' ); ?></a>
					</div>
				</form>
			</div>

			<div class="wsf-a-card">
				<table class="wsf-a-table">
					<thead>
						<tr>
							<th>ID</th>
							<?php foreach ( $this->args['columns'] as $label ) : ?>
								<th><?php echo esc_html( $label ); ?></th>
							<?php endforeach; ?>
							<th><?php esc_html_e( 'تاریخ ثبت', 'webisoft-school-forms' ); ?></th>
							<th><?php esc_html_e( 'عملیات', 'webisoft-school-forms' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php if ( $rows ) : ?>
						<?php foreach ( $rows as $row ) : ?>
							<tr>
								<td><?php echo esc_html( $row->id ); ?></td>
								<?php foreach ( array_keys( $this->args['columns'] ) as $key ) : ?>
									<td><?php echo $this->render_cell( $row, $key ); // phpcs:ignore -- already escaped by callback/esc_html ?></td>
								<?php endforeach; ?>
								<td><span dir="ltr"><?php echo esc_html( wsf_format_jalali_datetime( $row->submitted_at ) ); ?></span></td>
								<td>
									<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=' . $this->args['page_slug'] . '&wsf_action=delete&id=' . intval( $row->id ) ), $this->args['nonce_prefix'] . '_delete_' . intval( $row->id ) ) ); ?>" class="wsf-a-btn wsf-a-btn-danger wsf-a-btn-sm" onclick="return confirm('<?php echo esc_js( __( 'آیا از حذف این رکورد مطمئن هستید؟', 'webisoft-school-forms' ) ); ?>');"><?php esc_html_e( 'حذف', 'webisoft-school-forms' ); ?></a>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr><td colspan="<?php echo esc_attr( count( $this->args['columns'] ) + 3 ); ?>"><?php esc_html_e( 'هیچ رکوردی پیدا نشد.', 'webisoft-school-forms' ); ?></td></tr>
					<?php endif; ?>
					</tbody>
				</table>
				<?php if ( $total_pages > 1 ) : ?>
					<div style="margin-top:20px;">
						<?php
						echo paginate_links(
							array(
								'base'     => add_query_arg( 'paged', '%#%' ),
								'format'   => '',
								'current'  => $current_page,
								'total'    => $total_pages,
								'add_args' => array_filter( $filter_values ),
							)
						);
						?>
					</div>
				<?php endif; ?>
			</div>

			<div class="wsf-a-card" style="border-color:#fecaca;">
				<h3 style="color:#dc2626;"><?php esc_html_e( 'منطقه خطر', 'webisoft-school-forms' ); ?></h3>
				<form method="post" onsubmit="return confirm('<?php echo esc_js( __( 'هشدار: تمام اطلاعات این فرم حذف خواهند شد. مطمئن هستید؟', 'webisoft-school-forms' ) ); ?>');">
					<?php wp_nonce_field( $this->args['nonce_prefix'] . '_clear' ); ?>
					<input type="hidden" name="wsf_clear_database" value="1">
					<button type="submit" class="wsf-a-btn wsf-a-btn-danger">🗑 <?php esc_html_e( 'پاک کردن کل دیتابیس این فرم', 'webisoft-school-forms' ); ?></button>
				</form>
			</div>
		</div>
		<?php
	}

	private function render_cell( $row, $key ) {
		if ( is_callable( $this->args['row_cell'] ) ) {
			$html = call_user_func( $this->args['row_cell'], $row, $key );
			if ( null !== $html ) {
				return $html;
			}
		}
		return esc_html( $row->$key ?? '' );
	}

	private function build_where() {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();
		$values = array();

		foreach ( $this->args['filters'] as $key => $filter ) {
			$val = isset( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) : '';
			$values[ $key ] = $val;
			if ( $val === '' ) {
				continue;
			}
			if ( ( $filter['type'] ?? 'text' ) === 'select' ) {
				$where[]  = "{$key} = %s";
				$params[] = $val;
			} else {
				$where[]  = "{$key} LIKE %s";
				$params[] = '%' . $wpdb->esc_like( $val ) . '%';
			}
		}

		$values['date_from'] = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '';
		$values['date_to']   = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '';
		if ( $this->args['date_filter'] ) {
			if ( $values['date_from'] !== '' ) {
				$where[]  = 'DATE(submitted_at) >= %s';
				$params[] = $values['date_from'];
			}
			if ( $values['date_to'] !== '' ) {
				$where[]  = 'DATE(submitted_at) <= %s';
				$params[] = $values['date_to'];
			}
		}

		return array( implode( ' AND ', $where ), $params, $values );
	}

	private function maybe_handle_delete( $table ) {
		global $wpdb;
		if ( ! isset( $_GET['wsf_action'], $_GET['id'] ) || 'delete' !== $_GET['wsf_action'] ) {
			return;
		}
		$id = intval( $_GET['id'] );
		check_admin_referer( $this->args['nonce_prefix'] . '_delete_' . $id );

		if ( is_callable( $this->args['before_delete'] ) ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
			if ( $row ) {
				call_user_func( $this->args['before_delete'], $row );
			}
		}

		$wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'رکورد با موفقیت حذف شد.', 'webisoft-school-forms' ) . '</p></div>';
	}

	private function maybe_handle_clear( $table ) {
		global $wpdb;
		if ( ! isset( $_POST['wsf_clear_database'] ) ) {
			return;
		}
		check_admin_referer( $this->args['nonce_prefix'] . '_clear' );

		if ( is_callable( $this->args['before_clear'] ) ) {
			call_user_func( $this->args['before_clear'] );
		}

		$wpdb->query( "TRUNCATE TABLE {$table}" ); // phpcs:ignore -- table name is our own constant, not user input
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'تمام اطلاعات این فرم با موفقیت پاک شد.', 'webisoft-school-forms' ) . '</p></div>';
	}

	public function handle_csv_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی غیرمجاز.', 'webisoft-school-forms' ) );
		}
		check_admin_referer( $this->args['csv_action'] );

		global $wpdb;
		$rows = $wpdb->get_results( "SELECT * FROM {$this->table()} ORDER BY submitted_at DESC", ARRAY_A );

		$csv_columns = $this->args['csv_columns'] ?? $this->args['columns'];
		$headers     = array_merge( array( 'ID' ), array_values( $csv_columns ), array( 'تاریخ ثبت' ) );
		$keys        = array_keys( $csv_columns );

		$csv_rows = array();
		foreach ( $rows as $row ) {
			$line = array( $row['id'] );
			foreach ( $keys as $key ) {
				$line[] = $row[ $key ] ?? '';
			}
			$line[]     = $row['submitted_at'];
			$csv_rows[] = $line;
		}

		wsf_stream_csv( $this->args['csv_filename_prefix'] . '-' . gmdate( 'Y-m-d' ) . '.csv', $headers, $csv_rows );
	}

}
